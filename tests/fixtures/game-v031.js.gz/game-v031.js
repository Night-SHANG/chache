"use strict";
(() => {
  // src/platform/types.ts
  var SOUND_NAMES = ["pick", "place", "invalid", "route_ready", "forklift", "ship", "chain2", "chain3", "chain4", "upgrade", "shift", "fail"];

  // src/presentation/layout.ts
  var trays3 = [
    { x: 48, y: 1530, w: 316, h: 272 },
    { x: 382, y: 1530, w: 316, h: 272 },
    { x: 716, y: 1530, w: 316, h: 272 }
  ];
  var L = {
    width: 1080,
    height: 1920,
    board: { x: 120, y: 560, cell: 120, size: 840 },
    trays: trays3,
    trays3,
    pause: { x: 938, y: 54, w: 96, h: 100 },
    chain: { x: 938, y: 168, w: 96, h: 42 },
    boardHint: { x: 120, y: 496, w: 840, h: 27 },
    restart: { x: 246, y: 1240, w: 588, h: 114 },
    resume: { x: 246, y: 1090, w: 588, h: 114 },
    upgradeRects: [
      { x: 54, y: 650, w: 312, h: 592 },
      { x: 384, y: 650, w: 312, h: 592 },
      { x: 714, y: 650, w: 312, h: 592 }
    ],
    debug: { x: 880, y: 1836, w: 152, h: 48 }
  };
  function getTrayRects(count) {
    if (count === 3) return L.trays.map((rect) => ({ ...rect }));
    if (!Number.isInteger(count) || count < 1 || count > 4) return [];
    const gap = 18, x = 48, width = 984;
    const w = (width - gap * (count - 1)) / count;
    return Array.from({ length: count }, (_, index) => ({ x: x + index * (w + gap), y: 1530, w, h: 272 }));
  }
  function hitTestPoint(point2, rect) {
    return Number.isFinite(point2.x) && Number.isFinite(point2.y) && point2.x >= rect.x && point2.y >= rect.y && point2.x < rect.x + rect.w && point2.y < rect.y + rect.h;
  }
  function pointToCell(point2) {
    const { x, y, cell, size } = L.board;
    if (!hitTestPoint(point2, { x, y, w: size, h: size })) return null;
    return { x: Math.floor((point2.x - x) / cell), y: Math.floor((point2.y - y) / cell) };
  }
  function cellCenter(point2) {
    return { x: L.board.x + (point2.x + 0.5) * L.board.cell, y: L.board.y + (point2.y + 0.5) * L.board.cell };
  }
  function mapClientPoint(point2, viewport) {
    if (viewport.w <= 0 || viewport.h <= 0) return null;
    const scale = Math.min(viewport.w / L.width, viewport.h / L.height);
    const x = viewport.x + (viewport.w - L.width * scale) / 2;
    const y = viewport.y + (viewport.h - L.height * scale) / 2;
    const logical = { x: (point2.x - x) / scale, y: (point2.y - y) / scale };
    return hitTestPoint(logical, { x: 0, y: 0, w: L.width, h: L.height }) ? logical : null;
  }

  // src/platform/wechat.ts
  function createWechatPlatform(host, clock) {
    var _a;
    const canvas = host.createCanvas();
    const ctx = canvas.getContext("2d");
    if (!ctx) throw Error("\u65E0\u6CD5\u521B\u5EFA2D\u753B\u5E03");
    let dpr = 1, scale = 1, offsetX = 0, offsetY = 0;
    let viewport = { x: 0, y: 0, w: 1080, h: 1920 };
    const resize = () => {
      var _a2;
      const info = host.getWindowInfo ? host.getWindowInfo() : (_a2 = host.getSystemInfoSync) == null ? void 0 : _a2.call(host);
      if (!info) throw Error("\u7F3A\u5C11\u7A97\u53E3\u5C3A\u5BF8\u63A5\u53E3");
      dpr = Math.min(Math.max(info.pixelRatio || 1, 1), 3);
      canvas.width = Math.round(info.windowWidth * dpr);
      canvas.height = Math.round(info.windowHeight * dpr);
      const safe = info.safeArea;
      viewport = safe ? { x: safe.left, y: safe.top, w: safe.width, h: safe.height } : { x: 0, y: 0, w: info.windowWidth, h: info.windowHeight };
      scale = Math.min(viewport.w / L.width, viewport.h / L.height);
      offsetX = viewport.x + (viewport.w - L.width * scale) / 2;
      offsetY = viewport.y + (viewport.h - L.height * scale) / 2;
    };
    resize();
    (_a = host.onWindowResize) == null ? void 0 : _a.call(host, resize);
    const sounds = /* @__PURE__ */ new Map();
    const stopSounds = () => {
      for (const sound of sounds.values()) try {
        sound.stop();
      } catch (e) {
      }
    };
    const platform2 = {
      storage: { get: (key) => {
        const value = host.getStorageSync(key);
        if (value === "" || value === void 0 || value === null) return null;
        if (typeof value !== "string") throw Error("\u5B58\u50A8\u683C\u5F0F\u65E0\u6548");
        return value;
      }, set: (key, value) => host.setStorageSync(key, value), remove: (key) => host.removeStorageSync(key) },
      beginFrame: () => {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.fillStyle = "#0c131c";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.setTransform(scale * dpr, 0, 0, scale * dpr, offsetX * dpr, offsetY * dpr);
        return ctx;
      },
      frame: (callback) => clock.requestAnimationFrame(() => callback(clock.now())),
      now: clock.now,
      wallTime: () => Date.now(),
      onPointer: (callback) => {
        const convert = (type) => (event) => {
          var _a2, _b, _c;
          if (type === "cancel") {
            callback({ type, point: { x: -1, y: -1 }, id: (_b = (_a2 = event.changedTouches[0]) == null ? void 0 : _a2.identifier) != null ? _b : 0 });
            return;
          }
          for (const touch of event.changedTouches) {
            const point2 = (_c = mapClientPoint({ x: touch.clientX, y: touch.clientY }, viewport)) != null ? _c : { x: -1, y: -1 };
            callback({ type, point: point2, id: touch.identifier });
          }
        };
        host.onTouchStart(convert("down"));
        host.onTouchMove(convert("move"));
        host.onTouchEnd(convert("up"));
        host.onTouchCancel(convert("cancel"));
      },
      onHide: (callback) => host.onHide(() => {
        stopSounds();
        callback();
      }),
      onShow: (callback) => host.onShow(() => {
        resize();
        callback();
      }),
      playSound: (name) => {
        var _a2;
        if (!SOUND_NAMES.includes(name)) return;
        try {
          let sound = sounds.get(name);
          if (!sound) {
            sound = host.createInnerAudioContext();
            sounds.set(name, sound);
            try {
              (_a2 = sound.onError) == null ? void 0 : _a2.call(sound, () => {
              });
            } catch (e) {
            }
          }
          const path = `assets/${name}.wav`;
          if (sound.src !== path) sound.src = path;
          sound.stop();
          const playing = sound.play();
          if (playing) void playing.catch(() => {
          });
        } catch (e) {
        }
      },
      stopSounds,
      loadImage: (path) => new Promise((resolve, reject) => {
        const image = host.createImage();
        image.onload = () => resolve(image);
        image.onerror = reject;
        image.src = path;
      })
    };
    return platform2;
  }

  // node_modules/@tweenjs/tween.js/dist/tween.esm.js
  var Easing = Object.freeze({
    Linear: Object.freeze({
      None: function(amount) {
        return amount;
      },
      In: function(amount) {
        return amount;
      },
      Out: function(amount) {
        return amount;
      },
      InOut: function(amount) {
        return amount;
      }
    }),
    Quadratic: Object.freeze({
      In: function(amount) {
        return amount * amount;
      },
      Out: function(amount) {
        return amount * (2 - amount);
      },
      InOut: function(amount) {
        if ((amount *= 2) < 1) {
          return 0.5 * amount * amount;
        }
        return -0.5 * (--amount * (amount - 2) - 1);
      }
    }),
    Cubic: Object.freeze({
      In: function(amount) {
        return amount * amount * amount;
      },
      Out: function(amount) {
        return --amount * amount * amount + 1;
      },
      InOut: function(amount) {
        if ((amount *= 2) < 1) {
          return 0.5 * amount * amount * amount;
        }
        return 0.5 * ((amount -= 2) * amount * amount + 2);
      }
    }),
    Quartic: Object.freeze({
      In: function(amount) {
        return amount * amount * amount * amount;
      },
      Out: function(amount) {
        return 1 - --amount * amount * amount * amount;
      },
      InOut: function(amount) {
        if ((amount *= 2) < 1) {
          return 0.5 * amount * amount * amount * amount;
        }
        return -0.5 * ((amount -= 2) * amount * amount * amount - 2);
      }
    }),
    Quintic: Object.freeze({
      In: function(amount) {
        return amount * amount * amount * amount * amount;
      },
      Out: function(amount) {
        return --amount * amount * amount * amount * amount + 1;
      },
      InOut: function(amount) {
        if ((amount *= 2) < 1) {
          return 0.5 * amount * amount * amount * amount * amount;
        }
        return 0.5 * ((amount -= 2) * amount * amount * amount * amount + 2);
      }
    }),
    Sinusoidal: Object.freeze({
      In: function(amount) {
        return 1 - Math.sin((1 - amount) * Math.PI / 2);
      },
      Out: function(amount) {
        return Math.sin(amount * Math.PI / 2);
      },
      InOut: function(amount) {
        return 0.5 * (1 - Math.sin(Math.PI * (0.5 - amount)));
      }
    }),
    Exponential: Object.freeze({
      In: function(amount) {
        return amount === 0 ? 0 : Math.pow(1024, amount - 1);
      },
      Out: function(amount) {
        return amount === 1 ? 1 : 1 - Math.pow(2, -10 * amount);
      },
      InOut: function(amount) {
        if (amount === 0) {
          return 0;
        }
        if (amount === 1) {
          return 1;
        }
        if ((amount *= 2) < 1) {
          return 0.5 * Math.pow(1024, amount - 1);
        }
        return 0.5 * (-Math.pow(2, -10 * (amount - 1)) + 2);
      }
    }),
    Circular: Object.freeze({
      In: function(amount) {
        return 1 - Math.sqrt(1 - amount * amount);
      },
      Out: function(amount) {
        return Math.sqrt(1 - --amount * amount);
      },
      InOut: function(amount) {
        if ((amount *= 2) < 1) {
          return -0.5 * (Math.sqrt(1 - amount * amount) - 1);
        }
        return 0.5 * (Math.sqrt(1 - (amount -= 2) * amount) + 1);
      }
    }),
    Elastic: Object.freeze({
      In: function(amount) {
        if (amount === 0) {
          return 0;
        }
        if (amount === 1) {
          return 1;
        }
        return -Math.pow(2, 10 * (amount - 1)) * Math.sin((amount - 1.1) * 5 * Math.PI);
      },
      Out: function(amount) {
        if (amount === 0) {
          return 0;
        }
        if (amount === 1) {
          return 1;
        }
        return Math.pow(2, -10 * amount) * Math.sin((amount - 0.1) * 5 * Math.PI) + 1;
      },
      InOut: function(amount) {
        if (amount === 0) {
          return 0;
        }
        if (amount === 1) {
          return 1;
        }
        amount *= 2;
        if (amount < 1) {
          return -0.5 * Math.pow(2, 10 * (amount - 1)) * Math.sin((amount - 1.1) * 5 * Math.PI);
        }
        return 0.5 * Math.pow(2, -10 * (amount - 1)) * Math.sin((amount - 1.1) * 5 * Math.PI) + 1;
      }
    }),
    Back: Object.freeze({
      In: function(amount) {
        var s = 1.70158;
        return amount === 1 ? 1 : amount * amount * ((s + 1) * amount - s);
      },
      Out: function(amount) {
        var s = 1.70158;
        return amount === 0 ? 0 : --amount * amount * ((s + 1) * amount + s) + 1;
      },
      InOut: function(amount) {
        var s = 1.70158 * 1.525;
        if ((amount *= 2) < 1) {
          return 0.5 * (amount * amount * ((s + 1) * amount - s));
        }
        return 0.5 * ((amount -= 2) * amount * ((s + 1) * amount + s) + 2);
      }
    }),
    Bounce: Object.freeze({
      In: function(amount) {
        return 1 - Easing.Bounce.Out(1 - amount);
      },
      Out: function(amount) {
        if (amount < 1 / 2.75) {
          return 7.5625 * amount * amount;
        } else if (amount < 2 / 2.75) {
          return 7.5625 * (amount -= 1.5 / 2.75) * amount + 0.75;
        } else if (amount < 2.5 / 2.75) {
          return 7.5625 * (amount -= 2.25 / 2.75) * amount + 0.9375;
        } else {
          return 7.5625 * (amount -= 2.625 / 2.75) * amount + 0.984375;
        }
      },
      InOut: function(amount) {
        if (amount < 0.5) {
          return Easing.Bounce.In(amount * 2) * 0.5;
        }
        return Easing.Bounce.Out(amount * 2 - 1) * 0.5 + 0.5;
      }
    }),
    generatePow: function(power) {
      if (power === void 0) {
        power = 4;
      }
      power = power < Number.EPSILON ? Number.EPSILON : power;
      power = power > 1e4 ? 1e4 : power;
      return {
        In: function(amount) {
          return Math.pow(amount, power);
        },
        Out: function(amount) {
          return 1 - Math.pow(1 - amount, power);
        },
        InOut: function(amount) {
          if (amount < 0.5) {
            return Math.pow(amount * 2, power) / 2;
          }
          return (1 - Math.pow(2 - amount * 2, power)) / 2 + 0.5;
        }
      };
    }
  });
  var now = function() {
    return performance.now();
  };
  var Group = (
    /** @class */
    (function() {
      function Group2() {
        var tweens = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          tweens[_i] = arguments[_i];
        }
        this._tweens = {};
        this._tweensAddedDuringUpdate = {};
        this.add.apply(this, tweens);
      }
      Group2.prototype.getAll = function() {
        var _this = this;
        return Object.keys(this._tweens).map(function(tweenId) {
          return _this._tweens[tweenId];
        });
      };
      Group2.prototype.removeAll = function() {
        this._tweens = {};
      };
      Group2.prototype.add = function() {
        var _a;
        var tweens = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          tweens[_i] = arguments[_i];
        }
        for (var _b = 0, tweens_1 = tweens; _b < tweens_1.length; _b++) {
          var tween = tweens_1[_b];
          (_a = tween._group) === null || _a === void 0 ? void 0 : _a.remove(tween);
          tween._group = this;
          this._tweens[tween.getId()] = tween;
          this._tweensAddedDuringUpdate[tween.getId()] = tween;
        }
      };
      Group2.prototype.remove = function() {
        var tweens = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          tweens[_i] = arguments[_i];
        }
        for (var _a = 0, tweens_2 = tweens; _a < tweens_2.length; _a++) {
          var tween = tweens_2[_a];
          tween._group = void 0;
          delete this._tweens[tween.getId()];
          delete this._tweensAddedDuringUpdate[tween.getId()];
        }
      };
      Group2.prototype.allStopped = function() {
        return this.getAll().every(function(tween) {
          return !tween.isPlaying();
        });
      };
      Group2.prototype.update = function(time, preserve) {
        if (time === void 0) {
          time = now();
        }
        if (preserve === void 0) {
          preserve = true;
        }
        var tweenIds = Object.keys(this._tweens);
        if (tweenIds.length === 0)
          return;
        while (tweenIds.length > 0) {
          this._tweensAddedDuringUpdate = {};
          for (var i = 0; i < tweenIds.length; i++) {
            var tween = this._tweens[tweenIds[i]];
            var autoStart = !preserve;
            if (tween && tween.update(time, autoStart) === false && !preserve)
              this.remove(tween);
          }
          tweenIds = Object.keys(this._tweensAddedDuringUpdate);
        }
      };
      return Group2;
    })()
  );
  var Interpolation = {
    Linear: function(v, k) {
      var m = v.length - 1;
      var f = m * k;
      var i = Math.floor(f);
      var fn = Interpolation.Utils.Linear;
      if (k < 0) {
        return fn(v[0], v[1], f);
      }
      if (k > 1) {
        return fn(v[m], v[m - 1], m - f);
      }
      return fn(v[i], v[i + 1 > m ? m : i + 1], f - i);
    },
    Bezier: function(v, k) {
      var b = 0;
      var n = v.length - 1;
      var pw = Math.pow;
      var bn = Interpolation.Utils.Bernstein;
      for (var i = 0; i <= n; i++) {
        b += pw(1 - k, n - i) * pw(k, i) * v[i] * bn(n, i);
      }
      return b;
    },
    CatmullRom: function(v, k) {
      var m = v.length - 1;
      var f = m * k;
      var i = Math.floor(f);
      var fn = Interpolation.Utils.CatmullRom;
      if (v[0] === v[m]) {
        if (k < 0) {
          i = Math.floor(f = m * (1 + k));
        }
        return fn(v[(i - 1 + m) % m], v[i], v[(i + 1) % m], v[(i + 2) % m], f - i);
      } else {
        if (k < 0) {
          return v[0] - (fn(v[0], v[0], v[1], v[1], -f) - v[0]);
        }
        if (k > 1) {
          return v[m] - (fn(v[m], v[m], v[m - 1], v[m - 1], f - m) - v[m]);
        }
        return fn(v[i ? i - 1 : 0], v[i], v[m < i + 1 ? m : i + 1], v[m < i + 2 ? m : i + 2], f - i);
      }
    },
    Utils: {
      Linear: function(p0, p1, t) {
        return (p1 - p0) * t + p0;
      },
      Bernstein: function(n, i) {
        var fc = Interpolation.Utils.Factorial;
        return fc(n) / fc(i) / fc(n - i);
      },
      Factorial: /* @__PURE__ */ (function() {
        var a = [1];
        return function(n) {
          var s = 1;
          if (a[n]) {
            return a[n];
          }
          for (var i = n; i > 1; i--) {
            s *= i;
          }
          a[n] = s;
          return s;
        };
      })(),
      CatmullRom: function(p0, p1, p2, p3, t) {
        var v0 = (p2 - p0) * 0.5;
        var v1 = (p3 - p1) * 0.5;
        var t2 = t * t;
        var t3 = t * t2;
        return (2 * p1 - 2 * p2 + v0 + v1) * t3 + (-3 * p1 + 3 * p2 - 2 * v0 - v1) * t2 + v0 * t + p1;
      }
    }
  };
  var Sequence = (
    /** @class */
    (function() {
      function Sequence2() {
      }
      Sequence2.nextId = function() {
        return Sequence2._nextId++;
      };
      Sequence2._nextId = 0;
      return Sequence2;
    })()
  );
  var mainGroup = new Group();
  var Tween = (
    /** @class */
    (function() {
      function Tween2(object3, group) {
        this._isPaused = false;
        this._pauseStart = 0;
        this._valuesStart = {};
        this._valuesEnd = {};
        this._valuesStartRepeat = {};
        this._duration = 1e3;
        this._isDynamic = false;
        this._initialRepeat = 0;
        this._repeat = 0;
        this._yoyo = false;
        this._isPlaying = false;
        this._reversed = false;
        this._delayTime = 0;
        this._startTime = 0;
        this._easingFunction = Easing.Linear.None;
        this._interpolationFunction = Interpolation.Linear;
        this._chainedTweens = [];
        this._onStartCallbackFired = false;
        this._onEveryStartCallbackFired = false;
        this._id = Sequence.nextId();
        this._isChainStopped = false;
        this._propertiesAreSetUp = false;
        this._goToEnd = false;
        this._object = object3;
        if (typeof group === "object") {
          this._group = group;
          group.add(this);
        } else if (group === true) {
          this._group = mainGroup;
          mainGroup.add(this);
        }
      }
      Tween2.prototype.getId = function() {
        return this._id;
      };
      Tween2.prototype.isPlaying = function() {
        return this._isPlaying;
      };
      Tween2.prototype.isPaused = function() {
        return this._isPaused;
      };
      Tween2.prototype.getDuration = function() {
        return this._duration;
      };
      Tween2.prototype.to = function(target, duration) {
        if (duration === void 0) {
          duration = 1e3;
        }
        if (this._isPlaying)
          throw new Error("Can not call Tween.to() while Tween is already started or paused. Stop the Tween first.");
        this._valuesEnd = target;
        this._propertiesAreSetUp = false;
        this._duration = duration < 0 ? 0 : duration;
        return this;
      };
      Tween2.prototype.duration = function(duration) {
        if (duration === void 0) {
          duration = 1e3;
        }
        this._duration = duration < 0 ? 0 : duration;
        return this;
      };
      Tween2.prototype.dynamic = function(dynamic) {
        if (dynamic === void 0) {
          dynamic = false;
        }
        this._isDynamic = dynamic;
        return this;
      };
      Tween2.prototype.start = function(time, overrideStartingValues) {
        if (time === void 0) {
          time = now();
        }
        if (overrideStartingValues === void 0) {
          overrideStartingValues = false;
        }
        if (this._isPlaying) {
          return this;
        }
        this._repeat = this._initialRepeat;
        if (this._reversed) {
          this._reversed = false;
          for (var property in this._valuesStartRepeat) {
            this._swapEndStartRepeatValues(property);
            this._valuesStart[property] = this._valuesStartRepeat[property];
          }
        }
        this._isPlaying = true;
        this._isPaused = false;
        this._onStartCallbackFired = false;
        this._onEveryStartCallbackFired = false;
        this._isChainStopped = false;
        this._startTime = time;
        this._startTime += this._delayTime;
        if (!this._propertiesAreSetUp || overrideStartingValues) {
          this._propertiesAreSetUp = true;
          if (!this._isDynamic) {
            var tmp = {};
            for (var prop in this._valuesEnd)
              tmp[prop] = this._valuesEnd[prop];
            this._valuesEnd = tmp;
          }
          this._setupProperties(this._object, this._valuesStart, this._valuesEnd, this._valuesStartRepeat, overrideStartingValues);
        }
        return this;
      };
      Tween2.prototype.startFromCurrentValues = function(time) {
        return this.start(time, true);
      };
      Tween2.prototype._setupProperties = function(_object, _valuesStart, _valuesEnd, _valuesStartRepeat, overrideStartingValues) {
        for (var property in _valuesEnd) {
          var startValue = _object[property];
          var startValueIsArray = Array.isArray(startValue);
          var propType = startValueIsArray ? "array" : typeof startValue;
          var isInterpolationList = !startValueIsArray && Array.isArray(_valuesEnd[property]);
          if (propType === "undefined" || propType === "function") {
            continue;
          }
          if (isInterpolationList) {
            var endValues = _valuesEnd[property];
            if (endValues.length === 0) {
              continue;
            }
            var temp = [startValue];
            for (var i = 0, l = endValues.length; i < l; i += 1) {
              var value = this._handleRelativeValue(startValue, endValues[i]);
              if (isNaN(value)) {
                isInterpolationList = false;
                console.warn("Found invalid interpolation list. Skipping.");
                break;
              }
              temp.push(value);
            }
            if (isInterpolationList) {
              _valuesEnd[property] = temp;
            }
          }
          if ((propType === "object" || startValueIsArray) && startValue && !isInterpolationList) {
            _valuesStart[property] = startValueIsArray ? [] : {};
            var nestedObject = startValue;
            for (var prop in nestedObject) {
              _valuesStart[property][prop] = nestedObject[prop];
            }
            _valuesStartRepeat[property] = startValueIsArray ? [] : {};
            var endValues = _valuesEnd[property];
            if (!this._isDynamic) {
              var tmp = {};
              for (var prop in endValues)
                tmp[prop] = endValues[prop];
              _valuesEnd[property] = endValues = tmp;
            }
            this._setupProperties(nestedObject, _valuesStart[property], endValues, _valuesStartRepeat[property], overrideStartingValues);
          } else {
            if (typeof _valuesStart[property] === "undefined" || overrideStartingValues) {
              _valuesStart[property] = startValue;
            }
            if (!startValueIsArray) {
              _valuesStart[property] *= 1;
            }
            if (isInterpolationList) {
              _valuesStartRepeat[property] = _valuesEnd[property].slice().reverse();
            } else {
              _valuesStartRepeat[property] = _valuesStart[property] || 0;
            }
          }
        }
      };
      Tween2.prototype.stop = function() {
        if (!this._isChainStopped) {
          this._isChainStopped = true;
          this.stopChainedTweens();
        }
        if (!this._isPlaying) {
          return this;
        }
        this._isPlaying = false;
        this._isPaused = false;
        if (this._onStopCallback) {
          this._onStopCallback(this._object);
        }
        return this;
      };
      Tween2.prototype.end = function() {
        this._goToEnd = true;
        this.update(this._startTime + this._duration);
        return this;
      };
      Tween2.prototype.pause = function(time) {
        if (time === void 0) {
          time = now();
        }
        if (this._isPaused || !this._isPlaying) {
          return this;
        }
        this._isPaused = true;
        this._pauseStart = time;
        return this;
      };
      Tween2.prototype.resume = function(time) {
        if (time === void 0) {
          time = now();
        }
        if (!this._isPaused || !this._isPlaying) {
          return this;
        }
        this._isPaused = false;
        this._startTime += time - this._pauseStart;
        this._pauseStart = 0;
        return this;
      };
      Tween2.prototype.stopChainedTweens = function() {
        for (var i = 0, numChainedTweens = this._chainedTweens.length; i < numChainedTweens; i++) {
          this._chainedTweens[i].stop();
        }
        return this;
      };
      Tween2.prototype.group = function(group) {
        if (!group) {
          console.warn("tween.group() without args has been removed, use group.add(tween) instead.");
          return this;
        }
        group.add(this);
        return this;
      };
      Tween2.prototype.remove = function() {
        var _a;
        (_a = this._group) === null || _a === void 0 ? void 0 : _a.remove(this);
        return this;
      };
      Tween2.prototype.delay = function(amount) {
        if (amount === void 0) {
          amount = 0;
        }
        this._delayTime = amount;
        return this;
      };
      Tween2.prototype.repeat = function(times) {
        if (times === void 0) {
          times = 0;
        }
        this._initialRepeat = times;
        this._repeat = times;
        return this;
      };
      Tween2.prototype.repeatDelay = function(amount) {
        this._repeatDelayTime = amount;
        return this;
      };
      Tween2.prototype.yoyo = function(yoyo) {
        if (yoyo === void 0) {
          yoyo = false;
        }
        this._yoyo = yoyo;
        return this;
      };
      Tween2.prototype.easing = function(easingFunction) {
        if (easingFunction === void 0) {
          easingFunction = Easing.Linear.None;
        }
        this._easingFunction = easingFunction;
        return this;
      };
      Tween2.prototype.interpolation = function(interpolationFunction) {
        if (interpolationFunction === void 0) {
          interpolationFunction = Interpolation.Linear;
        }
        this._interpolationFunction = interpolationFunction;
        return this;
      };
      Tween2.prototype.chain = function() {
        var tweens = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          tweens[_i] = arguments[_i];
        }
        this._chainedTweens = tweens;
        return this;
      };
      Tween2.prototype.onStart = function(callback) {
        this._onStartCallback = callback;
        return this;
      };
      Tween2.prototype.onEveryStart = function(callback) {
        this._onEveryStartCallback = callback;
        return this;
      };
      Tween2.prototype.onUpdate = function(callback) {
        this._onUpdateCallback = callback;
        return this;
      };
      Tween2.prototype.onRepeat = function(callback) {
        this._onRepeatCallback = callback;
        return this;
      };
      Tween2.prototype.onComplete = function(callback) {
        this._onCompleteCallback = callback;
        return this;
      };
      Tween2.prototype.onStop = function(callback) {
        this._onStopCallback = callback;
        return this;
      };
      Tween2.prototype.update = function(time, autoStart) {
        var _this = this;
        var _a;
        if (time === void 0) {
          time = now();
        }
        if (autoStart === void 0) {
          autoStart = Tween2.autoStartOnUpdate;
        }
        if (this._isPaused)
          return true;
        var property;
        if (!this._goToEnd && !this._isPlaying) {
          if (autoStart)
            this.start(time, true);
          else
            return false;
        }
        this._goToEnd = false;
        if (time < this._startTime) {
          return true;
        }
        if (this._onStartCallbackFired === false) {
          if (this._onStartCallback) {
            this._onStartCallback(this._object);
          }
          this._onStartCallbackFired = true;
        }
        if (this._onEveryStartCallbackFired === false) {
          if (this._onEveryStartCallback) {
            this._onEveryStartCallback(this._object);
          }
          this._onEveryStartCallbackFired = true;
        }
        var elapsedTime = time - this._startTime;
        var durationAndDelay = this._duration + ((_a = this._repeatDelayTime) !== null && _a !== void 0 ? _a : this._delayTime);
        var totalTime = this._duration + this._repeat * durationAndDelay;
        var calculateElapsedPortion = function() {
          if (_this._duration === 0)
            return 1;
          if (elapsedTime > totalTime) {
            return 1;
          }
          var timesRepeated = Math.trunc(elapsedTime / durationAndDelay);
          var timeIntoCurrentRepeat = elapsedTime - timesRepeated * durationAndDelay;
          var portion = Math.min(timeIntoCurrentRepeat / _this._duration, 1);
          if (portion === 0 && elapsedTime === _this._duration) {
            return 1;
          }
          return portion;
        };
        var elapsed = calculateElapsedPortion();
        var value = this._easingFunction(elapsed);
        this._updateProperties(this._object, this._valuesStart, this._valuesEnd, value);
        if (this._onUpdateCallback) {
          this._onUpdateCallback(this._object, elapsed);
        }
        if (this._duration === 0 || elapsedTime >= this._duration) {
          if (this._repeat > 0) {
            var completeCount = Math.min(Math.trunc((elapsedTime - this._duration) / durationAndDelay) + 1, this._repeat);
            if (isFinite(this._repeat)) {
              this._repeat -= completeCount;
            }
            for (property in this._valuesStartRepeat) {
              if (!this._yoyo && typeof this._valuesEnd[property] === "string") {
                this._valuesStartRepeat[property] = // eslint-disable-next-line
                // @ts-ignore FIXME?
                this._valuesStartRepeat[property] + parseFloat(this._valuesEnd[property]);
              }
              if (this._yoyo) {
                this._swapEndStartRepeatValues(property);
              }
              this._valuesStart[property] = this._valuesStartRepeat[property];
            }
            if (this._yoyo) {
              this._reversed = !this._reversed;
            }
            this._startTime += durationAndDelay * completeCount;
            if (this._onRepeatCallback) {
              this._onRepeatCallback(this._object);
            }
            this._onEveryStartCallbackFired = false;
            return true;
          } else {
            if (this._onCompleteCallback) {
              this._onCompleteCallback(this._object);
            }
            for (var i = 0, numChainedTweens = this._chainedTweens.length; i < numChainedTweens; i++) {
              this._chainedTweens[i].start(this._startTime + this._duration, false);
            }
            this._isPlaying = false;
            return false;
          }
        }
        return true;
      };
      Tween2.prototype._updateProperties = function(_object, _valuesStart, _valuesEnd, value) {
        for (var property in _valuesEnd) {
          if (_valuesStart[property] === void 0) {
            continue;
          }
          var start = _valuesStart[property] || 0;
          var end = _valuesEnd[property];
          var startIsArray = Array.isArray(_object[property]);
          var endIsArray = Array.isArray(end);
          var isInterpolationList = !startIsArray && endIsArray;
          if (isInterpolationList) {
            _object[property] = this._interpolationFunction(end, value);
          } else if (typeof end === "object" && end) {
            this._updateProperties(_object[property], start, end, value);
          } else {
            end = this._handleRelativeValue(start, end);
            if (typeof end === "number") {
              _object[property] = start + (end - start) * value;
            }
          }
        }
      };
      Tween2.prototype._handleRelativeValue = function(start, end) {
        if (typeof end !== "string") {
          return end;
        }
        if (end.charAt(0) === "+" || end.charAt(0) === "-") {
          return start + parseFloat(end);
        }
        return parseFloat(end);
      };
      Tween2.prototype._swapEndStartRepeatValues = function(property) {
        var tmp = this._valuesStartRepeat[property];
        var endValue = this._valuesEnd[property];
        if (typeof endValue === "string") {
          this._valuesStartRepeat[property] = this._valuesStartRepeat[property] + parseFloat(endValue);
        } else {
          this._valuesStartRepeat[property] = this._valuesEnd[property];
        }
        this._valuesEnd[property] = tmp;
      };
      Tween2.autoStartOnUpdate = false;
      return Tween2;
    })()
  );
  var nextId = Sequence.nextId;
  var TWEEN = mainGroup;
  var getAll = TWEEN.getAll.bind(TWEEN);
  var removeAll = TWEEN.removeAll.bind(TWEEN);
  var add = TWEEN.add.bind(TWEEN);
  var remove = TWEEN.remove.bind(TWEEN);
  var update = TWEEN.update.bind(TWEEN);

  // src/presentation/motion.ts
  var MOTION = {
    placeMs: 100,
    invalidMs: 140,
    noticeMs: 650,
    failMs: 180,
    reduced: { placeMs: 0, invalidMs: 0, noticeMs: 240, failMs: 0 }
  };
  function shipmentTiming(reducedMotion) {
    return reducedMotion ? { routeMs: 0, moveMs: 0, collectMs: 80, totalMs: 80 } : { routeMs: 140, moveMs: 350, collectMs: 160, totalMs: 650 };
  }
  var unit = (n) => Math.max(0, Math.min(1, Number.isFinite(n) ? n : 0));
  var bump = (n) => {
    const p = unit(n);
    return p === 0 || p === 1 ? 0 : Math.sin(p * Math.PI);
  };
  function shipmentFrame(progress, reducedMotion) {
    if (reducedMotion) return { stage: "collect", route: 1, move: 0, collect: unit(progress) };
    const timing = shipmentTiming(false), time = unit(progress) * timing.totalMs;
    return {
      stage: time < timing.routeMs ? "route" : time < timing.routeMs + timing.moveMs ? "move" : "collect",
      route: unit(time / timing.routeMs),
      move: Easing.Quadratic.InOut(unit((time - timing.routeMs) / timing.moveMs)),
      collect: unit((time - timing.routeMs - timing.moveMs) / timing.collectMs)
    };
  }
  function routePose(route2, progress) {
    if (!route2.length) return null;
    const step = unit(progress) * (route2.length - 1), index = Math.floor(step), next = Math.min(route2.length - 1, index + 1);
    const from = cellCenter(route2[index]), to = cellCenter(route2[next]), amount = step - index;
    const headingFrom = next === index ? cellCenter(route2[Math.max(0, index - 1)]) : from;
    return { x: from.x + (to.x - from.x) * amount, y: from.y + (to.y - from.y) * amount, angle: Math.atan2(to.y - headingFrom.y, to.x - headingFrom.x) };
  }
  function dockPosition(dock) {
    const p = cellCenter(dock.entry);
    return {
      x: dock.side === "west" ? L.board.x - 24 : dock.side === "east" ? L.board.x + L.board.size + 24 : p.x,
      y: dock.side === "north" ? L.board.y - 10 : dock.side === "south" ? L.board.y + L.board.size + 15 : p.y
    };
  }
  function collectPose(source2, target, progress, reducedMotion) {
    if (reducedMotion) return { ...source2, scale: 1 };
    const p = unit(progress), travel = Easing.Cubic.InOut(unit((p - 0.22) / 0.78));
    const lift = p < 0.22 ? 12 * Easing.Quadratic.Out(p / 0.22) : 12 * (1 - travel);
    return { x: source2.x + (target.x - source2.x) * travel, y: source2.y + (target.y - source2.y) * travel - lift, scale: 1 - 0.94 * travel };
  }
  function chainFeedback(chain) {
    const level = Math.max(1, Math.min(4, Math.floor(chain) || 1));
    return { particles: [4, 7, 10, 12][level - 1], dust: level + 2, flash: 0.1 + level * 0.04, fontSize: 32 + level * 4, pulse: level === 4 };
  }
  function feedbackParticles(origin, chain, progress, stage, reducedMotion = false) {
    if (reducedMotion) return [];
    const p = unit(progress);
    if (p <= 0 || p >= 1) return [];
    const feedback = chainFeedback(chain), count = stage === "move" ? feedback.dust : feedback.particles;
    return Array.from({ length: count }, (_, index) => {
      const angle = index * 2.399963229728653 + (stage === "move" ? Math.PI : 0);
      const distance = (stage === "move" ? 7 + p * 20 : 9 + p * 48) + index % 3;
      return {
        x: origin.x + Math.cos(angle) * distance,
        y: origin.y + Math.sin(angle) * distance,
        radius: stage === "move" ? 2 + index % 2 : 3 + index % 3,
        alpha: (stage === "move" ? 0.28 : 0.46) * bump(p)
      };
    });
  }
  function placementPose(progress, reducedMotion) {
    const amount = reducedMotion ? 0 : bump(progress);
    return { x: 1 + amount * 0.04, y: 1 - amount * 0.08 };
  }
  function reboundOffset(progress, reducedMotion) {
    return reducedMotion || bump(progress) === 0 ? 0 : -8 * bump(progress);
  }

  // src/domain/rulesets/v1/content.ts
  var P0_CONFIG = {
    balanced: false,
    rulesetVersion: 1,
    runConfigId: "run.standard_p0_v1",
    boardSize: 7,
    candidateCount: 3,
    shiftCount: 5,
    ordersPerShift: 6,
    upgradeEvery: 4,
    resolutionLimit: 64,
    docksByShift: [2, 3, 3, 4, 4],
    cargoByShift: [3, 3, 4, 5, 5],
    orderMinByShift: [3, 3, 4, 4, 5],
    orderMaxByShift: [4, 5, 5, 6, 7],
    score: { orderBase: 100, orderPerShift: 25, overfill: 12, routeDepth: 5, chainPercent: 25, shiftBonus: 200 },
    upgrade: { overfill: 12, deepRoute: 8, chainPercent: 20, contract: 40, variety: 65, smallWeightPercent: 60 },
    generation: { occupancySmallPercent: 200, recentShapeDivisor: 2, cargoPresenceWeight: 2 }
  };
  var CARGO = [
    { id: "cargo.food", name: "\u98DF\u54C1", color: "#e9584b", icon: "apple" },
    { id: "cargo.machine", name: "\u673A\u68B0", color: "#76a74d", icon: "gear" },
    { id: "cargo.chem", name: "\u5316\u5DE5", color: "#efb938", icon: "warning" },
    { id: "cargo.electronic", name: "\u7535\u5B50", color: "#8f70d1", icon: "chip" },
    { id: "cargo.cold", name: "\u51B7\u85CF", color: "#59b5e7", icon: "snow" }
  ];
  var shape = (id2, points, minShift, weight) => ({ id: `shape.${id2}`, cells: points.map(([x, y]) => ({ x, y })), minShift, weight });
  var SHAPES = [
    shape("single", [[0, 0]], 1, 22),
    shape("domino_h", [[0, 0], [1, 0]], 1, 18),
    shape("domino_v", [[0, 0], [0, 1]], 1, 18),
    shape("i3_h", [[0, 0], [1, 0], [2, 0]], 1, 12),
    shape("i3_v", [[0, 0], [0, 1], [0, 2]], 1, 12),
    shape("l3_ne", [[0, 0], [1, 0], [0, 1]], 1, 10),
    shape("l3_nw", [[0, 0], [1, 0], [1, 1]], 1, 10),
    shape("l3_se", [[0, 0], [0, 1], [1, 1]], 1, 10),
    shape("l3_sw", [[1, 0], [0, 1], [1, 1]], 1, 10),
    shape("square", [[0, 0], [1, 0], [0, 1], [1, 1]], 2, 10),
    shape("i4_h", [[0, 0], [1, 0], [2, 0], [3, 0]], 2, 6),
    shape("i4_v", [[0, 0], [0, 1], [0, 2], [0, 3]], 2, 6),
    shape("t4_n", [[0, 0], [1, 0], [2, 0], [1, 1]], 2, 8),
    shape("t4_s", [[1, 0], [0, 1], [1, 1], [2, 1]], 2, 8),
    shape("l4_e", [[0, 0], [0, 1], [0, 2], [1, 2]], 2, 7),
    shape("l4_w", [[1, 0], [1, 1], [0, 2], [1, 2]], 2, 7),
    shape("s4_h", [[1, 0], [2, 0], [0, 1], [1, 1]], 3, 5),
    shape("z4_h", [[0, 0], [1, 0], [1, 1], [2, 1]], 3, 5),
    shape("p5", [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2]], 4, 3),
    shape("cross5", [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]], 4, 3)
  ];
  var DOCKS = [
    { id: "dock.north", name: "\u5317\u95E8", entry: { x: 3, y: 0 }, side: "north", priority: 0 },
    { id: "dock.east", name: "\u4E1C\u95E8", entry: { x: 6, y: 3 }, side: "east", priority: 1 },
    { id: "dock.south", name: "\u5357\u95E8", entry: { x: 3, y: 6 }, side: "south", priority: 2 },
    { id: "dock.west", name: "\u897F\u95E8", entry: { x: 0, y: 3 }, side: "west", priority: 3 }
  ];
  var UPGRADES = [
    { id: "upgrade.overfill", title: "\u8D85\u989D\u88C5\u8F7D", description: "\u6BCF\u4E2A\u8D85\u989D\u8D27\u7BB1\u518D\u52A012\u5206\uFF0C\u53EF\u53E0\u52A0", color: "#f4b85e", maxStack: 99, effect: "overfill" },
    { id: "upgrade.deep_route", title: "\u6DF1\u5165\u4ED3\u5E93", description: "\u8DEF\u7EBF\u81F3\u5C113\u6B65\u65F6\uFF0C\u6BCF\u6B65\u518D\u52A08\u5206", color: "#74b9db", maxStack: 3, effect: "deep_route" },
    { id: "upgrade.small_parcels", title: "\u5C0F\u4EF6\u8865\u7ED9", description: "\u540E\u7EED1\u20132\u683C\u8D27\u4EF6\u7684\u57FA\u7840\u6743\u91CD\u589E\u52A060%", color: "#81c89b", maxStack: 3, effect: "small_parcels" },
    { id: "upgrade.chain", title: "\u8FDE\u9501\u52A0\u901F", description: "\u6BCF\u5C42\u8FDE\u9501\u7684\u500D\u7387\u518D\u589E\u52A020\u4E2A\u767E\u5206\u70B9", color: "#e7a4a7", maxStack: 99, effect: "chain" },
    { id: "upgrade.contract", title: "\u4F18\u8D28\u5408\u7EA6", description: "\u6BCF\u5F20\u5B8C\u6210\u8BA2\u5355\u518D\u52A040\u57FA\u7840\u5206", color: "#d7bf75", maxStack: 99, effect: "contract" },
    { id: "upgrade.variety", title: "\u591A\u54C1\u8054\u8FD0", description: "\u540C\u6B21\u8FDE\u9501\u66F4\u6362\u8D27\u7269\u7C7B\u522B\u65F6\u518D\u52A065\u5206", color: "#ba9eda", maxStack: 3, effect: "variety" }
  ];

  // src/domain/v2/content.ts
  var RULES_V2_CONFIG = {
    ...P0_CONFIG,
    balanced: false,
    rulesetVersion: 2,
    runConfigId: "run.standard_v2",
    special: { minShift: 3, weights: { normal: 88, pallet: 5, rush: 3, hazard: 3, wildcard: 1 }, rushTurns: 3 },
    sideEntry: { x: 0, y: 6 }
  };
  var source = (section) => `docs/research/01-rules.md#${section}`;
  function upgrade(id2, title, description, effect, behavior, maxStack, minShift, tags, params, sourceSection, provisional = false) {
    return {
      id: `upgrade.${id2}`,
      title,
      description,
      color: behavior ? "#81c89b" : "#d7bf75",
      effect,
      behavior,
      maxStack,
      minShift,
      tags,
      prerequisites: [],
      conflicts: [],
      params: { baseWeight: 100, ...params },
      sourceRef: source(sourceSection),
      provisional
    };
  }
  var UPGRADES_V2 = [
    upgrade("overfill", "\u8D85\u989D\u88C5\u8F7D", "\u6BCF\u4E2A\u8D85\u989D\u8BA2\u5355\u5355\u4F4D\u518D\u52A012\u5206\uFF0C\u53EF\u53E0\u52A0", "overfill", false, 99, 1, ["score", "order"], { points: 12 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8BA2\u5355\u7C7B/\u8D85\u989D\u88C5\u8F7D\u6536\u76CA"),
    upgrade("deep_route", "\u6DF1\u5165\u4ED3\u5E93", "\u8DEF\u7EBF\u81F3\u5C113\u6B65\u65F6\uFF0C\u6BCF\u6B65\u518D\u52A08\u5206", "deep_route", false, 3, 1, ["score", "route"], { points: 8, minDepth: 3 }, "Roguelite\u5347\u7EA7\u539F\u5219/Combo\u7C7B/\u6DF1\u8DEF\u7EBF\u5956\u52B1"),
    upgrade("small_parcels", "\u5C0F\u4EF6\u8865\u7ED9", "\u540E\u7EED1\u20132\u683C\u666E\u901A\u8D27\u4EF6\u7684\u57FA\u7840\u6743\u91CD\u589E\u52A060%", "small_parcels", true, 3, 1, ["generation", "piece"], { weightPercent: 60 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8D27\u4EF6\u7C7B/\u5C0F\u4EF6\u6743\u91CD"),
    upgrade("chain", "\u8FDE\u9501\u52A0\u901F", "\u6BCF\u5C42\u8FDE\u9501\u7684\u500D\u7387\u518D\u589E\u52A020\u4E2A\u767E\u5206\u70B9", "chain", false, 99, 1, ["score", "chain"], { percent: 20 }, "Chain/\u771F\u5B9E\u6E05\u8DEF\u7EA7\u8054\uFF1BScore/ChainMultiplier"),
    upgrade("contract", "\u4F18\u8D28\u5408\u7EA6", "\u6BCF\u5F20\u5B8C\u6210\u8BA2\u5355\u518D\u52A040\u57FA\u7840\u5206", "contract", false, 99, 1, ["score", "order"], { points: 40 }, "\u8BA2\u5355\u4E0E\u53C9\u8F66\u901A\u8DEF/Dock/\u8BA2\u5355\u57FA\u7840\u5206\u503C"),
    upgrade("variety", "\u591A\u54C1\u8054\u8FD0", "\u540C\u6B21\u8FDE\u9501\u66F4\u6362\u8D27\u7269\u7C7B\u522B\u65F6\u518D\u52A065\u5206", "variety", false, 3, 1, ["score", "chain"], { points: 65 }, "Roguelite\u5347\u7EA7\u539F\u5219/Combo\u7C7B/\u4E0D\u540C\u7C7B\u522B\u5956\u52B1"),
    upgrade("side_gate", "\u897F\u5357\u4FA7\u95E8", "\u6574\u5C40\u589E\u52A0\u897F\u5357\u7A7A\u683C(0,6)\u5165\u53E3\uFF1B\u5404Dock\u9009\u62E9\u6700\u77ED\u901A\u8DEF", "side_gate", true, 1, 1, ["route", "entry"], { x: RULES_V2_CONFIG.sideEntry.x, y: RULES_V2_CONFIG.sideEntry.y }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8DEF\u7EBF\u7C7B/\u4E34\u65F6\u4FA7\u5165\u53E3\uFF08\u6574\u5C40\u4F5C\u7528\u57DF\u4E3A\u672C\u6279\u63D0\u6848\uFF09", true),
    upgrade("pallet_pass", "\u6258\u76D8\u901A\u884C", "\u6BCF\u6B21\u653E\u7F6E\u9996\u5355\u7684\u8DEF\u7EBF\u53EF\u7A7F\u8FC71\u4E2A\u975E\u76EE\u6807\u6258\u76D8\uFF0C\u6258\u76D8\u4FDD\u7559", "pallet_pass", true, 1, 3, ["route", "pallet"], { maxPallets: 1 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8DEF\u7EBF\u7C7B/\u8DEF\u7EBF\u4F8B\u5916\uFF1B\u7279\u6B8A\u8D27\u4EF6/Pallet", true),
    upgrade("small_order_first", "\u5C0F\u5355\u5148\u884C", "\u65E7\u8BA2\u5355\u6309\u6700\u4F4E\u6570\u91CF\u4F18\u5148\uFF0C\u5176\u6B21\u6570\u91CF\u76F8\u540C\u6309\u539FDock\u987A\u5E8F", "small_order_first", true, 1, 1, ["order", "priority"], { priorityAmount: 1 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u53C9\u8F66\u7C7B/Dock\u7ED3\u7B97\u5148\u540E\u9009\u62E9", true),
    upgrade("light_orders", "\u8F7B\u91CF\u8BA2\u5355", "\u4E4B\u540E\u65B0\u8BA2\u5355\u7684\u9700\u6C42\u6570\u91CF\u51CF\u5C111\uFF0C\u6700\u4F4E2\uFF1B\u65E7\u5355\u4E0D\u53D8", "light_orders", true, 1, 1, ["order", "generation"], { reduction: 1, floor: 2 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8BA2\u5355\u7C7B/\u53EF\u9009\u8BA2\u5355\uFF08\u6570\u91CF\u5206\u5E03\u63D0\u6848\uFF09", true),
    upgrade("stock_orders", "\u5E93\u5B58\u5408\u7EA6", "\u65B0\u8BA2\u5355\u6309\u5DF2\u6709\u5E93\u5B58\u52A0\u6743\u8D27\u7C7B\uFF0C\u4ECD\u4E0D\u91CD\u590D\u3001\u4E0D\u4FDD\u8BC1\u53EF\u5B8C\u6210", "stock_orders", true, 1, 1, ["order", "generation"], { baseCargoWeight: 20, unitWeight: 8 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8BA2\u5355\u7C7B/\u53EF\u9009\u8BA2\u5355\uFF1B04-contract/PieceGenerator/\u5F53\u524D\u8D27\u7269\u5206\u5E03", true),
    upgrade("four_choices", "\u56DB\u4EF6\u5019\u9009", "\u7ACB\u5373\u589E\u52A0\u7B2C4\u4EF6\u5019\u9009\uFF0C\u5168\u90E8\u5019\u9009\u5747\u65E0\u5904\u53EF\u653E\u624D\u7206\u4ED3", "four_choices", true, 1, 1, ["piece", "generation"], { candidateCount: 4 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u8D27\u4EF6\u7C7B/\u56DB\u9009\u4E00", true),
    upgrade("pallet_supply", "\u6258\u76D8\u8865\u7ED9", "Shift3\u8D77\u6BCF\u7B2C4\u6B21\u751F\u6210\u56FA\u5B9A\u4E3A\u5355\u683C\u6258\u76D8", "pallet_supply", true, 1, 3, ["piece", "generation", "pallet"], { interval: 4 }, "\u7279\u6B8A\u8D27\u4EF6/Pallet\uFF1B04-contract/PieceGenerator/\u7279\u6B8A\u8D27\u4EF6\u8282\u594F", true),
    upgrade("rush_buffer", "\u52A0\u6025\u7F13\u51B2", "\u4E4B\u540E\u751F\u6210\u7684\u52A0\u6025\u8D27\u4EF6\u589E\u52A02\u6B21\u6709\u6548\u653E\u7F6E\u671F\u9650", "rush_buffer", true, 1, 3, ["piece", "rush"], { extraTurns: 2 }, "\u7279\u6B8A\u8D27\u4EF6/Rush/\u591A\u6B21\u64CD\u4F5C\u4ECD\u672A\u51FA\u5E93\u4F1A\u53D8\u5360\u4F4D\u969C\u788D", true),
    upgrade("hazard_clearance", "\u5371\u9669\u54C1\u6E05\u969C", "\u5371\u9669\u54C1\u51FA\u8D27\u65F6\u6700\u591A\u6E052\u4E2A\u8D27\u7EC4\u76F8\u90BB\u5E9F\u5F03\u7269", "hazard_clearance", true, 1, 3, ["clear", "hazard"], { maxWaste: 2 }, "\u7279\u6B8A\u8D27\u4EF6/Hazard\uFF1BRoguelite\u5347\u7EA7\u539F\u5219/\u53C9\u8F66\u7C7B/\u6E05\u969C", true),
    upgrade("wild_supply", "\u4E07\u80FD\u8865\u7ED9", "\u4E07\u80FD\u751F\u6210\u6743\u91CD\u75311\u589E\u81F33\uFF0C\u666E\u901A\u7B49\u91CF\u51CF\u5C11\uFF0C\u4ECD\u4F4E\u9891", "wild_supply", true, 1, 3, ["piece", "generation", "wildcard"], { weightBonus: 2 }, "\u7279\u6B8A\u8D27\u4EF6/Wildcard/\u751F\u6210\u7387\u6781\u4F4E\uFF1BRoguelite\u5347\u7EA7\u539F\u5219/\u8D27\u4EF6\u7C7B/\u4F4E\u9891\u4E07\u80FD\u6258\u76D8", true),
    upgrade("sweep_route", "\u8DEF\u7EBF\u6E05\u626B", "\u6BCF\u6B21\u653E\u7F6E\u9996\u5355\u540E\u6E05\u7406\u8DEF\u7EBF\u65C1\u626B\u63CF\u5E8F\u7B2C1\u4E2A\u5E9F\u5F03\u7269", "sweep_route", true, 1, 1, ["route", "clear"], { maxWaste: 1 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u53C9\u8F66\u7C7B/\u6E05\u969C", true),
    upgrade("extra_pickup", "\u987A\u8DEF\u642C\u8FD0", "\u6BCF\u6B21\u653E\u7F6E\u9996\u5355\u540E\u6E05\u8DEF\u7EBF\u65C1\u7B2C1\u683C\u975E\u76EE\u6807\u666E\u901A\u8D27\u7269\uFF1B\u4E0D\u8BA1\u51FA\u8D27\u5206", "extra_pickup", true, 1, 1, ["route", "clear"], { maxCargo: 1 }, "Roguelite\u5347\u7EA7\u539F\u5219/\u53C9\u8F66\u7C7B/\u4E00\u6B21\u989D\u5916\u642C\u8FD0", true)
  ];
  var EFFECTS_V2 = UPGRADES_V2.map((upgrade2) => upgrade2.effect);
  function upgradeStackV2(state, effect) {
    return state.upgrades.filter((id2) => id2 === `upgrade.${effect}`).length;
  }
  function upgradeParamV2(effect, param) {
    var _a, _b;
    const value = (_b = (_a = UPGRADES_V2.find((upgrade2) => upgrade2.effect === effect)) == null ? void 0 : _a.params) == null ? void 0 : _b[param];
    if (value === void 0) throw new Error(`Missing v2 upgrade parameter: ${effect}.${param}`);
    return value;
  }

  // src/domain/v3/content.ts
  var RULES_V3_CONFIG = {
    ...RULES_V2_CONFIG,
    rulesetVersion: 3,
    runConfigId: "run.standard_v3",
    tutorial: {
      origins: [{ x: 1, y: 1 }, { x: 3, y: 1 }, { x: 3, y: 4 }],
      lessonFoodCells: [42, 43, 44],
      lessonWallCells: [21, 22, 23, 24, 25, 26, 27],
      foodAmount: 3,
      machineAmount: 8
    }
  };

  // src/domain/content.ts
  var CURRENT_RULESET = 3;

  // src/domain/rulesets/v1/board.ts
  var BOARD_SIZE = P0_CONFIG.boardSize;
  var toIndex = (point2) => point2.y * BOARD_SIZE + point2.x;
  var toPoint = (index) => ({ x: index % BOARD_SIZE, y: Math.floor(index / BOARD_SIZE) });
  function neighbors(index) {
    const x = index % BOARD_SIZE, y = Math.floor(index / BOARD_SIZE), out = [];
    if (y > 0) out.push(index - BOARD_SIZE);
    if (x < BOARD_SIZE - 1) out.push(index + 1);
    if (y < BOARD_SIZE - 1) out.push(index + BOARD_SIZE);
    if (x > 0) out.push(index - 1);
    return out;
  }
  function collectGroups(board) {
    const visited = /* @__PURE__ */ new Set(), groups = [];
    for (let i = 0; i < board.length; i++) {
      const cargo = board[i];
      if (cargo === null || visited.has(i)) continue;
      const cells = [i];
      visited.add(i);
      for (let cursor = 0; cursor < cells.length; cursor++) for (const next of neighbors(cells[cursor])) {
        if (board[next] === cargo && !visited.has(next)) {
          visited.add(next);
          cells.push(next);
        }
      }
      cells.sort((a, b) => a - b);
      groups.push({ cargo, cells });
    }
    return groups;
  }
  function findRoute(board, dock, cells) {
    const start = toIndex(dock.entry);
    if (board[start] !== null) return null;
    const targets = new Set(cells.flatMap(neighbors).filter((index) => board[index] === null));
    const queue = [start], parent = /* @__PURE__ */ new Map();
    parent.set(start, -1);
    for (let cursor = 0; cursor < queue.length; cursor++) {
      const current = queue[cursor];
      if (targets.has(current)) {
        const route2 = [];
        let step = current;
        while (step !== -1) {
          route2.push(toPoint(step));
          step = parent.get(step);
        }
        return route2.reverse();
      }
      for (const next of neighbors(current)) if (board[next] === null && !parent.has(next)) {
        parent.set(next, current);
        queue.push(next);
      }
    }
    return null;
  }
  function selectOrderGroup(board, order) {
    var _a;
    const dock = DOCKS.find((d) => d.id === order.dockId);
    if (!dock) return null;
    const eligible = [];
    for (const group of collectGroups(board)) {
      if (group.cargo !== order.cargo || group.cells.length < order.amount) continue;
      const path = findRoute(board, dock, group.cells);
      if (path) eligible.push({ group, path });
    }
    eligible.sort((a, b) => a.path.length - b.path.length || b.group.cells.length - a.group.cells.length || a.group.cells[0] - b.group.cells[0]);
    return (_a = eligible[0]) != null ? _a : null;
  }
  function orderStatus(state, order) {
    var _a;
    const count = Math.max(0, ...collectGroups(state.board).filter((g) => g.cargo === order.cargo).map((g) => g.cells.length));
    if (count < order.amount) return { count, status: "need", path: [] };
    const selected = selectOrderGroup(state.board, order);
    return { count, status: selected ? "ready" : "blocked", path: (_a = selected == null ? void 0 : selected.path) != null ? _a : [] };
  }

  // src/domain/v2/board.ts
  function cellUnitsV2(state, index) {
    var _a, _b, _c, _d;
    if (state.board[index] === null || ((_b = (_a = state.cellTraits) == null ? void 0 : _a[index]) == null ? void 0 : _b.kind) === "waste") return 0;
    return ((_d = (_c = state.cellTraits) == null ? void 0 : _c[index]) == null ? void 0 : _d.kind) === "pallet" ? 2 : 1;
  }
  function collectGroupsV2(state, cargo) {
    const eligible = (index) => {
      var _a, _b, _c, _d;
      return state.board[index] !== null && ((_b = (_a = state.cellTraits) == null ? void 0 : _a[index]) == null ? void 0 : _b.kind) !== "waste" && (state.board[index] === cargo || ((_d = (_c = state.cellTraits) == null ? void 0 : _c[index]) == null ? void 0 : _d.kind) === "wildcard");
    };
    const groups = [], visited = /* @__PURE__ */ new Set();
    for (let i = 0; i < state.board.length; i++) {
      if (!eligible(i) || visited.has(i)) continue;
      const cells = [i];
      visited.add(i);
      for (let cursor = 0; cursor < cells.length; cursor++) for (const next of neighbors(cells[cursor])) if (eligible(next) && !visited.has(next)) {
        visited.add(next);
        cells.push(next);
      }
      cells.sort((a, b) => a - b);
      groups.push({ cargo, cells, units: cells.reduce((sum, index) => sum + cellUnitsV2(state, index), 0) });
    }
    return groups;
  }
  function routeFrom(state, entry, cells, allowPallet) {
    var _a, _b;
    const start = toIndex(entry);
    if (state.board[start] !== null) return null;
    const group = new Set(cells), targets = new Set(cells.flatMap(neighbors).filter((i) => state.board[i] === null));
    const queue = [start], parent = /* @__PURE__ */ new Map([[start, -1]]);
    for (let cursor = 0; cursor < queue.length; cursor++) {
      const key = queue[cursor], current = key % 49, used = key >= 49;
      if (targets.has(current)) {
        const path = [];
        let step = key;
        while (step !== -1) {
          path.push(toPoint(step % 49));
          step = parent.get(step);
        }
        return { path: path.reverse(), usedPalletPass: used };
      }
      for (const next of neighbors(current)) {
        const isPallet = ((_b = (_a = state.cellTraits) == null ? void 0 : _a[next]) == null ? void 0 : _b.kind) === "pallet" && !group.has(next);
        if (state.board[next] !== null && !(allowPallet && !used && isPallet)) continue;
        const nextKey = next + (used || state.board[next] !== null ? 49 : 0);
        if (!parent.has(nextKey)) {
          parent.set(nextKey, key);
          queue.push(nextKey);
        }
      }
    }
    return null;
  }
  function findRouteV2(state, dock, cells, allowPallet = false) {
    const original = routeFrom(state, dock.entry, cells, allowPallet);
    if (!upgradeStackV2(state, "side_gate")) return original;
    const side = routeFrom(state, RULES_V2_CONFIG.sideEntry, cells, allowPallet);
    return side && (!original || side.path.length < original.path.length) ? side : original;
  }
  function selectOrderGroupV2(state, order, allowPallet = upgradeStackV2(state, "pallet_pass") > 0) {
    var _a;
    const dock = DOCKS.find((d) => d.id === order.dockId);
    if (!dock) return null;
    const eligible = [];
    for (const group of collectGroupsV2(state, order.cargo)) {
      if (group.units < order.amount) continue;
      const route2 = findRouteV2(state, dock, group.cells, allowPallet);
      if (route2) eligible.push({ group, ...route2 });
    }
    eligible.sort((a, b) => a.path.length - b.path.length || b.group.units - a.group.units || a.group.cells[0] - b.group.cells[0]);
    return (_a = eligible[0]) != null ? _a : null;
  }
  function orderStatusV2(state, order) {
    const count = Math.max(0, ...collectGroupsV2(state, order.cargo).map((group) => group.units));
    if (count < order.amount) return { count, status: "need", path: [], reason: "insufficient" };
    const selected = selectOrderGroupV2(state, order);
    if (selected) return { count, status: "ready", path: selected.path, reason: "ready" };
    const dock = DOCKS.find((d) => d.id === order.dockId);
    const entryBlocked = !dock || state.board[toIndex(dock.entry)] !== null;
    const sideBlocked = !upgradeStackV2(state, "side_gate") || state.board[toIndex(RULES_V2_CONFIG.sideEntry)] !== null;
    return { count, status: "blocked", path: [], reason: entryBlocked && sideBlocked ? "entry-blocked" : "route-blocked" };
  }

  // node_modules/pure-rand/lib/esm/generator/LinearCongruential.js
  var MULTIPLIER = 214013;
  var INCREMENT = 2531011;
  var MASK = 4294967295;
  var MASK_2 = (1 << 31) - 1;
  var computeNextSeed = function(seed) {
    return seed * MULTIPLIER + INCREMENT & MASK;
  };
  var computeValueFromNextSeed = function(nextseed) {
    return (nextseed & MASK_2) >> 16;
  };
  var LinearCongruential32 = (function() {
    function LinearCongruential322(seed) {
      this.seed = seed;
    }
    LinearCongruential322.prototype.clone = function() {
      return new LinearCongruential322(this.seed);
    };
    LinearCongruential322.prototype.next = function() {
      var nextRng = new LinearCongruential322(this.seed);
      var out = nextRng.unsafeNext();
      return [out, nextRng];
    };
    LinearCongruential322.prototype.unsafeNext = function() {
      var s1 = computeNextSeed(this.seed);
      var v1 = computeValueFromNextSeed(s1);
      var s2 = computeNextSeed(s1);
      var v2 = computeValueFromNextSeed(s2);
      this.seed = computeNextSeed(s2);
      var v3 = computeValueFromNextSeed(this.seed);
      var vnext = v3 + (v2 + (v1 << 15) << 15);
      return vnext | 0;
    };
    LinearCongruential322.prototype.getState = function() {
      return [this.seed];
    };
    return LinearCongruential322;
  })();
  function fromState(state) {
    var valid = state.length === 1;
    if (!valid) {
      throw new Error("The state must have been produced by a congruential32 RandomGenerator");
    }
    return new LinearCongruential32(state[0]);
  }
  var congruential32 = Object.assign(function(seed) {
    return new LinearCongruential32(seed);
  }, { fromState });

  // node_modules/pure-rand/lib/esm/generator/MersenneTwister.js
  var __read = function(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
      while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    } catch (error) {
      e = { error };
    } finally {
      try {
        if (r && !r.done && (m = i["return"])) m.call(i);
      } finally {
        if (e) throw e.error;
      }
    }
    return ar;
  };
  var __spreadArray = function(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
  var MersenneTwister = (function() {
    function MersenneTwister2(states, index) {
      this.states = states;
      this.index = index;
    }
    MersenneTwister2.twist = function(prev) {
      var mt = prev.slice();
      for (var idx = 0; idx !== MersenneTwister2.N - MersenneTwister2.M; ++idx) {
        var y_1 = (mt[idx] & MersenneTwister2.MASK_UPPER) + (mt[idx + 1] & MersenneTwister2.MASK_LOWER);
        mt[idx] = mt[idx + MersenneTwister2.M] ^ y_1 >>> 1 ^ -(y_1 & 1) & MersenneTwister2.A;
      }
      for (var idx = MersenneTwister2.N - MersenneTwister2.M; idx !== MersenneTwister2.N - 1; ++idx) {
        var y_2 = (mt[idx] & MersenneTwister2.MASK_UPPER) + (mt[idx + 1] & MersenneTwister2.MASK_LOWER);
        mt[idx] = mt[idx + MersenneTwister2.M - MersenneTwister2.N] ^ y_2 >>> 1 ^ -(y_2 & 1) & MersenneTwister2.A;
      }
      var y = (mt[MersenneTwister2.N - 1] & MersenneTwister2.MASK_UPPER) + (mt[0] & MersenneTwister2.MASK_LOWER);
      mt[MersenneTwister2.N - 1] = mt[MersenneTwister2.M - 1] ^ y >>> 1 ^ -(y & 1) & MersenneTwister2.A;
      return mt;
    };
    MersenneTwister2.seeded = function(seed) {
      var out = Array(MersenneTwister2.N);
      out[0] = seed;
      for (var idx = 1; idx !== MersenneTwister2.N; ++idx) {
        var xored = out[idx - 1] ^ out[idx - 1] >>> 30;
        out[idx] = Math.imul(MersenneTwister2.F, xored) + idx | 0;
      }
      return out;
    };
    MersenneTwister2.from = function(seed) {
      return new MersenneTwister2(MersenneTwister2.twist(MersenneTwister2.seeded(seed)), 0);
    };
    MersenneTwister2.prototype.clone = function() {
      return new MersenneTwister2(this.states, this.index);
    };
    MersenneTwister2.prototype.next = function() {
      var nextRng = new MersenneTwister2(this.states, this.index);
      var out = nextRng.unsafeNext();
      return [out, nextRng];
    };
    MersenneTwister2.prototype.unsafeNext = function() {
      var y = this.states[this.index];
      y ^= this.states[this.index] >>> MersenneTwister2.U;
      y ^= y << MersenneTwister2.S & MersenneTwister2.B;
      y ^= y << MersenneTwister2.T & MersenneTwister2.C;
      y ^= y >>> MersenneTwister2.L;
      if (++this.index >= MersenneTwister2.N) {
        this.states = MersenneTwister2.twist(this.states);
        this.index = 0;
      }
      return y;
    };
    MersenneTwister2.prototype.getState = function() {
      return __spreadArray([this.index], __read(this.states), false);
    };
    MersenneTwister2.fromState = function(state) {
      var valid = state.length === MersenneTwister2.N + 1 && state[0] >= 0 && state[0] < MersenneTwister2.N;
      if (!valid) {
        throw new Error("The state must have been produced by a mersenne RandomGenerator");
      }
      return new MersenneTwister2(state.slice(1), state[0]);
    };
    MersenneTwister2.N = 624;
    MersenneTwister2.M = 397;
    MersenneTwister2.R = 31;
    MersenneTwister2.A = 2567483615;
    MersenneTwister2.F = 1812433253;
    MersenneTwister2.U = 11;
    MersenneTwister2.S = 7;
    MersenneTwister2.B = 2636928640;
    MersenneTwister2.T = 15;
    MersenneTwister2.C = 4022730752;
    MersenneTwister2.L = 18;
    MersenneTwister2.MASK_LOWER = Math.pow(2, MersenneTwister2.R) - 1;
    MersenneTwister2.MASK_UPPER = Math.pow(2, MersenneTwister2.R);
    return MersenneTwister2;
  })();
  function fromState2(state) {
    return MersenneTwister.fromState(state);
  }
  var mersenne = Object.assign(function(seed) {
    return MersenneTwister.from(seed);
  }, { fromState: fromState2 });

  // node_modules/pure-rand/lib/esm/generator/XorShift.js
  var XorShift128Plus = (function() {
    function XorShift128Plus2(s01, s00, s11, s10) {
      this.s01 = s01;
      this.s00 = s00;
      this.s11 = s11;
      this.s10 = s10;
    }
    XorShift128Plus2.prototype.clone = function() {
      return new XorShift128Plus2(this.s01, this.s00, this.s11, this.s10);
    };
    XorShift128Plus2.prototype.next = function() {
      var nextRng = new XorShift128Plus2(this.s01, this.s00, this.s11, this.s10);
      var out = nextRng.unsafeNext();
      return [out, nextRng];
    };
    XorShift128Plus2.prototype.unsafeNext = function() {
      var a0 = this.s00 ^ this.s00 << 23;
      var a1 = this.s01 ^ (this.s01 << 23 | this.s00 >>> 9);
      var b0 = a0 ^ this.s10 ^ (a0 >>> 18 | a1 << 14) ^ (this.s10 >>> 5 | this.s11 << 27);
      var b1 = a1 ^ this.s11 ^ a1 >>> 18 ^ this.s11 >>> 5;
      var out = this.s00 + this.s10 | 0;
      this.s01 = this.s11;
      this.s00 = this.s10;
      this.s11 = b1;
      this.s10 = b0;
      return out;
    };
    XorShift128Plus2.prototype.jump = function() {
      var nextRng = new XorShift128Plus2(this.s01, this.s00, this.s11, this.s10);
      nextRng.unsafeJump();
      return nextRng;
    };
    XorShift128Plus2.prototype.unsafeJump = function() {
      var ns01 = 0;
      var ns00 = 0;
      var ns11 = 0;
      var ns10 = 0;
      var jump = [1667051007, 2321340297, 1548169110, 304075285];
      for (var i = 0; i !== 4; ++i) {
        for (var mask = 1; mask; mask <<= 1) {
          if (jump[i] & mask) {
            ns01 ^= this.s01;
            ns00 ^= this.s00;
            ns11 ^= this.s11;
            ns10 ^= this.s10;
          }
          this.unsafeNext();
        }
      }
      this.s01 = ns01;
      this.s00 = ns00;
      this.s11 = ns11;
      this.s10 = ns10;
    };
    XorShift128Plus2.prototype.getState = function() {
      return [this.s01, this.s00, this.s11, this.s10];
    };
    return XorShift128Plus2;
  })();
  function fromState3(state) {
    var valid = state.length === 4;
    if (!valid) {
      throw new Error("The state must have been produced by a xorshift128plus RandomGenerator");
    }
    return new XorShift128Plus(state[0], state[1], state[2], state[3]);
  }
  var xorshift128plus = Object.assign(function(seed) {
    return new XorShift128Plus(-1, ~seed, seed | 0, 0);
  }, { fromState: fromState3 });

  // node_modules/pure-rand/lib/esm/generator/XoroShiro.js
  var XoroShiro128Plus = (function() {
    function XoroShiro128Plus2(s01, s00, s11, s10) {
      this.s01 = s01;
      this.s00 = s00;
      this.s11 = s11;
      this.s10 = s10;
    }
    XoroShiro128Plus2.prototype.clone = function() {
      return new XoroShiro128Plus2(this.s01, this.s00, this.s11, this.s10);
    };
    XoroShiro128Plus2.prototype.next = function() {
      var nextRng = new XoroShiro128Plus2(this.s01, this.s00, this.s11, this.s10);
      var out = nextRng.unsafeNext();
      return [out, nextRng];
    };
    XoroShiro128Plus2.prototype.unsafeNext = function() {
      var out = this.s00 + this.s10 | 0;
      var a0 = this.s10 ^ this.s00;
      var a1 = this.s11 ^ this.s01;
      var s00 = this.s00;
      var s01 = this.s01;
      this.s00 = s00 << 24 ^ s01 >>> 8 ^ a0 ^ a0 << 16;
      this.s01 = s01 << 24 ^ s00 >>> 8 ^ a1 ^ (a1 << 16 | a0 >>> 16);
      this.s10 = a1 << 5 ^ a0 >>> 27;
      this.s11 = a0 << 5 ^ a1 >>> 27;
      return out;
    };
    XoroShiro128Plus2.prototype.jump = function() {
      var nextRng = new XoroShiro128Plus2(this.s01, this.s00, this.s11, this.s10);
      nextRng.unsafeJump();
      return nextRng;
    };
    XoroShiro128Plus2.prototype.unsafeJump = function() {
      var ns01 = 0;
      var ns00 = 0;
      var ns11 = 0;
      var ns10 = 0;
      var jump = [3639956645, 3750757012, 1261568508, 386426335];
      for (var i = 0; i !== 4; ++i) {
        for (var mask = 1; mask; mask <<= 1) {
          if (jump[i] & mask) {
            ns01 ^= this.s01;
            ns00 ^= this.s00;
            ns11 ^= this.s11;
            ns10 ^= this.s10;
          }
          this.unsafeNext();
        }
      }
      this.s01 = ns01;
      this.s00 = ns00;
      this.s11 = ns11;
      this.s10 = ns10;
    };
    XoroShiro128Plus2.prototype.getState = function() {
      return [this.s01, this.s00, this.s11, this.s10];
    };
    return XoroShiro128Plus2;
  })();
  function fromState4(state) {
    var valid = state.length === 4;
    if (!valid) {
      throw new Error("The state must have been produced by a xoroshiro128plus RandomGenerator");
    }
    return new XoroShiro128Plus(state[0], state[1], state[2], state[3]);
  }
  var xoroshiro128plus = Object.assign(function(seed) {
    return new XoroShiro128Plus(-1, ~seed, seed | 0, 0);
  }, { fromState: fromState4 });

  // node_modules/pure-rand/lib/esm/distribution/internals/UnsafeUniformIntDistributionInternal.js
  function unsafeUniformIntDistributionInternal(rangeSize, rng) {
    var MaxAllowed = rangeSize > 2 ? ~~(4294967296 / rangeSize) * rangeSize : 4294967296;
    var deltaV = rng.unsafeNext() + 2147483648;
    while (deltaV >= MaxAllowed) {
      deltaV = rng.unsafeNext() + 2147483648;
    }
    return deltaV % rangeSize;
  }

  // node_modules/pure-rand/lib/esm/distribution/internals/UnsafeUniformArrayIntDistributionInternal.js
  function unsafeUniformArrayIntDistributionInternal(out, rangeSize, rng) {
    var rangeLength = rangeSize.length;
    while (true) {
      for (var index = 0; index !== rangeLength; ++index) {
        var indexRangeSize = index === 0 ? rangeSize[0] + 1 : 4294967296;
        var g = unsafeUniformIntDistributionInternal(indexRangeSize, rng);
        out[index] = g;
      }
      for (var index = 0; index !== rangeLength; ++index) {
        var current = out[index];
        var currentInRange = rangeSize[index];
        if (current < currentInRange) {
          return out;
        } else if (current > currentInRange) {
          break;
        }
      }
    }
  }

  // node_modules/pure-rand/lib/esm/distribution/UnsafeUniformBigIntDistribution.js
  var One = typeof BigInt !== "undefined" ? BigInt(1) : void 0;
  var ThirtyTwo = typeof BigInt !== "undefined" ? BigInt(32) : void 0;
  var NumValues = typeof BigInt !== "undefined" ? BigInt(4294967296) : void 0;

  // node_modules/pure-rand/lib/esm/distribution/internals/ArrayInt64.js
  function fromNumberToArrayInt64(out, n) {
    if (n < 0) {
      var posN = -n;
      out.sign = -1;
      out.data[0] = ~~(posN / 4294967296);
      out.data[1] = posN >>> 0;
    } else {
      out.sign = 1;
      out.data[0] = ~~(n / 4294967296);
      out.data[1] = n >>> 0;
    }
    return out;
  }
  function substractArrayInt64(out, arrayIntA, arrayIntB) {
    var lowA = arrayIntA.data[1];
    var highA = arrayIntA.data[0];
    var signA = arrayIntA.sign;
    var lowB = arrayIntB.data[1];
    var highB = arrayIntB.data[0];
    var signB = arrayIntB.sign;
    out.sign = 1;
    if (signA === 1 && signB === -1) {
      var low_1 = lowA + lowB;
      var high = highA + highB + (low_1 > 4294967295 ? 1 : 0);
      out.data[0] = high >>> 0;
      out.data[1] = low_1 >>> 0;
      return out;
    }
    var lowFirst = lowA;
    var highFirst = highA;
    var lowSecond = lowB;
    var highSecond = highB;
    if (signA === -1) {
      lowFirst = lowB;
      highFirst = highB;
      lowSecond = lowA;
      highSecond = highA;
    }
    var reminderLow = 0;
    var low = lowFirst - lowSecond;
    if (low < 0) {
      reminderLow = 1;
      low = low >>> 0;
    }
    out.data[0] = highFirst - highSecond - reminderLow;
    out.data[1] = low;
    return out;
  }

  // node_modules/pure-rand/lib/esm/distribution/UnsafeUniformIntDistribution.js
  var safeNumberMaxSafeInteger = Number.MAX_SAFE_INTEGER;
  var sharedA = { sign: 1, data: [0, 0] };
  var sharedB = { sign: 1, data: [0, 0] };
  var sharedC = { sign: 1, data: [0, 0] };
  var sharedData = [0, 0];
  function uniformLargeIntInternal(from, to, rangeSize, rng) {
    var rangeSizeArrayIntValue = rangeSize <= safeNumberMaxSafeInteger ? fromNumberToArrayInt64(sharedC, rangeSize) : substractArrayInt64(sharedC, fromNumberToArrayInt64(sharedA, to), fromNumberToArrayInt64(sharedB, from));
    if (rangeSizeArrayIntValue.data[1] === 4294967295) {
      rangeSizeArrayIntValue.data[0] += 1;
      rangeSizeArrayIntValue.data[1] = 0;
    } else {
      rangeSizeArrayIntValue.data[1] += 1;
    }
    unsafeUniformArrayIntDistributionInternal(sharedData, rangeSizeArrayIntValue.data, rng);
    return sharedData[0] * 4294967296 + sharedData[1] + from;
  }
  function unsafeUniformIntDistribution(from, to, rng) {
    var rangeSize = to - from;
    if (rangeSize <= 4294967295) {
      var g = unsafeUniformIntDistributionInternal(rangeSize + 1, rng);
      return g + from;
    }
    return uniformLargeIntInternal(from, to, rangeSize, rng);
  }

  // node_modules/pure-rand/lib/esm/distribution/UniformIntDistribution.js
  function uniformIntDistribution(from, to, rng) {
    if (rng != null) {
      var nextRng = rng.clone();
      return [unsafeUniformIntDistribution(from, to, nextRng), nextRng];
    }
    return function(rng2) {
      var nextRng2 = rng2.clone();
      return [unsafeUniformIntDistribution(from, to, nextRng2), nextRng2];
    };
  }

  // src/domain/random.ts
  function createRandomState(seed) {
    if (!Number.isSafeInteger(seed)) throw new Error("Seed must be a safe integer");
    return [...xoroshiro128plus(seed | 0).getState()];
  }
  function nextRandom(state, min, max) {
    const [value, rng] = uniformIntDistribution(min, max, xoroshiro128plus.fromState(state));
    return { value, state: [...rng.getState()] };
  }

  // src/domain/v3/engine.ts
  function copyCommand(command) {
    return command.type === "place" ? { ...command, origin: { ...command.origin } } : { ...command };
  }
  function cloneState(state) {
    var _a;
    return {
      ...state,
      board: [...state.board],
      cellTraits: state.board.map((cell, i) => {
        var _a2;
        return cell === null ? null : ((_a2 = state.cellTraits) == null ? void 0 : _a2[i]) ? { ...state.cellTraits[i] } : null;
      }),
      generatedPieces: (_a = state.generatedPieces) != null ? _a : 0,
      rngState: [...state.rngState],
      candidates: state.candidates.map((p) => ({ ...p })),
      orders: state.orders.map((o) => ({ ...o })),
      upgrades: [...state.upgrades],
      upgradeChoices: [...state.upgradeChoices],
      commands: state.commands.map(copyCommand)
    };
  }
  function random(state, min, max) {
    const result = nextRandom(state.rngState, min, max);
    state.rngState = result.state;
    return result.value;
  }
  function weighted(state, values, weights) {
    if (!values.length || values.length !== weights.length || weights.some((w) => !Number.isSafeInteger(w) || w < 0) || !weights.some((w) => w > 0)) throw new Error("Invalid v3 weighted pool");
    let draw = random(state, 1, weights.reduce((sum, w) => sum + w, 0));
    for (let i = 0; i < values.length; i++) {
      draw -= weights[i];
      if (draw <= 0) return values[i];
    }
    throw new Error("Invalid v3 random draw");
  }
  function cargoPool(shift) {
    return CARGO.slice(0, RULES_V3_CONFIG.cargoByShift[shift - 1]).map((c) => c.id);
  }
  function inventoryUnits(state, cargo) {
    return state.board.reduce((sum, cell, i) => sum + (cell === cargo ? cellUnitsV2(state, i) : 0), 0);
  }
  function generatePieceV3(state) {
    var _a;
    state.generatedPieces = ((_a = state.generatedPieces) != null ? _a : 0) + 1;
    let trait;
    if (state.shift >= RULES_V3_CONFIG.special.minShift) {
      if (upgradeStackV2(state, "pallet_supply") && state.generatedPieces % upgradeParamV2("pallet_supply", "interval") === 0) trait = "pallet";
      else {
        const bonus = upgradeStackV2(state, "wild_supply") * upgradeParamV2("wild_supply", "weightBonus"), weights = RULES_V3_CONFIG.special.weights;
        const selected = weighted(state, ["normal", "pallet", "rush", "hazard", "wildcard"], [weights.normal - bonus, weights.pallet, weights.rush, weights.hazard, weights.wildcard + bonus]);
        if (selected !== "normal") trait = selected;
      }
    }
    let shapeId = "shape.single";
    if (!trait) {
      const shapes = SHAPES.filter((shape2) => shape2.minShift <= state.shift), occupancy = state.board.filter(Boolean).length;
      const smallBonus = upgradeStackV2(state, "small_parcels") * upgradeParamV2("small_parcels", "weightPercent");
      const weights = shapes.map((shape2) => {
        let weight = shape2.weight * 100;
        if (shape2.cells.length <= 2) weight = Math.floor(weight * (100 + smallBonus + Math.floor(occupancy * RULES_V3_CONFIG.generation.occupancySmallPercent / 49)) / 100);
        if (state.candidates.some((piece2) => piece2.shapeId === shape2.id)) weight = Math.floor(weight / RULES_V3_CONFIG.generation.recentShapeDivisor);
        return Math.max(1, weight);
      });
      shapeId = weighted(state, shapes, weights).id;
    }
    const pool = cargoPool(state.shift), cargo = weighted(state, pool, pool.map((id2) => 20 + inventoryUnits(state, id2) * RULES_V3_CONFIG.generation.cargoPresenceWeight));
    const piece = { id: `piece.${state.nextId++}`, shapeId, cargo };
    if (trait) {
      piece.trait = trait;
      if (trait === "rush") piece.rushTurns = RULES_V3_CONFIG.special.rushTurns + upgradeStackV2(state, "rush_buffer") * upgradeParamV2("rush_buffer", "extraTurns");
    }
    return piece;
  }
  function refreshOrders(state) {
    for (const dock of DOCKS.slice(0, RULES_V3_CONFIG.docksByShift[state.shift - 1])) {
      if (state.orders.some((order) => order.dockId === dock.id)) continue;
      const pool = cargoPool(state.shift).filter((cargo2) => !state.orders.some((order) => order.cargo === cargo2));
      if (!pool.length) throw new Error("No distinct cargo available for active Dock");
      const cargo = upgradeStackV2(state, "stock_orders") ? weighted(state, pool, pool.map((id2) => upgradeParamV2("stock_orders", "baseCargoWeight") + inventoryUnits(state, id2) * upgradeParamV2("stock_orders", "unitWeight"))) : pool[random(state, 0, pool.length - 1)];
      const drawnAmount = random(state, RULES_V3_CONFIG.orderMinByShift[state.shift - 1], RULES_V3_CONFIG.orderMaxByShift[state.shift - 1]);
      const amount = upgradeStackV2(state, "light_orders") ? Math.max(upgradeParamV2("light_orders", "floor"), drawnAmount - upgradeParamV2("light_orders", "reduction")) : drawnAmount;
      state.orders.push({ id: `order.${state.nextId++}`, dockId: dock.id, cargo, amount, baseScore: RULES_V3_CONFIG.score.orderBase + (state.shift - 1) * RULES_V3_CONFIG.score.orderPerShift });
    }
    state.orders.sort((a, b) => DOCKS.findIndex((d) => d.id === a.dockId) - DOCKS.findIndex((d) => d.id === b.dockId));
  }
  function isUpgradeEligibleV3(state, upgrade2) {
    var _a, _b, _c;
    return state.shift >= ((_a = upgrade2.minShift) != null ? _a : 1) && state.upgrades.filter((id2) => id2 === upgrade2.id).length < upgrade2.maxStack && ((_b = upgrade2.prerequisites) != null ? _b : []).every((id2) => state.upgrades.includes(id2)) && !((_c = upgrade2.conflicts) != null ? _c : []).some((id2) => state.upgrades.includes(id2)) && !UPGRADES_V2.some((u) => {
      var _a2;
      return state.upgrades.includes(u.id) && ((_a2 = u.conflicts) == null ? void 0 : _a2.includes(upgrade2.id));
    });
  }
  function generateUpgradeChoicesV3(state) {
    const pool = UPGRADES_V2.filter((u) => isUpgradeEligibleV3(state, u)), choices = [];
    function choose(values) {
      if (!values.length) return;
      const ownedTags = new Set(UPGRADES_V2.filter((u) => state.upgrades.includes(u.id)).flatMap((u) => {
        var _a;
        return (_a = u.tags) != null ? _a : [];
      }));
      const weights = values.map((u) => {
        var _a, _b, _c;
        const duplicate = state.upgrades.filter((id2) => id2 === u.id).length, synergy = ((_a = u.tags) != null ? _a : []).some((tag) => ownedTags.has(tag)) ? 125 : 100;
        const antiRepeat = state.upgradeChoices.includes(u.id) ? 50 : 100;
        return Math.max(0, Math.floor(((_c = (_b = u.params) == null ? void 0 : _b.baseWeight) != null ? _c : 100) * synergy * antiRepeat / 1e4 / (1 + duplicate)));
      });
      const selected = weights.some((w) => w > 0) ? weighted(state, values, weights) : [...values].sort((a, b) => a.id.localeCompare(b.id))[0];
      choices.push(selected.id);
      pool.splice(pool.indexOf(selected), 1);
    }
    for (let i = 0; i < 2; i++) choose(pool.filter((u) => u.behavior));
    while (choices.length < 3 && pool.length) choose(pool);
    return choices;
  }
  function tutorialPiece(state, shapeId, cargo) {
    var _a;
    state.generatedPieces = ((_a = state.generatedPieces) != null ? _a : 0) + 1;
    return { id: `piece.${state.nextId++}`, shapeId, cargo };
  }
  function tutorialOrder(state, dockId, cargo, amount) {
    return { id: `order.${state.nextId++}`, dockId, cargo, amount, baseScore: RULES_V3_CONFIG.score.orderBase };
  }
  function advanceTutorial(state, events) {
    var _a;
    state.tutorialStep = ((_a = state.tutorialStep) != null ? _a : 0) + 1;
    if (state.tutorialStep === 1) {
      state.candidates = [tutorialPiece(state, "shape.single", "cargo.food")];
    } else if (state.tutorialStep === 2) {
      state.board.fill(null);
      state.cellTraits.fill(null);
      for (const cell of RULES_V3_CONFIG.tutorial.lessonFoodCells) state.board[cell] = "cargo.food";
      for (const cell of RULES_V3_CONFIG.tutorial.lessonWallCells) state.board[cell] = "cargo.machine";
      state.orders = [tutorialOrder(state, "dock.north", "cargo.food", RULES_V3_CONFIG.tutorial.foodAmount), tutorialOrder(state, "dock.south", "cargo.machine", RULES_V3_CONFIG.tutorial.machineAmount)];
      state.candidates = [tutorialPiece(state, "shape.single", "cargo.machine")];
    } else {
      state.phase = "result";
      state.result = "won";
      state.endReason = "completed";
    }
    events.push({ type: "tutorialAdvanced", step: state.tutorialStep });
    if (state.phase === "result") events.push({ type: "result", result: "won" });
  }
  function createRunV3(seed, mode = "standard") {
    const state = {
      rulesetVersion: 3,
      runConfigId: RULES_V3_CONFIG.runConfigId,
      seed,
      mode,
      rngState: createRandomState(seed),
      board: Array(49).fill(null),
      cellTraits: Array(49).fill(null),
      generatedPieces: 0,
      candidates: [],
      orders: [],
      phase: "input",
      shift: 1,
      completedOrders: 0,
      score: 0,
      lastChain: 0,
      maxChain: 0,
      upgrades: [],
      upgradeChoices: [],
      commandIndex: 0,
      commands: [],
      nextId: 1,
      result: null,
      tutorialStep: mode === "tutorial" ? 0 : 3,
      overtime: false,
      endReason: null
    };
    if (mode === "tutorial") {
      state.orders = [tutorialOrder(state, "dock.north", "cargo.food", RULES_V3_CONFIG.tutorial.foodAmount)];
      state.candidates = [tutorialPiece(state, "shape.domino_h", "cargo.food")];
    } else {
      refreshOrders(state);
      for (let i = 0; i < RULES_V3_CONFIG.candidateCount; i++) state.candidates.push(generatePieceV3(state));
    }
    return state;
  }
  function placement(state, pieceId, origin) {
    var _a;
    if (state.phase !== "input") return { cells: [], reason: "\u5F53\u524D\u9636\u6BB5\u4E0D\u80FD\u5165\u5E93" };
    const piece = state.candidates.find((p) => p.id === pieceId), shape2 = SHAPES.find((s) => s.id === (piece == null ? void 0 : piece.shapeId));
    if (!piece || !shape2) return { cells: [], reason: "\u8D27\u4EF6\u5DF2\u4E0D\u5B58\u5728" };
    if (piece.trait && (!["pallet", "rush", "hazard", "wildcard"].includes(piece.trait) || shape2.cells.length !== 1)) return { cells: [], reason: "\u7279\u6B8A\u8D27\u4EF6\u5FC5\u987B\u4E3A\u5408\u6CD5\u5355\u683C" };
    if (piece.trait === "rush" && (!Number.isSafeInteger(piece.rushTurns) || piece.rushTurns <= 0)) return { cells: [], reason: "\u52A0\u6025\u8D27\u4EF6\u671F\u9650\u65E0\u6548" };
    if (!origin || !Number.isInteger(origin.x) || !Number.isInteger(origin.y)) return { cells: [], reason: "\u843D\u70B9\u5FC5\u987B\u662F\u5B8C\u6574\u683C\u5B50" };
    if (state.mode === "tutorial") {
      const hint = RULES_V3_CONFIG.tutorial.origins[(_a = state.tutorialStep) != null ? _a : 0];
      if (!hint || origin.x !== hint.x || origin.y !== hint.y) return { cells: [], reason: "\u8BF7\u5C06\u8D27\u4EF6\u653E\u5230\u6559\u5B66\u63D0\u793A\u683C" };
    }
    const points = shape2.cells.map((cell) => ({ x: cell.x + origin.x, y: cell.y + origin.y })), cells = points.map(toIndex);
    if (points.some((p) => p.x < 0 || p.y < 0 || p.x >= 7 || p.y >= 7)) return { cells, reason: "\u8D85\u51FA\u4ED3\u5E93\u8FB9\u754C" };
    if (cells.some((i) => state.board[i] !== null)) return { cells, reason: "\u8FD9\u91CC\u5DF2\u6709\u8D27\u7269" };
    return { cells };
  }
  function placePiece(state, piece, cells) {
    for (const cell of cells) {
      state.board[cell] = piece.cargo;
      state.cellTraits[cell] = piece.trait ? piece.trait === "rush" ? { kind: "rush", remaining: piece.rushTurns, bornAtCommand: state.commandIndex + 1 } : { kind: piece.trait } : null;
    }
  }
  function clear(state, cells) {
    for (const i of cells) {
      state.board[i] = null;
      state.cellTraits[i] = null;
    }
  }
  function shipmentScore(state, base, units, amount, depth, chain, varied) {
    const orderBase = base + upgradeStackV2(state, "contract") * upgradeParamV2("contract", "points");
    const overfill = Math.max(0, units - amount) * (RULES_V3_CONFIG.score.overfill + upgradeStackV2(state, "overfill") * upgradeParamV2("overfill", "points"));
    const route2 = depth * (RULES_V3_CONFIG.score.routeDepth + (depth >= upgradeParamV2("deep_route", "minDepth") ? upgradeStackV2(state, "deep_route") * upgradeParamV2("deep_route", "points") : 0));
    const variety = varied ? upgradeStackV2(state, "variety") * upgradeParamV2("variety", "points") : 0;
    return Math.floor((orderBase + overfill + route2 + variety) * (100 + (chain - 1) * (RULES_V3_CONFIG.score.chainPercent + upgradeStackV2(state, "chain") * upgradeParamV2("chain", "percent"))) / 100);
  }
  function adjacentCells(cells) {
    return [...new Set(cells.flatMap(neighbors))].sort((a, b) => a - b);
  }
  function resolveOldOrders(state) {
    const priority = (dockId) => {
      var _a, _b;
      return (_b = (_a = DOCKS.find((d) => d.id === dockId)) == null ? void 0 : _a.priority) != null ? _b : 99;
    };
    const pending = [...state.orders].sort((a, b) => (upgradeStackV2(state, "small_order_first") ? a.amount - b.amount : 0) || priority(a.dockId) - priority(b.dockId));
    const shipments = [];
    while (pending.length) {
      let selected = null, index = -1;
      for (let i = 0; i < pending.length; i++) {
        selected = selectOrderGroupV2(state, pending[i], shipments.length === 0 && upgradeStackV2(state, "pallet_pass") > 0);
        if (selected) {
          index = i;
          break;
        }
      }
      if (!selected) break;
      if (shipments.length >= RULES_V3_CONFIG.resolutionLimit) throw new Error("Resolution exceeded 64 steps");
      const [order] = pending.splice(index, 1), chain = shipments.length + 1;
      const score = shipmentScore(state, order.baseScore, selected.group.units, order.amount, selected.path.length - 1, chain, shipments.length > 0 && shipments[shipments.length - 1].cargo !== order.cargo);
      const hazard2 = selected.group.cells.some((i) => {
        var _a;
        return ((_a = state.cellTraits[i]) == null ? void 0 : _a.kind) === "hazard";
      });
      const extra = hazard2 ? adjacentCells(selected.group.cells).filter((i) => {
        var _a;
        return ((_a = state.cellTraits[i]) == null ? void 0 : _a.kind) === "waste";
      }).slice(0, upgradeStackV2(state, "hazard_clearance") ? upgradeParamV2("hazard_clearance", "maxWaste") : 1) : [];
      clear(state, selected.group.cells);
      clear(state, extra);
      if (chain === 1) {
        const adjacent = adjacentCells(selected.path.map(toIndex));
        if (upgradeStackV2(state, "sweep_route")) {
          const waste = adjacent.filter((i) => {
            var _a;
            return ((_a = state.cellTraits[i]) == null ? void 0 : _a.kind) === "waste";
          }).slice(0, upgradeParamV2("sweep_route", "maxWaste"));
          clear(state, waste);
          extra.push(...waste);
        }
        if (upgradeStackV2(state, "extra_pickup")) {
          const cargo = adjacent.filter((i) => state.board[i] !== null && state.board[i] !== order.cargo && state.cellTraits[i] === null).slice(0, upgradeParamV2("extra_pickup", "maxCargo"));
          clear(state, cargo);
          extra.push(...cargo);
        }
      }
      shipments.push({
        type: "shipment",
        dockId: order.dockId,
        orderId: order.id,
        cargo: order.cargo,
        cells: selected.group.cells,
        path: selected.path,
        score,
        chain,
        units: selected.group.units,
        extraClearedCells: extra.sort((a, b) => a - b),
        usedPalletPass: selected.usedPalletPass
      });
      state.score += score;
      state.completedOrders++;
    }
    state.orders = pending;
    state.lastChain = shipments.length;
    state.maxChain = Math.max(state.maxChain, shipments.length);
    return shipments;
  }
  function ageRush(state) {
    const expired = [];
    for (let i = 0; i < 49; i++) {
      const trait = state.cellTraits[i];
      if ((trait == null ? void 0 : trait.kind) !== "rush" || trait.bornAtCommand === state.commandIndex) continue;
      trait.remaining--;
      if (trait.remaining <= 0) {
        state.cellTraits[i] = { kind: "waste" };
        expired.push(i);
      }
    }
    return expired;
  }
  function previewPlacementV3(state, pieceId, origin) {
    const checked = placement(state, pieceId, origin);
    if (checked.reason) return { valid: false, cells: checked.cells, shipments: [], reason: checked.reason };
    const next = cloneState(state), piece = state.candidates.find((p) => p.id === pieceId);
    placePiece(next, piece, checked.cells);
    return { valid: true, cells: checked.cells, shipments: resolveOldOrders(next) };
  }
  function findLegalMovesV3(state) {
    const moves = [], input = state.phase === "input" ? state : { ...state, phase: "input" };
    for (const piece of state.candidates) for (let y = 0; y < 7; y++) for (let x = 0; x < 7; x++) if (!placement(input, piece.id, { x, y }).reason) moves.push({ pieceId: piece.id, origin: { x, y } });
    return moves;
  }
  function candidateCount(state) {
    return upgradeStackV2(state, "four_choices") ? upgradeParamV2("four_choices", "candidateCount") : RULES_V3_CONFIG.candidateCount;
  }
  function applyCommandV3(state, command) {
    const reject = (error) => ({ state, events: [], error });
    if (!command || command.type !== "place" && command.type !== "upgrade" && command.type !== "continueOvertime" && command.type !== "finishOvertime") return reject("\u672A\u77E5\u6307\u4EE4");
    if (command.type === "continueOvertime") {
      if (state.mode !== "standard" || state.phase !== "result" || state.result !== "won" || state.overtime || state.shift !== RULES_V3_CONFIG.shiftCount || state.completedOrders < RULES_V3_CONFIG.ordersPerShift * RULES_V3_CONFIG.shiftCount) return reject("\u53EA\u6709\u5B8C\u6210\u4E94\u73ED\u7684\u6807\u51C6\u5C40\u53EF\u4EE5\u7EE7\u7EED\u52A0\u73ED");
      const next2 = cloneState(state);
      next2.overtime = true;
      next2.phase = "input";
      next2.result = null;
      next2.endReason = null;
      next2.upgradeChoices = [];
      next2.commands.push(copyCommand(command));
      next2.commandIndex++;
      refreshOrders(next2);
      while (next2.candidates.length < candidateCount(next2)) next2.candidates.push(generatePieceV3(next2));
      const events2 = [{ type: "overtimeStarted" }];
      if (!findLegalMovesV3(next2).length) {
        next2.phase = "result";
        next2.result = "failed";
        next2.endReason = "blocked";
        events2.push({ type: "result", result: "failed" });
      }
      return { state: next2, events: events2 };
    }
    if (command.type === "finishOvertime") {
      if (state.mode !== "standard" || !state.overtime || state.phase !== "input") return reject("\u53EA\u6709\u52A0\u73ED\u8FDB\u884C\u4E2D\u53EF\u4EE5\u4E3B\u52A8\u7ED3\u7B97");
      const next2 = cloneState(state);
      next2.phase = "result";
      next2.result = "won";
      next2.endReason = "retired";
      next2.commands.push(copyCommand(command));
      next2.commandIndex++;
      return { state: next2, events: [{ type: "result", result: "won" }] };
    }
    if (command.type === "upgrade") {
      const upgrade2 = UPGRADES_V2.find((u) => u.id === command.upgradeId);
      if (state.mode === "tutorial" || state.overtime || state.phase !== "upgrade" || !state.upgradeChoices.includes(command.upgradeId) || !upgrade2 || !isUpgradeEligibleV3(state, upgrade2)) return reject("\u5F53\u524D\u4E0D\u80FD\u9009\u62E9\u6B64\u5347\u7EA7");
      const next2 = cloneState(state);
      next2.upgrades.push(command.upgradeId);
      next2.upgradeChoices = [];
      next2.phase = "input";
      next2.commands.push(copyCommand(command));
      next2.commandIndex++;
      if (upgrade2.effect === "four_choices") while (next2.candidates.length < candidateCount(next2)) next2.candidates.push(generatePieceV3(next2));
      return { state: next2, events: [] };
    }
    const checked = placement(state, command.pieceId, command.origin);
    if (checked.reason) return reject(checked.reason);
    const next = cloneState(state), index = next.candidates.findIndex((piece2) => piece2.id === command.pieceId), piece = next.candidates[index];
    placePiece(next, piece, checked.cells);
    next.candidates.splice(index, 1);
    const events = [{ type: "placed", pieceId: piece.id, cells: checked.cells }, ...resolveOldOrders(next)];
    next.commands.push(copyCommand(command));
    next.commandIndex++;
    const expired = ageRush(next);
    if (expired.length) events.push({ type: "rushExpired", cells: expired });
    if (next.mode === "tutorial") {
      advanceTutorial(next, events);
      return { state: next, events };
    }
    if (!next.overtime && next.completedOrders >= RULES_V3_CONFIG.ordersPerShift * RULES_V3_CONFIG.shiftCount) {
      next.phase = "result";
      next.result = "won";
      next.endReason = "completed";
      next.score += RULES_V3_CONFIG.score.shiftBonus;
      events.push({ type: "result", result: "won" });
      return { state: next, events };
    }
    const shift = Math.min(RULES_V3_CONFIG.shiftCount, Math.floor(next.completedOrders / RULES_V3_CONFIG.ordersPerShift) + 1);
    if (shift > next.shift) {
      next.score += (shift - next.shift) * RULES_V3_CONFIG.score.shiftBonus;
      next.shift = shift;
      events.push({ type: "shift", shift });
    }
    refreshOrders(next);
    next.candidates.splice(index, 0, generatePieceV3(next));
    while (next.candidates.length < candidateCount(next)) next.candidates.push(generatePieceV3(next));
    if (!findLegalMovesV3(next).length) {
      next.phase = "result";
      next.result = "failed";
      next.endReason = "blocked";
      events.push({ type: "result", result: "failed" });
    } else if (!next.overtime && Math.floor(next.completedOrders / RULES_V3_CONFIG.upgradeEvery) > Math.floor(state.completedOrders / RULES_V3_CONFIG.upgradeEvery)) {
      next.phase = "upgrade";
      next.upgradeChoices = generateUpgradeChoicesV3(next);
      events.push({ type: "upgrade" });
    }
    return { state: next, events };
  }

  // src/domain/rulesets/v1/random.ts
  function createRandomState2(seed) {
    if (!Number.isSafeInteger(seed)) throw new Error("Seed must be a safe integer");
    return [...xoroshiro128plus(seed | 0).getState()];
  }
  function nextRandom2(state, min, max) {
    const [value, rng] = uniformIntDistribution(min, max, xoroshiro128plus.fromState(state));
    return { value, state: [...rng.getState()] };
  }

  // src/domain/rulesets/v1/engine.ts
  var stack = (state, id2) => state.upgrades.filter((value) => value === `upgrade.${id2}`).length;
  function copyCommand2(command) {
    return command.type === "place" ? { ...command, origin: { ...command.origin } } : { ...command };
  }
  function cloneState2(state) {
    return {
      ...state,
      board: [...state.board],
      rngState: [...state.rngState],
      candidates: state.candidates.map((p) => ({ ...p })),
      orders: state.orders.map((o) => ({ ...o })),
      upgrades: [...state.upgrades],
      upgradeChoices: [...state.upgradeChoices],
      commands: state.commands.map(copyCommand2)
    };
  }
  function random2(state, min, max) {
    const draw = nextRandom2(state.rngState, min, max);
    state.rngState = draw.state;
    return draw.value;
  }
  function weighted2(state, values, weights) {
    let draw = random2(state, 1, weights.reduce((sum, value) => sum + value, 0));
    for (let i = 0; i < values.length; i++) {
      draw -= weights[i];
      if (draw <= 0) return values[i];
    }
    return values[values.length - 1];
  }
  function cargoPool2(shift) {
    return CARGO.slice(0, P0_CONFIG.cargoByShift[shift - 1]).map((c) => c.id);
  }
  function generatePiece(state) {
    const shapes = SHAPES.filter((shape3) => shape3.minShift <= state.shift);
    const occupancy = state.board.filter(Boolean).length;
    const smallBonus = stack(state, "small_parcels") * P0_CONFIG.upgrade.smallWeightPercent;
    const weights = shapes.map((shape3) => {
      let weight = shape3.weight * 100;
      if (shape3.cells.length <= 2) weight = Math.floor(weight * (100 + smallBonus + Math.floor(occupancy * P0_CONFIG.generation.occupancySmallPercent / 49)) / 100);
      if (state.candidates.some((piece) => piece.shapeId === shape3.id)) weight = Math.floor(weight / P0_CONFIG.generation.recentShapeDivisor);
      return Math.max(1, weight);
    });
    const shape2 = weighted2(state, shapes, weights), pool = cargoPool2(state.shift);
    const cargo = weighted2(state, pool, pool.map((id2) => 20 + state.board.filter((cell) => cell === id2).length * P0_CONFIG.generation.cargoPresenceWeight));
    return { id: `piece.${state.nextId++}`, shapeId: shape2.id, cargo };
  }
  function refreshOrders2(state) {
    for (const dock of DOCKS.slice(0, P0_CONFIG.docksByShift[state.shift - 1])) {
      if (state.orders.some((order) => order.dockId === dock.id)) continue;
      const pool = cargoPool2(state.shift).filter((cargo) => !state.orders.some((order) => order.cargo === cargo));
      if (!pool.length) throw new Error("No distinct cargo available for active Dock");
      state.orders.push({
        id: `order.${state.nextId++}`,
        dockId: dock.id,
        cargo: pool[random2(state, 0, pool.length - 1)],
        amount: random2(state, P0_CONFIG.orderMinByShift[state.shift - 1], P0_CONFIG.orderMaxByShift[state.shift - 1]),
        baseScore: P0_CONFIG.score.orderBase + (state.shift - 1) * P0_CONFIG.score.orderPerShift
      });
    }
    state.orders.sort((a, b) => DOCKS.findIndex((d) => d.id === a.dockId) - DOCKS.findIndex((d) => d.id === b.dockId));
  }
  function upgradeChoices(state) {
    const pool = UPGRADES.filter((u) => state.upgrades.filter((id2) => id2 === u.id).length < u.maxStack);
    const choices = [];
    const behavior = pool.findIndex((u) => u.id === "upgrade.small_parcels");
    if (behavior >= 0) choices.push(pool.splice(behavior, 1)[0].id);
    while (choices.length < 3 && pool.length) {
      const selected = weighted2(state, pool, pool.map((u) => Math.max(1, Math.floor(100 / (1 + state.upgrades.filter((id2) => id2 === u.id).length)))));
      choices.push(selected.id);
      pool.splice(pool.indexOf(selected), 1);
    }
    if (choices.length !== 3) throw new Error("Upgrade fallback content invariant violated");
    return choices;
  }
  function createRun(seed, mode = "standard") {
    const state = {
      rulesetVersion: P0_CONFIG.rulesetVersion,
      runConfigId: P0_CONFIG.runConfigId,
      seed,
      mode,
      rngState: createRandomState2(seed),
      board: Array(49).fill(null),
      candidates: [],
      orders: [],
      phase: "input",
      shift: 1,
      completedOrders: 0,
      score: 0,
      lastChain: 0,
      maxChain: 0,
      upgrades: [],
      upgradeChoices: [],
      commandIndex: 0,
      commands: [],
      nextId: 1,
      result: null
    };
    refreshOrders2(state);
    for (let i = 0; i < P0_CONFIG.candidateCount; i++) state.candidates.push(generatePiece(state));
    if (mode === "tutorial") {
      state.orders[0] = { ...state.orders[0], cargo: "cargo.food", amount: 3 };
      state.orders[1] = { ...state.orders[1], cargo: "cargo.machine", amount: 3 };
      state.candidates[0] = { ...state.candidates[0], shapeId: "shape.domino_h", cargo: "cargo.food" };
      state.candidates[1] = { ...state.candidates[1], shapeId: "shape.single", cargo: "cargo.food" };
      state.candidates[2] = { ...state.candidates[2], shapeId: "shape.domino_v", cargo: "cargo.machine" };
    }
    return state;
  }
  function placement2(state, pieceId, origin) {
    if (state.phase !== "input") return { cells: [], reason: "\u5F53\u524D\u9636\u6BB5\u4E0D\u80FD\u5165\u5E93" };
    const piece = state.candidates.find((p) => p.id === pieceId), shape2 = SHAPES.find((s) => s.id === (piece == null ? void 0 : piece.shapeId));
    if (!piece || !shape2) return { cells: [], reason: "\u8D27\u4EF6\u5DF2\u4E0D\u5B58\u5728" };
    if (!origin || !Number.isInteger(origin.x) || !Number.isInteger(origin.y)) return { cells: [], reason: "\u843D\u70B9\u5FC5\u987B\u662F\u5B8C\u6574\u683C\u5B50" };
    const points = shape2.cells.map((cell) => ({ x: cell.x + origin.x, y: cell.y + origin.y })), cells = points.map(toIndex);
    if (points.some((p) => p.x < 0 || p.y < 0 || p.x >= 7 || p.y >= 7)) return { cells, reason: "\u8D85\u51FA\u4ED3\u5E93\u8FB9\u754C" };
    if (cells.some((index) => state.board[index] !== null)) return { cells, reason: "\u8FD9\u91CC\u5DF2\u6709\u8D27\u7269" };
    return { cells };
  }
  function shipmentScore2(state, base, size, amount, depth, chain, varied) {
    const orderBase = base + stack(state, "contract") * P0_CONFIG.upgrade.contract;
    const overfill = Math.max(0, size - amount) * (P0_CONFIG.score.overfill + stack(state, "overfill") * P0_CONFIG.upgrade.overfill);
    const route2 = depth * (P0_CONFIG.score.routeDepth + (depth >= 3 ? stack(state, "deep_route") * P0_CONFIG.upgrade.deepRoute : 0));
    const variety = varied ? stack(state, "variety") * P0_CONFIG.upgrade.variety : 0;
    const chainPercent = 100 + (chain - 1) * (P0_CONFIG.score.chainPercent + stack(state, "chain") * P0_CONFIG.upgrade.chainPercent);
    return Math.floor((orderBase + overfill + route2 + variety) * chainPercent / 100);
  }
  function resolveOldOrders2(state) {
    const pending = [...state.orders].sort((a, b) => {
      var _a, _b, _c, _d;
      return ((_b = (_a = DOCKS.find((d) => d.id === a.dockId)) == null ? void 0 : _a.priority) != null ? _b : 99) - ((_d = (_c = DOCKS.find((d) => d.id === b.dockId)) == null ? void 0 : _c.priority) != null ? _d : 99);
    });
    const shipments = [];
    while (pending.length) {
      let selected = null, selectedIndex = -1;
      for (let i = 0; i < pending.length; i++) {
        selected = selectOrderGroup(state.board, pending[i]);
        if (selected) {
          selectedIndex = i;
          break;
        }
      }
      if (!selected) break;
      if (shipments.length >= P0_CONFIG.resolutionLimit) throw new Error("Resolution exceeded 64 steps");
      const [order] = pending.splice(selectedIndex, 1), chain = shipments.length + 1;
      const score = shipmentScore2(state, order.baseScore, selected.group.cells.length, order.amount, selected.path.length - 1, chain, shipments.length > 0 && shipments[shipments.length - 1].cargo !== order.cargo);
      for (const cell of selected.group.cells) state.board[cell] = null;
      shipments.push({ type: "shipment", dockId: order.dockId, orderId: order.id, cargo: order.cargo, cells: selected.group.cells, path: selected.path, score, chain });
      state.score += score;
      state.completedOrders++;
    }
    state.orders = pending;
    state.lastChain = shipments.length;
    state.maxChain = Math.max(state.maxChain, shipments.length);
    return shipments;
  }
  function previewPlacement(state, pieceId, origin) {
    const checked = placement2(state, pieceId, origin);
    if (checked.reason) return { valid: false, cells: checked.cells, shipments: [], reason: checked.reason };
    const next = cloneState2(state), piece = state.candidates.find((p) => p.id === pieceId);
    for (const cell of checked.cells) next.board[cell] = piece.cargo;
    return { valid: true, cells: checked.cells, shipments: resolveOldOrders2(next) };
  }
  function findLegalMoves(state) {
    const result = [];
    const input = state.phase === "input" ? state : { ...state, phase: "input" };
    for (const piece of state.candidates) for (let y = 0; y < 7; y++) for (let x = 0; x < 7; x++) {
      if (!placement2(input, piece.id, { x, y }).reason) result.push({ pieceId: piece.id, origin: { x, y } });
    }
    return result;
  }
  function applyCommand(state, command) {
    const reject = (error) => ({ state, events: [], error });
    if (!command || command.type !== "place" && command.type !== "upgrade") return reject("\u672A\u77E5\u6307\u4EE4");
    if (command.type === "upgrade") {
      if (state.phase !== "upgrade" || !state.upgradeChoices.includes(command.upgradeId)) return reject("\u5F53\u524D\u4E0D\u80FD\u9009\u62E9\u6B64\u5347\u7EA7");
      const next2 = cloneState2(state);
      next2.upgrades.push(command.upgradeId);
      next2.upgradeChoices = [];
      next2.phase = "input";
      next2.commands.push(copyCommand2(command));
      next2.commandIndex++;
      return { state: next2, events: [] };
    }
    const checked = placement2(state, command.pieceId, command.origin);
    if (checked.reason) return reject(checked.reason);
    const next = cloneState2(state), index = next.candidates.findIndex((piece2) => piece2.id === command.pieceId), piece = next.candidates[index];
    for (const cell of checked.cells) next.board[cell] = piece.cargo;
    next.candidates.splice(index, 1);
    const events = [{ type: "placed", pieceId: piece.id, cells: checked.cells }, ...resolveOldOrders2(next)];
    next.commands.push(copyCommand2(command));
    next.commandIndex++;
    if (next.completedOrders >= P0_CONFIG.ordersPerShift * P0_CONFIG.shiftCount) {
      next.phase = "result";
      next.result = "won";
      next.score += P0_CONFIG.score.shiftBonus;
      events.push({ type: "result", result: "won" });
      return { state: next, events };
    }
    const shift = Math.min(P0_CONFIG.shiftCount, Math.floor(next.completedOrders / P0_CONFIG.ordersPerShift) + 1);
    if (shift > next.shift) {
      next.score += (shift - next.shift) * P0_CONFIG.score.shiftBonus;
      next.shift = shift;
      events.push({ type: "shift", shift });
    }
    refreshOrders2(next);
    next.candidates.splice(index, 0, generatePiece(next));
    while (next.candidates.length < P0_CONFIG.candidateCount) next.candidates.push(generatePiece(next));
    if (!findLegalMoves(next).length) {
      next.phase = "result";
      next.result = "failed";
      events.push({ type: "result", result: "failed" });
    } else if (Math.floor(next.completedOrders / P0_CONFIG.upgradeEvery) > Math.floor(state.completedOrders / P0_CONFIG.upgradeEvery)) {
      next.phase = "upgrade";
      next.upgradeChoices = upgradeChoices(next);
      events.push({ type: "upgrade" });
    }
    return { state: next, events };
  }

  // src/domain/v2/engine.ts
  function copyCommand3(command) {
    return command.type === "place" ? { ...command, origin: { ...command.origin } } : { ...command };
  }
  function cloneState3(state) {
    var _a;
    return {
      ...state,
      board: [...state.board],
      cellTraits: state.board.map((cell, i) => {
        var _a2;
        return cell === null ? null : ((_a2 = state.cellTraits) == null ? void 0 : _a2[i]) ? { ...state.cellTraits[i] } : null;
      }),
      generatedPieces: (_a = state.generatedPieces) != null ? _a : 0,
      rngState: [...state.rngState],
      candidates: state.candidates.map((p) => ({ ...p })),
      orders: state.orders.map((o) => ({ ...o })),
      upgrades: [...state.upgrades],
      upgradeChoices: [...state.upgradeChoices],
      commands: state.commands.map(copyCommand3)
    };
  }
  function random3(state, min, max) {
    const result = nextRandom(state.rngState, min, max);
    state.rngState = result.state;
    return result.value;
  }
  function weighted3(state, values, weights) {
    if (!values.length || values.length !== weights.length || weights.some((w) => !Number.isSafeInteger(w) || w < 0) || !weights.some((w) => w > 0)) throw new Error("Invalid v2 weighted pool");
    let draw = random3(state, 1, weights.reduce((sum, w) => sum + w, 0));
    for (let i = 0; i < values.length; i++) {
      draw -= weights[i];
      if (draw <= 0) return values[i];
    }
    throw new Error("Invalid v2 random draw");
  }
  function cargoPool3(shift) {
    return CARGO.slice(0, RULES_V2_CONFIG.cargoByShift[shift - 1]).map((c) => c.id);
  }
  function inventoryUnits2(state, cargo) {
    return state.board.reduce((sum, cell, i) => sum + (cell === cargo ? cellUnitsV2(state, i) : 0), 0);
  }
  function generatePieceV2(state) {
    var _a;
    state.generatedPieces = ((_a = state.generatedPieces) != null ? _a : 0) + 1;
    let trait;
    if (state.shift >= RULES_V2_CONFIG.special.minShift) {
      if (upgradeStackV2(state, "pallet_supply") && state.generatedPieces % upgradeParamV2("pallet_supply", "interval") === 0) trait = "pallet";
      else {
        const bonus = upgradeStackV2(state, "wild_supply") * upgradeParamV2("wild_supply", "weightBonus"), weights = RULES_V2_CONFIG.special.weights;
        const selected = weighted3(state, ["normal", "pallet", "rush", "hazard", "wildcard"], [weights.normal - bonus, weights.pallet, weights.rush, weights.hazard, weights.wildcard + bonus]);
        if (selected !== "normal") trait = selected;
      }
    }
    let shapeId = "shape.single";
    if (!trait) {
      const shapes = SHAPES.filter((shape2) => shape2.minShift <= state.shift), occupancy = state.board.filter(Boolean).length;
      const smallBonus = upgradeStackV2(state, "small_parcels") * upgradeParamV2("small_parcels", "weightPercent");
      const weights = shapes.map((shape2) => {
        let weight = shape2.weight * 100;
        if (shape2.cells.length <= 2) weight = Math.floor(weight * (100 + smallBonus + Math.floor(occupancy * RULES_V2_CONFIG.generation.occupancySmallPercent / 49)) / 100);
        if (state.candidates.some((piece2) => piece2.shapeId === shape2.id)) weight = Math.floor(weight / RULES_V2_CONFIG.generation.recentShapeDivisor);
        return Math.max(1, weight);
      });
      shapeId = weighted3(state, shapes, weights).id;
    }
    const pool = cargoPool3(state.shift), cargo = weighted3(state, pool, pool.map((id2) => 20 + inventoryUnits2(state, id2) * RULES_V2_CONFIG.generation.cargoPresenceWeight));
    const piece = { id: `piece.${state.nextId++}`, shapeId, cargo };
    if (trait) {
      piece.trait = trait;
      if (trait === "rush") piece.rushTurns = RULES_V2_CONFIG.special.rushTurns + upgradeStackV2(state, "rush_buffer") * upgradeParamV2("rush_buffer", "extraTurns");
    }
    return piece;
  }
  function refreshOrders3(state) {
    for (const dock of DOCKS.slice(0, RULES_V2_CONFIG.docksByShift[state.shift - 1])) {
      if (state.orders.some((order) => order.dockId === dock.id)) continue;
      const pool = cargoPool3(state.shift).filter((cargo2) => !state.orders.some((order) => order.cargo === cargo2));
      if (!pool.length) throw new Error("No distinct cargo available for active Dock");
      const cargo = upgradeStackV2(state, "stock_orders") ? weighted3(state, pool, pool.map((id2) => upgradeParamV2("stock_orders", "baseCargoWeight") + inventoryUnits2(state, id2) * upgradeParamV2("stock_orders", "unitWeight"))) : pool[random3(state, 0, pool.length - 1)];
      const drawnAmount = random3(state, RULES_V2_CONFIG.orderMinByShift[state.shift - 1], RULES_V2_CONFIG.orderMaxByShift[state.shift - 1]);
      const amount = upgradeStackV2(state, "light_orders") ? Math.max(upgradeParamV2("light_orders", "floor"), drawnAmount - upgradeParamV2("light_orders", "reduction")) : drawnAmount;
      state.orders.push({ id: `order.${state.nextId++}`, dockId: dock.id, cargo, amount, baseScore: RULES_V2_CONFIG.score.orderBase + (state.shift - 1) * RULES_V2_CONFIG.score.orderPerShift });
    }
    state.orders.sort((a, b) => DOCKS.findIndex((d) => d.id === a.dockId) - DOCKS.findIndex((d) => d.id === b.dockId));
  }
  function isUpgradeEligibleV2(state, upgrade2) {
    var _a, _b, _c;
    return state.shift >= ((_a = upgrade2.minShift) != null ? _a : 1) && state.upgrades.filter((id2) => id2 === upgrade2.id).length < upgrade2.maxStack && ((_b = upgrade2.prerequisites) != null ? _b : []).every((id2) => state.upgrades.includes(id2)) && !((_c = upgrade2.conflicts) != null ? _c : []).some((id2) => state.upgrades.includes(id2)) && !UPGRADES_V2.some((u) => {
      var _a2;
      return state.upgrades.includes(u.id) && ((_a2 = u.conflicts) == null ? void 0 : _a2.includes(upgrade2.id));
    });
  }
  function generateUpgradeChoicesV2(state) {
    const pool = UPGRADES_V2.filter((u) => isUpgradeEligibleV2(state, u)), choices = [];
    function choose(values) {
      if (!values.length) return;
      const ownedTags = new Set(UPGRADES_V2.filter((u) => state.upgrades.includes(u.id)).flatMap((u) => {
        var _a;
        return (_a = u.tags) != null ? _a : [];
      }));
      const weights = values.map((u) => {
        var _a, _b, _c;
        const duplicate = state.upgrades.filter((id2) => id2 === u.id).length, synergy = ((_a = u.tags) != null ? _a : []).some((tag) => ownedTags.has(tag)) ? 125 : 100;
        const antiRepeat = state.upgradeChoices.includes(u.id) ? 50 : 100;
        return Math.max(0, Math.floor(((_c = (_b = u.params) == null ? void 0 : _b.baseWeight) != null ? _c : 100) * synergy * antiRepeat / 1e4 / (1 + duplicate)));
      });
      const selected = weights.some((w) => w > 0) ? weighted3(state, values, weights) : [...values].sort((a, b) => a.id.localeCompare(b.id))[0];
      choices.push(selected.id);
      pool.splice(pool.indexOf(selected), 1);
    }
    for (let i = 0; i < 2; i++) choose(pool.filter((u) => u.behavior));
    while (choices.length < 3 && pool.length) choose(pool);
    return choices;
  }
  function createRunV2(seed, mode = "standard") {
    const state = {
      rulesetVersion: 2,
      runConfigId: RULES_V2_CONFIG.runConfigId,
      seed,
      mode,
      rngState: createRandomState(seed),
      board: Array(49).fill(null),
      cellTraits: Array(49).fill(null),
      generatedPieces: 0,
      candidates: [],
      orders: [],
      phase: "input",
      shift: 1,
      completedOrders: 0,
      score: 0,
      lastChain: 0,
      maxChain: 0,
      upgrades: [],
      upgradeChoices: [],
      commandIndex: 0,
      commands: [],
      nextId: 1,
      result: null
    };
    refreshOrders3(state);
    for (let i = 0; i < RULES_V2_CONFIG.candidateCount; i++) state.candidates.push(generatePieceV2(state));
    if (mode === "tutorial") {
      state.orders[0] = { ...state.orders[0], cargo: "cargo.food", amount: 3 };
      state.orders[1] = { ...state.orders[1], cargo: "cargo.machine", amount: 3 };
      state.candidates[0] = { ...state.candidates[0], shapeId: "shape.domino_h", cargo: "cargo.food" };
      state.candidates[1] = { ...state.candidates[1], shapeId: "shape.single", cargo: "cargo.food" };
      state.candidates[2] = { ...state.candidates[2], shapeId: "shape.domino_v", cargo: "cargo.machine" };
    }
    return state;
  }
  function placement3(state, pieceId, origin) {
    if (state.phase !== "input") return { cells: [], reason: "\u5F53\u524D\u9636\u6BB5\u4E0D\u80FD\u5165\u5E93" };
    const piece = state.candidates.find((p) => p.id === pieceId), shape2 = SHAPES.find((s) => s.id === (piece == null ? void 0 : piece.shapeId));
    if (!piece || !shape2) return { cells: [], reason: "\u8D27\u4EF6\u5DF2\u4E0D\u5B58\u5728" };
    if (piece.trait && (!["pallet", "rush", "hazard", "wildcard"].includes(piece.trait) || shape2.cells.length !== 1)) return { cells: [], reason: "\u7279\u6B8A\u8D27\u4EF6\u5FC5\u987B\u4E3A\u5408\u6CD5\u5355\u683C" };
    if (piece.trait === "rush" && (!Number.isSafeInteger(piece.rushTurns) || piece.rushTurns <= 0)) return { cells: [], reason: "\u52A0\u6025\u8D27\u4EF6\u671F\u9650\u65E0\u6548" };
    if (!origin || !Number.isInteger(origin.x) || !Number.isInteger(origin.y)) return { cells: [], reason: "\u843D\u70B9\u5FC5\u987B\u662F\u5B8C\u6574\u683C\u5B50" };
    const points = shape2.cells.map((cell) => ({ x: cell.x + origin.x, y: cell.y + origin.y })), cells = points.map(toIndex);
    if (points.some((p) => p.x < 0 || p.y < 0 || p.x >= 7 || p.y >= 7)) return { cells, reason: "\u8D85\u51FA\u4ED3\u5E93\u8FB9\u754C" };
    if (cells.some((i) => state.board[i] !== null)) return { cells, reason: "\u8FD9\u91CC\u5DF2\u6709\u8D27\u7269" };
    return { cells };
  }
  function placePiece2(state, piece, cells) {
    for (const cell of cells) {
      state.board[cell] = piece.cargo;
      state.cellTraits[cell] = piece.trait ? piece.trait === "rush" ? { kind: "rush", remaining: piece.rushTurns, bornAtCommand: state.commandIndex + 1 } : { kind: piece.trait } : null;
    }
  }
  function clear2(state, cells) {
    for (const i of cells) {
      state.board[i] = null;
      state.cellTraits[i] = null;
    }
  }
  function shipmentScore3(state, base, units, amount, depth, chain, varied) {
    const orderBase = base + upgradeStackV2(state, "contract") * upgradeParamV2("contract", "points");
    const overfill = Math.max(0, units - amount) * (RULES_V2_CONFIG.score.overfill + upgradeStackV2(state, "overfill") * upgradeParamV2("overfill", "points"));
    const route2 = depth * (RULES_V2_CONFIG.score.routeDepth + (depth >= upgradeParamV2("deep_route", "minDepth") ? upgradeStackV2(state, "deep_route") * upgradeParamV2("deep_route", "points") : 0));
    const variety = varied ? upgradeStackV2(state, "variety") * upgradeParamV2("variety", "points") : 0;
    return Math.floor((orderBase + overfill + route2 + variety) * (100 + (chain - 1) * (RULES_V2_CONFIG.score.chainPercent + upgradeStackV2(state, "chain") * upgradeParamV2("chain", "percent"))) / 100);
  }
  function adjacentCells2(cells) {
    return [...new Set(cells.flatMap(neighbors))].sort((a, b) => a - b);
  }
  function resolveOldOrders3(state) {
    const priority = (dockId) => {
      var _a, _b;
      return (_b = (_a = DOCKS.find((d) => d.id === dockId)) == null ? void 0 : _a.priority) != null ? _b : 99;
    };
    const pending = [...state.orders].sort((a, b) => (upgradeStackV2(state, "small_order_first") ? a.amount - b.amount : 0) || priority(a.dockId) - priority(b.dockId));
    const shipments = [];
    while (pending.length) {
      let selected = null, index = -1;
      for (let i = 0; i < pending.length; i++) {
        selected = selectOrderGroupV2(state, pending[i], shipments.length === 0 && upgradeStackV2(state, "pallet_pass") > 0);
        if (selected) {
          index = i;
          break;
        }
      }
      if (!selected) break;
      if (shipments.length >= RULES_V2_CONFIG.resolutionLimit) throw new Error("Resolution exceeded 64 steps");
      const [order] = pending.splice(index, 1), chain = shipments.length + 1;
      const score = shipmentScore3(state, order.baseScore, selected.group.units, order.amount, selected.path.length - 1, chain, shipments.length > 0 && shipments[shipments.length - 1].cargo !== order.cargo);
      const hazard2 = selected.group.cells.some((i) => {
        var _a;
        return ((_a = state.cellTraits[i]) == null ? void 0 : _a.kind) === "hazard";
      });
      const extra = hazard2 ? adjacentCells2(selected.group.cells).filter((i) => {
        var _a;
        return ((_a = state.cellTraits[i]) == null ? void 0 : _a.kind) === "waste";
      }).slice(0, upgradeStackV2(state, "hazard_clearance") ? upgradeParamV2("hazard_clearance", "maxWaste") : 1) : [];
      clear2(state, selected.group.cells);
      clear2(state, extra);
      if (chain === 1) {
        const adjacent = adjacentCells2(selected.path.map(toIndex));
        if (upgradeStackV2(state, "sweep_route")) {
          const waste = adjacent.filter((i) => {
            var _a;
            return ((_a = state.cellTraits[i]) == null ? void 0 : _a.kind) === "waste";
          }).slice(0, upgradeParamV2("sweep_route", "maxWaste"));
          clear2(state, waste);
          extra.push(...waste);
        }
        if (upgradeStackV2(state, "extra_pickup")) {
          const cargo = adjacent.filter((i) => state.board[i] !== null && state.board[i] !== order.cargo && state.cellTraits[i] === null).slice(0, upgradeParamV2("extra_pickup", "maxCargo"));
          clear2(state, cargo);
          extra.push(...cargo);
        }
      }
      shipments.push({
        type: "shipment",
        dockId: order.dockId,
        orderId: order.id,
        cargo: order.cargo,
        cells: selected.group.cells,
        path: selected.path,
        score,
        chain,
        units: selected.group.units,
        extraClearedCells: extra.sort((a, b) => a - b),
        usedPalletPass: selected.usedPalletPass
      });
      state.score += score;
      state.completedOrders++;
    }
    state.orders = pending;
    state.lastChain = shipments.length;
    state.maxChain = Math.max(state.maxChain, shipments.length);
    return shipments;
  }
  function ageRush2(state) {
    const expired = [];
    for (let i = 0; i < 49; i++) {
      const trait = state.cellTraits[i];
      if ((trait == null ? void 0 : trait.kind) !== "rush" || trait.bornAtCommand === state.commandIndex) continue;
      trait.remaining--;
      if (trait.remaining <= 0) {
        state.cellTraits[i] = { kind: "waste" };
        expired.push(i);
      }
    }
    return expired;
  }
  function previewPlacementV2(state, pieceId, origin) {
    const checked = placement3(state, pieceId, origin);
    if (checked.reason) return { valid: false, cells: checked.cells, shipments: [], reason: checked.reason };
    const next = cloneState3(state), piece = state.candidates.find((p) => p.id === pieceId);
    placePiece2(next, piece, checked.cells);
    return { valid: true, cells: checked.cells, shipments: resolveOldOrders3(next) };
  }
  function findLegalMovesV2(state) {
    const moves = [], input = state.phase === "input" ? state : { ...state, phase: "input" };
    for (const piece of state.candidates) for (let y = 0; y < 7; y++) for (let x = 0; x < 7; x++) if (!placement3(input, piece.id, { x, y }).reason) moves.push({ pieceId: piece.id, origin: { x, y } });
    return moves;
  }
  function candidateCount2(state) {
    return upgradeStackV2(state, "four_choices") ? upgradeParamV2("four_choices", "candidateCount") : RULES_V2_CONFIG.candidateCount;
  }
  function applyCommandV2(state, command) {
    const reject = (error) => ({ state, events: [], error });
    if (!command || command.type !== "place" && command.type !== "upgrade") return reject("\u672A\u77E5\u6307\u4EE4");
    if (command.type === "upgrade") {
      const upgrade2 = UPGRADES_V2.find((u) => u.id === command.upgradeId);
      if (state.phase !== "upgrade" || !state.upgradeChoices.includes(command.upgradeId) || !upgrade2 || !isUpgradeEligibleV2(state, upgrade2)) return reject("\u5F53\u524D\u4E0D\u80FD\u9009\u62E9\u6B64\u5347\u7EA7");
      const next2 = cloneState3(state);
      next2.upgrades.push(command.upgradeId);
      next2.upgradeChoices = [];
      next2.phase = "input";
      next2.commands.push(copyCommand3(command));
      next2.commandIndex++;
      if (upgrade2.effect === "four_choices") while (next2.candidates.length < candidateCount2(next2)) next2.candidates.push(generatePieceV2(next2));
      return { state: next2, events: [] };
    }
    const checked = placement3(state, command.pieceId, command.origin);
    if (checked.reason) return reject(checked.reason);
    const next = cloneState3(state), index = next.candidates.findIndex((piece2) => piece2.id === command.pieceId), piece = next.candidates[index];
    placePiece2(next, piece, checked.cells);
    next.candidates.splice(index, 1);
    const events = [{ type: "placed", pieceId: piece.id, cells: checked.cells }, ...resolveOldOrders3(next)];
    next.commands.push(copyCommand3(command));
    next.commandIndex++;
    const expired = ageRush2(next);
    if (expired.length) events.push({ type: "rushExpired", cells: expired });
    if (next.completedOrders >= RULES_V2_CONFIG.ordersPerShift * RULES_V2_CONFIG.shiftCount) {
      next.phase = "result";
      next.result = "won";
      next.score += RULES_V2_CONFIG.score.shiftBonus;
      events.push({ type: "result", result: "won" });
      return { state: next, events };
    }
    const shift = Math.min(RULES_V2_CONFIG.shiftCount, Math.floor(next.completedOrders / RULES_V2_CONFIG.ordersPerShift) + 1);
    if (shift > next.shift) {
      next.score += (shift - next.shift) * RULES_V2_CONFIG.score.shiftBonus;
      next.shift = shift;
      events.push({ type: "shift", shift });
    }
    refreshOrders3(next);
    next.candidates.splice(index, 0, generatePieceV2(next));
    while (next.candidates.length < candidateCount2(next)) next.candidates.push(generatePieceV2(next));
    if (!findLegalMovesV2(next).length) {
      next.phase = "result";
      next.result = "failed";
      events.push({ type: "result", result: "failed" });
    } else if (Math.floor(next.completedOrders / RULES_V2_CONFIG.upgradeEvery) > Math.floor(state.completedOrders / RULES_V2_CONFIG.upgradeEvery)) {
      next.phase = "upgrade";
      next.upgradeChoices = generateUpgradeChoicesV2(next);
      events.push({ type: "upgrade" });
    }
    return { state: next, events };
  }

  // src/domain/engine.ts
  function createRun2(seed, mode = "standard", rulesetVersion = 1) {
    if (rulesetVersion === 1) return createRun(seed, mode);
    if (rulesetVersion === 2) return createRunV2(seed, mode);
    if (rulesetVersion === 3) return createRunV3(seed, mode);
    throw Error(`\u4E0D\u652F\u6301\u89C4\u5219\u7248\u672C ${rulesetVersion}`);
  }
  function version(state) {
    if (state.rulesetVersion !== 1 && state.rulesetVersion !== 2 && state.rulesetVersion !== 3) throw Error(`\u4E0D\u652F\u6301\u89C4\u5219\u7248\u672C ${state.rulesetVersion}`);
  }
  function applyCommand2(state, command) {
    version(state);
    return state.rulesetVersion === 1 ? applyCommand(state, command) : state.rulesetVersion === 2 ? applyCommandV2(state, command) : applyCommandV3(state, command);
  }
  function previewPlacement2(state, pieceId, origin) {
    version(state);
    return state.rulesetVersion === 1 ? previewPlacement(state, pieceId, origin) : state.rulesetVersion === 2 ? previewPlacementV2(state, pieceId, origin) : previewPlacementV3(state, pieceId, origin);
  }

  // src/application/save.ts
  var SAVE_KEYS = { main: "warehouse.run.v1", backup: "warehouse.run.backup.v1", temp: "warehouse.run.temp.v1" };
  var CARGO2 = ["cargo.food", "cargo.machine", "cargo.chem", "cargo.electronic", "cargo.cold"];
  var DOCKS2 = ["dock.north", "dock.east", "dock.south", "dock.west"];
  var schemaFor = (rules) => rules === 1 ? 1 : rules === 2 ? 2 : rules === 3 ? 3 : 0;
  var object = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
  var integer = (v, min = 0, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(v) && Number(v) >= min && Number(v) <= max;
  var id = (v) => typeof v === "string" && /^[a-zA-Z0-9_.:-]{1,100}$/.test(v);
  var array = (v, max = 1e5) => Array.isArray(v) && v.length <= max;
  var point = (v) => object(v) && integer(v.x, 0, 6) && integer(v.y, 0, 6);
  function requireValue(ok, message) {
    if (!ok) throw Error(message);
  }
  function assertRun(value) {
    requireValue(object(value), "\u5B58\u6863\u7ED3\u6784\u65E0\u6548");
    requireValue(value.rulesetVersion === P0_CONFIG.rulesetVersion && value.runConfigId === P0_CONFIG.runConfigId || value.rulesetVersion === 2 && value.runConfigId === "run.standard_v2" || value.rulesetVersion === 3 && value.runConfigId === "run.standard_v3", "\u89C4\u5219\u7248\u672C\u4E0D\u517C\u5BB9");
    requireValue(integer(value.seed, -2147483648, 4294967295), "\u79CD\u5B50\u65E0\u6548");
    requireValue(["standard", "daily", "tutorial"].includes(String(value.mode)), "\u6E38\u620F\u6A21\u5F0F\u65E0\u6548");
    requireValue(array(value.rngState, 4) && value.rngState.length === 4 && value.rngState.every((v) => integer(v, -2147483648, 2147483647)), "\u968F\u673A\u72B6\u6001\u65E0\u6548");
    requireValue(array(value.board, 49) && value.board.length === 49 && value.board.every((v) => v === null || CARGO2.includes(String(v))), "\u68CB\u76D8\u5B58\u6863\u65E0\u6548");
    requireValue(array(value.candidates, 4) && (value.candidates.length > 0 || value.rulesetVersion === 3 && value.mode === "tutorial" && value.phase === "result" && value.result === "won"), "\u5019\u9009\u8D27\u7269\u65E0\u6548");
    requireValue(value.candidates.every((v) => object(v) && id(v.id) && SHAPES.some((shape2) => shape2.id === v.shapeId) && CARGO2.includes(String(v.cargo))), "\u5019\u9009\u5185\u5BB9\u65E0\u6548");
    requireValue(new Set(value.candidates.map((v) => v.id)).size === value.candidates.length, "\u5019\u9009\u6807\u8BC6\u91CD\u590D");
    requireValue(array(value.orders, 4) && (value.orders.length > 0 || value.phase === "result" && value.result === "won"), "\u8BA2\u5355\u65E0\u6548");
    requireValue(value.orders.every((v) => object(v) && id(v.id) && DOCKS2.includes(String(v.dockId)) && CARGO2.includes(String(v.cargo)) && integer(v.amount, 1, 49) && integer(v.baseScore, 1, 1e6)), "\u8BA2\u5355\u5185\u5BB9\u65E0\u6548");
    requireValue(new Set(value.orders.map((v) => v.dockId)).size === value.orders.length, "\u7801\u5934\u91CD\u590D");
    requireValue(new Set(value.orders.map((v) => v.cargo)).size === value.orders.length, "\u8BA2\u5355\u8D27\u7C7B\u91CD\u590D");
    requireValue(["input", "upgrade", "result"].includes(String(value.phase)), "\u9636\u6BB5\u65E0\u6548");
    requireValue(integer(value.shift, 1, 5) && integer(value.completedOrders, 0, 1e5) && integer(value.score) && integer(value.lastChain, 0, 64) && integer(value.maxChain, 0, 64) && integer(value.nextId, 0), "\u8FDB\u5EA6\u65E0\u6548");
    requireValue(array(value.upgrades, 1e3) && value.upgrades.every(id) && array(value.upgradeChoices, 3) && value.upgradeChoices.every(id), "\u5347\u7EA7\u5B58\u6863\u65E0\u6548");
    const catalog = value.rulesetVersion === 1 ? UPGRADES : UPGRADES_V2;
    requireValue([...value.upgrades, ...value.upgradeChoices].every((v) => catalog.some((upgrade2) => upgrade2.id === v)), "\u5347\u7EA7\u5185\u5BB9\u5DF2\u53D8\u66F4");
    requireValue(new Set(value.upgradeChoices).size === value.upgradeChoices.length, "\u5347\u7EA7\u5019\u9009\u91CD\u590D");
    requireValue(value.phase !== "upgrade" || value.upgradeChoices.length > 0, "\u5347\u7EA7\u5019\u9009\u7F3A\u5931");
    requireValue(array(value.commands, 1e5) && integer(value.commandIndex) && value.commandIndex === value.commands.length, "\u547D\u4EE4\u7D22\u5F15\u65E0\u6548");
    requireValue(value.commands.every((v) => object(v) && (v.type === "place" && id(v.pieceId) && point(v.origin) || v.type === "upgrade" && id(v.upgradeId) || value.rulesetVersion === 3 && (v.type === "continueOvertime" || v.type === "finishOvertime"))), "\u547D\u4EE4\u5B58\u6863\u65E0\u6548");
    requireValue(value.result === null || value.result === "failed" || value.result === "won", "\u7ED3\u679C\u65E0\u6548");
    requireValue(value.phase === "result" === (value.result !== null), "\u7ED3\u679C\u4E0E\u9636\u6BB5\u4E0D\u4E00\u81F4");
    requireValue(value.runSerial === void 0 || integer(value.runSerial, 1), "\u672C\u5730\u5355\u5C40\u5E8F\u53F7\u65E0\u6548");
    requireValue(value.elapsedMs === void 0 || integer(value.elapsedMs), "\u6E38\u620F\u65F6\u957F\u65E0\u6548");
    requireValue(value.maxOccupancy === void 0 || integer(value.maxOccupancy, 0, 49), "\u6700\u9AD8\u5360\u7528\u8BB0\u5F55\u65E0\u6548");
    requireValue(value.challengeId === void 0 || id(value.challengeId), "\u6311\u6218\u6807\u8BC6\u65E0\u6548");
    requireValue(value.challengeDay === void 0 || typeof value.challengeDay === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value.challengeDay), "\u6311\u6218\u65E5\u671F\u65E0\u6548");
    if (value.rulesetVersion === 2 || value.rulesetVersion === 3) {
      const traits = value.cellTraits, board = value.board;
      requireValue(array(traits, 49) && traits.length === 49, "\u7279\u6B8A\u8D27\u4EF6\u72B6\u6001\u7F3A\u5931");
      requireValue(traits.every((t, i) => t === null || object(t) && board[i] !== null && ["pallet", "rush", "hazard", "wildcard", "waste"].includes(String(t.kind)) && (t.kind !== "rush" || integer(t.remaining, 1, 50) && integer(t.bornAtCommand, 0, Number(value.commandIndex)))), "\u7279\u6B8A\u8D27\u4EF6\u72B6\u6001\u65E0\u6548");
      requireValue(integer(value.generatedPieces, value.rulesetVersion === 3 ? 0 : 1, 1e6), "\u8D27\u4EF6\u751F\u6210\u8BA1\u6570\u65E0\u6548");
      requireValue(value.candidates.every((p) => object(p) && (p.trait === void 0 || ["pallet", "rush", "hazard", "wildcard"].includes(String(p.trait)) && p.shapeId === "shape.single" && (p.trait !== "rush" || integer(p.rushTurns, 1, 50)))), "\u7279\u6B8A\u5019\u9009\u65E0\u6548");
      requireValue(catalog.every((upgrade2) => value.upgrades.filter((id2) => id2 === upgrade2.id).length <= upgrade2.maxStack), "\u5347\u7EA7\u5C42\u6570\u8D85\u9650");
    }
    if (value.rulesetVersion === 3) {
      requireValue(integer(value.tutorialStep, 0, 3) && typeof value.overtime === "boolean", "\u6559\u5B66\u6216\u52A0\u73ED\u72B6\u6001\u7F3A\u5931");
      requireValue(value.endReason === null || ["blocked", "completed", "retired"].includes(String(value.endReason)), "\u7ED3\u7B97\u539F\u56E0\u65E0\u6548");
      requireValue(value.phase === "result" === (value.endReason !== null), "\u7ED3\u7B97\u9636\u6BB5\u4E0E\u539F\u56E0\u4E0D\u4E00\u81F4");
      requireValue(!value.overtime || value.mode === "standard" && value.shift === 5, "\u52A0\u73ED\u6A21\u5F0F\u65E0\u6548");
    }
  }
  function digest(raw) {
    let hash = 2166136261;
    for (let i = 0; i < raw.length; i++) {
      hash ^= raw.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function encodeRun(state) {
    assertRun(state);
    const body = JSON.stringify(state);
    return JSON.stringify({ schemaVersion: schemaFor(state.rulesetVersion), digest: digest(body), state });
  }
  function decodeRun(raw) {
    requireValue(raw.length <= 95e4, "\u5B58\u6863\u8D85\u51FA\u5927\u5C0F\u9650\u5236");
    const value = JSON.parse(raw);
    requireValue(object(value), "\u5B58\u6863\u7ED3\u6784\u65E0\u6548");
    requireValue(value.schemaVersion === 1 || value.schemaVersion === 2 || value.schemaVersion === 3, "\u5B58\u6863\u7248\u672C\u4E0D\u517C\u5BB9");
    requireValue(typeof value.digest === "string" && value.digest === digest(JSON.stringify(value.state)), "\u5B58\u6863\u6821\u9A8C\u5931\u8D25");
    assertRun(value.state);
    requireValue(value.schemaVersion === schemaFor(value.state.rulesetVersion), "\u5B58\u6863\u7248\u672C\u4E0E\u89C4\u5219\u4E0D\u517C\u5BB9");
    return value.state;
  }
  function archiveRaw(storage, key, raw) {
    const archive = `${key}.corrupt.${digest(raw)}`, existing = storage.get(archive);
    requireValue(existing === null || existing === raw, "\u5B58\u6863\u5F52\u6863\u6807\u8BC6\u51B2\u7A81\uFF0C\u5DF2\u505C\u6B62\u8986\u76D6");
    storage.set(archive, raw);
    requireValue(storage.get(archive) === raw, "\u635F\u574F\u5B58\u6863\u5907\u4EFD\u5931\u8D25");
  }
  function loadRun(storage) {
    try {
      const main = storage.get(SAVE_KEYS.main);
      const backup = storage.get(SAVE_KEYS.backup);
      if (main) {
        try {
          return { state: decodeRun(main), source: "main", message: "\u53D1\u73B0\u4E0A\u6B21\u503C\u73ED" };
        } catch (e) {
        }
      }
      if (backup) {
        try {
          return { state: decodeRun(backup), source: "backup", message: "\u4E3B\u5B58\u6863\u4E0D\u53EF\u7528\uFF0C\u53EF\u6062\u590D\u4E0A\u4E00\u4EFD\u5907\u4EFD" };
        } catch (e) {
        }
      }
      return { state: null, source: main || backup ? "corrupt" : "empty", message: main || backup ? "\u5B58\u6863\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u539F\u6587\u4EF6\u5DF2\u4FDD\u7559" : "\u5C1A\u65E0\u5B58\u6863" };
    } catch (e) {
      return { state: null, source: "unavailable", message: "\u65E0\u6CD5\u8BBF\u95EE\u672C\u5730\u5B58\u50A8\uFF0C\u672C\u5C40\u6682\u4E0D\u80FD\u4FDD\u5B58" };
    }
  }
  function saveRun(storage, state) {
    try {
      const raw = encodeRun(state);
      requireValue(raw.length <= 95e4, "\u5B58\u6863\u8D85\u51FA\u5927\u5C0F\u9650\u5236");
      const previous = storage.get(SAVE_KEYS.main);
      if (previous) {
        try {
          decodeRun(previous);
        } catch (e) {
          return { ok: false, message: "\u65E7\u6863\u635F\u574F\uFF0C\u5DF2\u4FDD\u62A4\u539F\u6587\u4EF6\uFF1B\u8BF7\u5148\u9009\u62E9\u6062\u590D\u6216\u65B0\u5F00" };
        }
      }
      storage.set(SAVE_KEYS.temp, raw);
      const verified = storage.get(SAVE_KEYS.temp);
      requireValue(verified === raw, "\u5199\u5165\u6821\u9A8C\u5931\u8D25");
      decodeRun(verified);
      const oldBackup = storage.get(SAVE_KEYS.backup);
      if (oldBackup) {
        try {
          decodeRun(oldBackup);
        } catch (e) {
          archiveRaw(storage, SAVE_KEYS.backup, oldBackup);
        }
      }
      if (previous) storage.set(SAVE_KEYS.backup, previous);
      storage.set(SAVE_KEYS.main, raw);
      requireValue(storage.get(SAVE_KEYS.main) === raw, "\u4FDD\u5B58\u8BFB\u56DE\u6821\u9A8C\u5931\u8D25");
      try {
        storage.remove(SAVE_KEYS.temp);
      } catch (e) {
      }
      return { ok: true, message: "\u5DF2\u4FDD\u5B58" };
    } catch (e) {
      return { ok: false, message: "\u4FDD\u5B58\u5931\u8D25\uFF0C\u4E0A\u4E00\u4EFD\u6709\u6548\u5B58\u6863\u4ECD\u4FDD\u7559" };
    }
  }
  function preserveCorrupt(storage) {
    try {
      for (const key of [SAVE_KEYS.main, SAVE_KEYS.backup]) {
        const raw = storage.get(key);
        if (!raw) continue;
        try {
          decodeRun(raw);
          continue;
        } catch (e) {
        }
        archiveRaw(storage, key, raw);
        storage.remove(key);
      }
      return { ok: true, message: "\u539F\u59CB\u635F\u574F\u5B58\u6863\u5DF2\u4FDD\u7559" };
    } catch (e) {
      return { ok: false, message: "\u65E0\u6CD5\u4FDD\u7559\u65E7\u6863\uFF0C\u6682\u4E0D\u8986\u76D6" };
    }
  }

  // src/domain/board.ts
  function orderStatus2(state, order) {
    return state.rulesetVersion >= 2 ? orderStatusV2(state, order) : orderStatus(state, order);
  }

  // src/domain/rulesets/v1/replay.ts
  function checksum(state) {
    const canonical = JSON.stringify([
      state.rulesetVersion,
      state.runConfigId,
      state.seed,
      state.mode,
      state.board,
      state.candidates.map((p) => [p.id, p.shapeId, p.cargo]),
      state.orders.map((o) => [o.id, o.dockId, o.cargo, o.amount, o.baseScore]),
      state.score,
      state.shift,
      state.rngState,
      state.phase,
      state.completedOrders,
      state.lastChain,
      state.maxChain,
      state.upgrades,
      state.upgradeChoices,
      state.commandIndex,
      state.nextId,
      state.result
    ]);
    let hash = 2166136261;
    for (let i = 0; i < canonical.length; i++) {
      hash ^= canonical.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  // src/domain/replay.ts
  function checksum2(state) {
    var _a;
    if (state.rulesetVersion === 1) return checksum(state);
    if (state.rulesetVersion !== 2 && state.rulesetVersion !== 3) throw Error(`\u4E0D\u652F\u6301\u89C4\u5219\u7248\u672C ${state.rulesetVersion}`);
    const fields = [checksum(state), state.candidates.map((p) => {
      var _a2, _b;
      return [(_a2 = p.trait) != null ? _a2 : null, (_b = p.rushTurns) != null ? _b : null];
    }), (_a = state.cellTraits) == null ? void 0 : _a.map((t) => {
      var _a2, _b;
      return t ? [t.kind, (_a2 = t.remaining) != null ? _a2 : null, (_b = t.bornAtCommand) != null ? _b : null] : null;
    }), state.generatedPieces];
    if (state.rulesetVersion === 3) fields.push(state.tutorialStep, state.overtime, state.endReason);
    const data = JSON.stringify(fields);
    let hash = 2166136261;
    for (let i = 0; i < data.length; i++) {
      hash ^= data.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  // src/presentation/diagnostics.ts
  var route = (path) => path.length ? path.map((point2) => `(${point2.x},${point2.y})`).join(">") : "none";
  function weightRows(label, weights) {
    const rows = [];
    for (let i = 0; i < weights.length; i += 3) rows.push(`${label} ${weights.slice(i, i + 3).map(([id2, weight]) => `${id2}=${weight}`).join(" ")}`);
    return rows;
  }
  function generationRows(state, occupancy) {
    var _a, _b;
    if (state.rulesetVersion === 3 && state.mode === "tutorial") return [`generation authored tutorial_step ${(_a = state.tutorialStep) != null ? _a : 0}; \u65E0\u968F\u673A\u8D27\u4EF6\u62BD\u7B7E`];
    const modern = state.rulesetVersion === 3 ? RULES_V3_CONFIG : state.rulesetVersion === 2 ? RULES_V2_CONFIG : null;
    const config = modern != null ? modern : P0_CONFIG;
    const smallBonus = upgradeStackV2(state, "small_parcels") * (modern ? upgradeParamV2("small_parcels", "weightPercent") : P0_CONFIG.upgrade.smallWeightPercent);
    const occupancyBonus = Math.floor(occupancy * config.generation.occupancySmallPercent / 49);
    const rows = ["generation \u5F53\u524D\u72B6\u6001\u6761\u4EF6\u6743\u91CD\uFF1B\u4E0D\u662F\u5386\u53F2\u62BD\u7B7E\u6216\u4E0B\u6B21\u843D\u5B50\u9884\u6D4B"];
    let forcedPallet = false;
    if (!modern) rows.push("special unavailable ruleset v1");
    else if (state.shift < modern.special.minShift) rows.push(`special disabled shift<${modern.special.minShift}`);
    else {
      const nextGeneration = ((_b = state.generatedPieces) != null ? _b : 0) + 1;
      const interval = upgradeParamV2("pallet_supply", "interval");
      forcedPallet = upgradeStackV2(state, "pallet_supply") > 0 && nextGeneration % interval === 0;
      if (forcedPallet) rows.push(`special next_generation ${nextGeneration} forced=pallet interval=${interval} shape=shape.single`);
      else {
        const bonus = upgradeStackV2(state, "wild_supply") * upgradeParamV2("wild_supply", "weightBonus"), weights = modern.special.weights;
        rows.push(`special next_generation ${nextGeneration} normal=${weights.normal - bonus} pallet=${weights.pallet} rush=${weights.rush} hazard=${weights.hazard} wildcard=${weights.wildcard + bonus}`);
      }
      rows.push(`special shape=shape.single; rush_turns ${modern.special.rushTurns + upgradeStackV2(state, "rush_buffer") * upgradeParamV2("rush_buffer", "extraTurns")}`);
    }
    if (!forcedPallet) {
      rows.push(`shape normal only; occupancy_bonus ${occupancyBonus}% small_parcels_bonus ${smallBonus}% repeat_divisor ${config.generation.recentShapeDivisor}`);
      rows.push("shape formula: base\xD7100; \u5C0F\u4EF6\u52A0\u6210\u540E\u5411\u4E0B\u53D6\u6574\uFF1B\u5F53\u524D\u5019\u9009\u91CD\u590D\u518D\u9664\u3001\u53D6\u6574\uFF0C\u6700\u4F4E1");
      const weights = SHAPES.filter((shape2) => shape2.minShift <= state.shift).map((shape2) => {
        let weight = shape2.weight * 100;
        if (shape2.cells.length <= 2) weight = Math.floor(weight * (100 + smallBonus + occupancyBonus) / 100);
        if (state.candidates.some((piece) => piece.shapeId === shape2.id)) weight = Math.floor(weight / config.generation.recentShapeDivisor);
        return [shape2.id, Math.max(1, weight)];
      });
      rows.push(...weightRows("shape_weight", weights));
    }
    rows.push(`cargo formula: 20+inventory\xD7${config.generation.cargoPresenceWeight}; ${modern ? "\u6258\u76D82 / \u5E9F\u72690 / \u5176\u4F591\uFF0C\u6309\u8D27\u4EF6\u539F\u8D27\u7C7B" : "v1\u6309\u5360\u7528\u683C\u6570"}`);
    const cargoWeights = CARGO.slice(0, config.cargoByShift[state.shift - 1]).map((cargo) => {
      const units = state.board.reduce((sum, cell, index) => sum + (cell === cargo.id ? modern ? cellUnitsV2(state, index) : 1 : 0), 0);
      return [cargo.id, 20 + units * config.generation.cargoPresenceWeight];
    });
    rows.push(...weightRows("cargo_weight", cargoWeights));
    return rows;
  }
  function buildDebugRows(state, view) {
    var _a, _b;
    const occupancy = state.board.filter((cell) => cell !== null).length;
    const rows = [
      `ruleset_version ${state.rulesetVersion} | run_config_id ${state.runConfigId}`,
      `seed ${state.seed} | mode ${state.mode} | shift ${state.shift}`,
      `phase ${state.phase} | paused ${view.paused} | board_source committed`,
      `rng_state ${JSON.stringify(state.rngState)}`,
      `command_index ${state.commandIndex} | occupancy ${occupancy}/${state.board.length} (${(occupancy / state.board.length * 100).toFixed(1)}%)`,
      `last_checksum ${checksum2(state)}`,
      ...state.candidates.map((piece) => `candidate ${piece.id} ${piece.shapeId} ${piece.cargo}${piece.trait ? ` trait=${piece.trait}` : ""}${piece.rushTurns !== void 0 ? ` rush_turns=${piece.rushTurns}` : ""}`)
    ];
    if (!state.candidates.length) rows.push("candidates none");
    for (const order of state.orders) {
      const status = orderStatus2(state, order);
      rows.push(`order ${order.id} ${order.dockId} ${order.cargo} ${status.count}/${order.amount} eligibility ${status.status}${status.reason ? ` (${status.reason})` : ""}`);
      rows.push(`canonical_route ${order.id} ${route(status.path)}`);
    }
    if (!state.orders.length) rows.push("active_orders none");
    const limit = state.rulesetVersion === 3 ? RULES_V3_CONFIG.resolutionLimit : state.rulesetVersion === 2 ? RULES_V2_CONFIG.resolutionLimit : P0_CONFIG.resolutionLimit;
    if (view.animation) {
      const shipment = view.animation.shipment;
      rows.push(`resolution_step ${shipment.chain}/${limit} animation | last_chain ${state.lastChain}`);
      rows.push(`animation ${shipment.orderId} canonical_route ${route(shipment.path)}`);
    } else if ((_a = view.preview) == null ? void 0 : _a.valid) {
      rows.push(`resolution_step 0/${limit} preview_steps ${view.preview.shipments.length} | last_chain ${state.lastChain}`);
      for (const shipment of view.preview.shipments) rows.push(`preview_step ${shipment.chain} ${shipment.orderId} canonical_route ${route(shipment.path)}`);
    } else {
      rows.push(`resolution_step 0/${limit} idle | last_chain ${state.lastChain}`);
      if (view.preview) rows.push(`preview invalid ${(_b = view.preview.reason) != null ? _b : "unknown"}`);
    }
    return [...rows, ...generationRows(state, occupancy)];
  }

  // src/presentation/debug-layout.ts
  var DEBUG_PREVIOUS = { x: 180, y: 1540, w: 310, h: 84 };
  var DEBUG_NEXT = { x: 590, y: 1540, w: 310, h: 84 };
  function debugPages(state, view) {
    const lines = [];
    for (const row of buildDebugRows(state, view)) {
      let line = "", width = 0;
      for (const char of row) {
        const units = char.charCodeAt(0) > 255 ? 2 : 1;
        if (width + units > 64) {
          lines.push(line);
          line = "  ";
          width = 2;
        }
        line += char;
        width += units;
      }
      lines.push(line);
    }
    const pages = [];
    for (let i = 0; i < lines.length; i += 24) pages.push(lines.slice(i, i + 24));
    return pages.length ? pages : [[]];
  }

  // src/application/profile.ts
  function createProfile() {
    return { schemaVersion: 1, settings: { sound: true, reducedMotion: false }, cosmetics: { theme: "day", forklift: "yellow", cargo: "classic" }, tutorialComplete: false, stats: { runs: 0, orders: 0, wins: 0, maxChain: 0 }, bestScores: {}, dailyHistory: {}, achievements: [], nextRunSerial: 1, lastRecordedRun: null };
  }
  var THEMES = [{ id: "day", name: "\u65E5\u73ED\u4ED3\u5E93", description: "\u660E\u4EAE\u7684\u65E5\u73ED\u8272\u8C03\uFF0C\u4EC5\u6539\u53D8\u5916\u89C2" }, { id: "night", name: "\u591C\u73ED\u4ED3\u5E93", description: "\u6DF1\u8272\u591C\u73ED\u8272\u8C03\uFF0C\u4EC5\u6539\u53D8\u5916\u89C2" }];
  var FORKLIFTS = [{ id: "yellow", name: "\u9EC4\u8272\u53C9\u8F66", description: "\u9ED8\u8BA4\u6D82\u88C5\uFF0C\u4EC5\u6539\u53D8\u5916\u89C2" }, { id: "blue", name: "\u84DD\u8272\u53C9\u8F66", description: "\u5B8C\u6210\u9996\u6B21\u6B63\u5F0F\u51FA\u8D27\u89E3\u9501", achievementId: "first_shipment" }, { id: "red", name: "\u7EA2\u8272\u53C9\u8F66", description: "\u5B8C\u6210\u6807\u51C6\u4E94\u73ED\u80DC\u5229\u89E3\u9501", achievementId: "five_shifts" }];
  var CARGO_STYLES = [{ id: "classic", name: "\u7ECF\u5178\u8D27\u7BB1", description: "\u9ED8\u8BA4\u8D27\u7BB1\u5916\u89C2" }, { id: "outline", name: "\u9192\u76EE\u8F6E\u5ED3", description: "\u66F4\u6E05\u6670\u7684\u8D27\u7BB1\u8F6E\u5ED3\uFF0C\u4EC5\u6539\u53D8\u5916\u89C2" }];
  var ACHIEVEMENTS = [{ id: "first_shipment", name: "\u9996\u6B21\u51FA\u8D27", description: "\u6B63\u5F0F\u5C40\u7D2F\u8BA1\u5B8C\u6210 1 \u4E2A\u8BA2\u5355\uFF0C\u89E3\u9501\u84DD\u8272\u53C9\u8F66" }, { id: "chain_3", name: "\u8FDE\u9501\u9AD8\u624B", description: "\u6B63\u5F0F\u5C40\u8FBE\u6210 3 \u8FDE\u9501" }, { id: "five_shifts", name: "\u4E94\u73ED\u5168\u52E4", description: "\u5B8C\u6210\u4E00\u6B21\u6807\u51C6\u4E94\u73ED\u80DC\u5229\uFF0C\u89E3\u9501\u7EA2\u8272\u53C9\u8F66" }, { id: "ship_100", name: "\u767E\u5355\u8001\u624B", description: "\u6B63\u5F0F\u5C40\u7D2F\u8BA1\u5B8C\u6210 100 \u4E2A\u8BA2\u5355" }];
  var PROFILE_KEYS = { main: "warehouse.profile.v1", backup: "warehouse.profile.backup.v1", temp: "warehouse.profile.temp.v1" };
  var MAX_PROFILE_LENGTH = 256e3;
  var MAX_BEST_SCORES = 128;
  var MAX_DAILY_DAYS = 60;
  var MAX_DAILY_RECORDS = 240;
  var MAX_RULESET = 9999;
  var MAX = Number.MAX_SAFE_INTEGER;
  var object2 = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
  var integer2 = (v, min = 0, max = MAX) => Number.isSafeInteger(v) && Number(v) >= min && Number(v) <= max;
  function requireValue2(value, message) {
    if (!value) throw Error(message);
  }
  function keys(value, expected) {
    const actual = Object.keys(value);
    return actual.length === expected.length && actual.every((key) => expected.includes(key));
  }
  function digest2(raw) {
    let hash = 2166136261;
    for (let i = 0; i < raw.length; i++) {
      hash ^= raw.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  var known = (list, id2) => typeof id2 === "string" && list.some((item) => item.id === id2);
  function dayValid(day) {
    if (typeof day !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(day)) return false;
    const epoch = Date.parse(`${day}T00:00:00.000Z`);
    return Number.isFinite(epoch) && new Date(epoch).toISOString().slice(0, 10) === day;
  }
  function dailyIdentity(day, rulesetVersion) {
    const id2 = `daily.${day}.v${rulesetVersion}`;
    return { id: id2, day, seed: parseInt(digest2(id2), 16), rulesetVersion, timeZone: "Asia/Shanghai", localOnly: true };
  }
  function localDailyChallenge(epochMs, rulesetVersion) {
    requireValue2(integer2(epochMs, -864e13, 864e13 - 288e5), "\u65E5\u671F\u65E0\u6548");
    requireValue2(integer2(rulesetVersion, 1, MAX_RULESET), "\u89C4\u5219\u7248\u672C\u65E0\u6548");
    const day = new Date(epochMs + 288e5).toISOString().slice(0, 10);
    requireValue2(dayValid(day), "\u65E5\u671F\u65E0\u6548");
    return dailyIdentity(day, rulesetVersion);
  }
  function assertProfile(value) {
    requireValue2(object2(value), "\u957F\u671F\u8BB0\u5F55\u7ED3\u6784\u65E0\u6548");
    requireValue2(value.schemaVersion === 1, "\u957F\u671F\u8BB0\u5F55\u7248\u672C\u4E0D\u517C\u5BB9");
    requireValue2(keys(value, ["schemaVersion", "settings", "cosmetics", "tutorialComplete", "stats", "bestScores", "dailyHistory", "achievements", "nextRunSerial", "lastRecordedRun", ...value.resetCursor === void 0 ? [] : ["resetCursor"]]), "\u957F\u671F\u8BB0\u5F55\u5B57\u6BB5\u65E0\u6548");
    const settings = value.settings, cosmetics = value.cosmetics, stats = value.stats;
    requireValue2(object2(settings) && keys(settings, ["sound", "reducedMotion"]) && typeof settings.sound === "boolean" && typeof settings.reducedMotion === "boolean", "\u8BBE\u7F6E\u65E0\u6548");
    requireValue2(object2(cosmetics) && keys(cosmetics, ["theme", "forklift", "cargo"]) && known(THEMES, cosmetics.theme) && known(FORKLIFTS, cosmetics.forklift) && known(CARGO_STYLES, cosmetics.cargo), "\u5916\u89C2\u65E0\u6548");
    requireValue2(typeof value.tutorialComplete === "boolean", "\u6559\u5B66\u8BB0\u5F55\u65E0\u6548");
    requireValue2(object2(stats) && keys(stats, ["runs", "orders", "wins", "maxChain"]) && integer2(stats.runs) && integer2(stats.orders) && integer2(stats.wins, 0, stats.runs) && integer2(stats.maxChain, 0, 64), "\u7EDF\u8BA1\u65E0\u6548");
    requireValue2(integer2(value.nextRunSerial, 1), "\u503C\u73ED\u5E8F\u53F7\u65E0\u6548");
    requireValue2(value.resetCursor === void 0 || object2(value.resetCursor) && keys(value.resetCursor, ["serial", "commandIndex"]) && integer2(value.resetCursor.serial, 1, value.nextRunSerial - 1) && integer2(value.resetCursor.commandIndex), "\u91CD\u7F6E\u8FB9\u754C\u65E0\u6548");
    const last = value.lastRecordedRun;
    requireValue2(last === null || object2(last) && keys(last, last.ignored === void 0 ? ["serial", "orders", "score"] : ["serial", "orders", "score", "ignored"]) && (last.ignored === void 0 || typeof last.ignored === "boolean") && integer2(last.serial, 1, value.nextRunSerial - 1) && integer2(last.orders) && integer2(last.score), "\u7ED3\u7B97\u8BB0\u5F55\u65E0\u6548");
    requireValue2(Array.isArray(value.achievements) && value.achievements.length <= ACHIEVEMENTS.length && value.achievements.every((id2) => known(ACHIEVEMENTS, id2)) && new Set(value.achievements).size === value.achievements.length, "\u6210\u5C31\u65E0\u6548");
    const achievements = value.achievements;
    requireValue2(!achievements.includes("first_shipment") || stats.orders >= 1, "\u51FA\u8D27\u6210\u5C31\u65E0\u6548");
    requireValue2(!achievements.includes("chain_3") || stats.maxChain >= 3, "\u8FDE\u9501\u6210\u5C31\u65E0\u6548");
    requireValue2(!achievements.includes("five_shifts") || stats.wins >= 1, "\u4E94\u73ED\u6210\u5C31\u65E0\u6548");
    requireValue2(!achievements.includes("ship_100") || stats.orders >= 100, "\u767E\u5355\u6210\u5C31\u65E0\u6548");
    const forklift2 = FORKLIFTS.find((item) => item.id === cosmetics.forklift);
    requireValue2(!forklift2.achievementId || achievements.includes(forklift2.achievementId), "\u53C9\u8F66\u5916\u89C2\u5C1A\u672A\u89E3\u9501");
    requireValue2(object2(value.bestScores) && Object.keys(value.bestScores).length <= MAX_BEST_SCORES, "\u6700\u597D\u6210\u7EE9\u6570\u91CF\u65E0\u6548");
    for (const [key, best] of Object.entries(value.bestScores)) requireValue2(/^(standard|overtime)\.v[1-9]\d{0,3}$/.test(key) && object2(best) && keys(best, ["score", "chain"]) && integer2(best.score) && integer2(best.chain, 0, 64), "\u6700\u597D\u6210\u7EE9\u65E0\u6548");
    requireValue2(object2(value.dailyHistory) && Object.keys(value.dailyHistory).length <= MAX_DAILY_RECORDS, "\u6BCF\u65E5\u8BB0\u5F55\u6570\u91CF\u65E0\u6548");
    const days = /* @__PURE__ */ new Set();
    for (const [key, entry] of Object.entries(value.dailyHistory)) {
      requireValue2(object2(entry) && keys(entry, ["day", "seed", "rulesetVersion", "score", "orders", "won"]) && dayValid(entry.day) && integer2(entry.rulesetVersion, 1, MAX_RULESET) && integer2(entry.score) && integer2(entry.orders) && typeof entry.won === "boolean", "\u6BCF\u65E5\u8BB0\u5F55\u65E0\u6548");
      const identity = dailyIdentity(entry.day, entry.rulesetVersion);
      requireValue2(key === identity.id && entry.seed === identity.seed, "\u6BCF\u65E5\u6311\u6218\u6807\u8BC6\u65E0\u6548");
      days.add(entry.day);
    }
    requireValue2(days.size <= MAX_DAILY_DAYS, "\u6BCF\u65E5\u8BB0\u5F55\u65E5\u671F\u8FC7\u591A");
  }
  function encodeProfile(profile) {
    assertProfile(profile);
    const body = JSON.stringify(profile);
    const raw = JSON.stringify({ schemaVersion: 1, digest: digest2(body), profile });
    requireValue2(raw.length <= MAX_PROFILE_LENGTH, "\u957F\u671F\u8BB0\u5F55\u8D85\u51FA\u5927\u5C0F\u9650\u5236");
    return raw;
  }
  function decodeProfile(raw) {
    requireValue2(typeof raw === "string" && raw.length <= MAX_PROFILE_LENGTH, "\u957F\u671F\u8BB0\u5F55\u8D85\u51FA\u5927\u5C0F\u9650\u5236");
    const envelope = JSON.parse(raw);
    requireValue2(object2(envelope), "\u957F\u671F\u8BB0\u5F55\u7ED3\u6784\u65E0\u6548");
    requireValue2(envelope.schemaVersion === 1, "\u957F\u671F\u8BB0\u5F55\u7248\u672C\u4E0D\u517C\u5BB9");
    requireValue2(object2(envelope.profile) && typeof envelope.digest === "string" && envelope.digest === digest2(JSON.stringify(envelope.profile)), "\u957F\u671F\u8BB0\u5F55\u6821\u9A8C\u5931\u8D25");
    assertProfile(envelope.profile);
    return envelope.profile;
  }
  function allocateRun(profile, minimum = 1) {
    assertProfile(profile);
    requireValue2(integer2(minimum, 1, MAX - 1), "\u503C\u73ED\u5E8F\u53F7\u65E0\u6548");
    const serial = Math.max(profile.nextRunSerial, minimum);
    requireValue2(serial < MAX, "\u503C\u73ED\u5E8F\u53F7\u5DF2\u7528\u5C3D");
    return { profile: { ...profile, nextRunSerial: serial + 1 }, serial };
  }
  function setProfileSettings(profile, patch) {
    assertProfile(profile);
    requireValue2(object2(patch) && Object.keys(patch).every((key) => ["sound", "reducedMotion"].includes(key) && typeof patch[key] === "boolean"), "\u8BBE\u7F6E\u65E0\u6548");
    return { ...profile, settings: { ...profile.settings, ...patch } };
  }
  function setProfileCosmetic(profile, kind, id2) {
    assertProfile(profile);
    const catalogue = kind === "theme" ? THEMES : kind === "forklift" ? FORKLIFTS : kind === "cargo" ? CARGO_STYLES : null;
    const item = catalogue == null ? void 0 : catalogue.find((item2) => item2.id === id2);
    if (!item) return { profile, error: "\u672A\u77E5\u5916\u89C2" };
    if (item.achievementId && !profile.achievements.includes(item.achievementId)) return { profile, error: "\u8BE5\u5916\u89C2\u5C1A\u672A\u89E3\u9501" };
    return { profile: { ...profile, cosmetics: { ...profile.cosmetics, [kind]: id2 } } };
  }
  var add2 = (left, right) => Math.min(MAX, left + right);
  function trimDaily(history) {
    const entries = Object.entries(history).sort(([a, x], [b, y]) => y.day.localeCompare(x.day) || y.rulesetVersion - x.rulesetVersion || a.localeCompare(b));
    const days = /* @__PURE__ */ new Set();
    return Object.fromEntries(entries.filter(([, entry]) => {
      days.add(entry.day);
      return days.size <= MAX_DAILY_DAYS;
    }).slice(0, MAX_DAILY_RECORDS));
  }
  function recordResult(profile, run) {
    var _a, _b, _c, _d;
    assertProfile(profile);
    if (run.phase !== "result" || !["won", "failed"].includes(String(run.result)) || !integer2(run.runSerial, 1, MAX - 1) || !integer2(run.completedOrders) || !integer2(run.score) || !integer2(run.maxChain, 0, 64) || !integer2(run.rulesetVersion, 1, MAX_RULESET) || !["standard", "daily", "tutorial"].includes(run.mode)) return profile;
    const cutoff = profile.resetCursor;
    if (cutoff && (run.runSerial < cutoff.serial || run.runSerial === cutoff.serial && run.commandIndex <= cutoff.commandIndex)) return profile;
    const previous = profile.lastRecordedRun;
    if (previous && run.runSerial < previous.serial) return profile;
    const same = (previous == null ? void 0 : previous.serial) === run.runSerial;
    if (run.mode === "tutorial") return { ...profile, tutorialComplete: profile.tutorialComplete || run.result === "won", nextRunSerial: Math.max(profile.nextRunSerial, run.runSerial + 1), lastRecordedRun: { serial: run.runSerial, orders: 0, score: 0 } };
    const orders = same ? Math.max(0, run.completedOrders - previous.orders) : run.completedOrders;
    const clearedStandard = run.mode === "standard" && (run.result === "won" || run.overtime === true);
    const newlyCredited = !same || !!(previous == null ? void 0 : previous.ignored);
    const stats = { runs: add2(profile.stats.runs, newlyCredited ? 1 : 0), orders: add2(profile.stats.orders, orders), wins: add2(profile.stats.wins, newlyCredited && (run.result === "won" || clearedStandard) ? 1 : 0), maxChain: Math.max(profile.stats.maxChain, run.maxChain) };
    const bestScores = { ...profile.bestScores };
    let dailyHistory = { ...profile.dailyHistory };
    if (run.mode === "standard") {
      const key = `${run.overtime ? "overtime" : "standard"}.v${run.rulesetVersion}`, best = bestScores[key];
      bestScores[key] = { score: Math.max((_a = best == null ? void 0 : best.score) != null ? _a : 0, run.score), chain: Math.max((_b = best == null ? void 0 : best.chain) != null ? _b : 0, run.maxChain) };
      const retained = Object.keys(bestScores).sort((a, b) => Number(b.split(".v")[1]) - Number(a.split(".v")[1]) || a.localeCompare(b)).slice(MAX_BEST_SCORES);
      for (const old of retained) delete bestScores[old];
    } else if (dayValid(run.challengeDay)) {
      const challenge = dailyIdentity(run.challengeDay, run.rulesetVersion);
      if (run.challengeId === challenge.id && run.seed === challenge.seed) {
        const old = dailyHistory[challenge.id];
        dailyHistory[challenge.id] = { day: challenge.day, seed: challenge.seed, rulesetVersion: challenge.rulesetVersion, score: Math.max((_c = old == null ? void 0 : old.score) != null ? _c : 0, run.score), orders: Math.max((_d = old == null ? void 0 : old.orders) != null ? _d : 0, run.completedOrders), won: !!(old == null ? void 0 : old.won) || run.result === "won" };
        dailyHistory = trimDaily(dailyHistory);
      }
    }
    const achievements = [...profile.achievements];
    for (const [id2, achieved] of [["first_shipment", stats.orders >= 1], ["chain_3", stats.maxChain >= 3], ["five_shifts", clearedStandard], ["ship_100", stats.orders >= 100]]) if (achieved && !achievements.includes(id2)) achievements.push(id2);
    return { ...profile, stats, bestScores, dailyHistory, achievements, nextRunSerial: Math.max(profile.nextRunSerial, run.runSerial + 1), lastRecordedRun: { serial: run.runSerial, orders: Math.max(same ? previous.orders : 0, run.completedOrders), score: Math.max(same ? previous.score : 0, run.score) } };
  }
  function parsed(raw) {
    if (raw === null) return null;
    try {
      return decodeProfile(raw);
    } catch (e) {
      return null;
    }
  }
  function loadProfile(storage) {
    try {
      const main = storage.get(PROFILE_KEYS.main), backup = storage.get(PROFILE_KEYS.backup), profile = parsed(main), fallback = parsed(backup);
      if (profile) return { profile, source: "main", message: "\u5DF2\u8BFB\u53D6\u672C\u5730\u957F\u671F\u8BB0\u5F55" };
      if (fallback) return { profile: fallback, source: "backup", message: "\u4E3B\u8BB0\u5F55\u4E0D\u53EF\u7528\uFF0C\u53EF\u6062\u590D\u4E0A\u4E00\u4EFD\u957F\u671F\u8BB0\u5F55\u5907\u4EFD" };
      return { profile: createProfile(), source: main !== null || backup !== null ? "corrupt" : "empty", message: main !== null || backup !== null ? "\u957F\u671F\u8BB0\u5F55\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u539F\u59CB\u5185\u5BB9\u5DF2\u4FDD\u7559" : "\u5C1A\u65E0\u957F\u671F\u8BB0\u5F55" };
    } catch (e) {
      return { profile: createProfile(), source: "unavailable", message: "\u65E0\u6CD5\u8BBF\u95EE\u672C\u5730\u5B58\u50A8\uFF0C\u957F\u671F\u8BB0\u5F55\u6682\u4E0D\u80FD\u4FDD\u5B58" };
    }
  }
  function archiveRaw2(storage, key, raw) {
    const archive = `${key}.archive.${digest2(raw)}`, existing = storage.get(archive);
    requireValue2(existing === null || existing === raw, "\u957F\u671F\u8BB0\u5F55\u5F52\u6863\u6807\u8BC6\u51B2\u7A81");
    storage.set(archive, raw);
    requireValue2(storage.get(archive) === raw, "\u957F\u671F\u8BB0\u5F55\u5F52\u6863\u6821\u9A8C\u5931\u8D25");
  }
  function restore(storage, key, raw) {
    try {
      if (raw === null) storage.remove(key);
      else storage.set(key, raw);
    } catch (e) {
    }
  }
  function writeProfile(storage, profile, replace = false) {
    let previous = null, backup = null, changed = false;
    try {
      const raw = encodeProfile(profile);
      previous = storage.get(PROFILE_KEYS.main);
      backup = storage.get(PROFILE_KEYS.backup);
      if (!replace && previous !== null && !parsed(previous)) return { ok: false, message: "\u65E7\u957F\u671F\u8BB0\u5F55\u635F\u574F\uFF0C\u5DF2\u4FDD\u62A4\u539F\u6587\uFF1B\u8BF7\u5148\u9009\u62E9\u6062\u590D\u6216\u91CD\u7F6E" };
      if (replace) {
        for (const [key, value] of [[PROFILE_KEYS.main, previous], [PROFILE_KEYS.backup, backup]]) if (value !== null) archiveRaw2(storage, key, value);
      } else if (backup !== null && !parsed(backup)) archiveRaw2(storage, PROFILE_KEYS.backup, backup);
      storage.set(PROFILE_KEYS.temp, raw);
      const verified = storage.get(PROFILE_KEYS.temp);
      requireValue2(verified === raw, "\u4E34\u65F6\u5199\u5165\u6821\u9A8C\u5931\u8D25");
      decodeProfile(verified);
      changed = true;
      if (replace || previous !== null) {
        const nextBackup = replace ? raw : previous;
        storage.set(PROFILE_KEYS.backup, nextBackup);
        requireValue2(storage.get(PROFILE_KEYS.backup) === nextBackup, "\u5907\u4EFD\u8BFB\u56DE\u6821\u9A8C\u5931\u8D25");
      }
      storage.set(PROFILE_KEYS.main, raw);
      requireValue2(storage.get(PROFILE_KEYS.main) === raw, "\u957F\u671F\u8BB0\u5F55\u4FDD\u5B58\u8BFB\u56DE\u6821\u9A8C\u5931\u8D25");
      try {
        storage.remove(PROFILE_KEYS.temp);
      } catch (e) {
      }
      return { ok: true, message: "\u957F\u671F\u8BB0\u5F55\u5DF2\u4FDD\u5B58" };
    } catch (e) {
      if (changed) {
        restore(storage, PROFILE_KEYS.main, previous);
        restore(storage, PROFILE_KEYS.backup, backup);
      }
      return { ok: false, message: "\u957F\u671F\u8BB0\u5F55\u4FDD\u5B58\u5931\u8D25\uFF0C\u65E7\u8BB0\u5F55\u5DF2\u4FDD\u62A4" };
    }
  }
  function saveProfile(storage, profile) {
    return writeProfile(storage, profile);
  }
  function recoverProfile(storage) {
    const loaded = loadProfile(storage);
    if (loaded.source === "unavailable") return { ok: false, message: loaded.message };
    if (loaded.source === "main") return { ok: true, message: "\u957F\u671F\u8BB0\u5F55\u6709\u6548\uFF0C\u65E0\u9700\u6062\u590D" };
    const result = writeProfile(storage, loaded.profile, true);
    return result.ok ? { ok: true, message: loaded.source === "backup" ? "\u539F\u59CB\u8BB0\u5F55\u5DF2\u5F52\u6863\uFF0C\u5DF2\u6062\u590D\u6709\u6548\u5907\u4EFD" : "\u539F\u59CB\u8BB0\u5F55\u5DF2\u5F52\u6863\uFF0C\u5DF2\u5EFA\u7ACB\u65B0\u8BB0\u5F55" } : result;
  }
  function resetProfile(storage, minimumNextSerial = 1, activeRun) {
    try {
      requireValue2(integer2(minimumNextSerial, 1), "\u503C\u73ED\u5E8F\u53F7\u65E0\u6548");
      const loaded = loadProfile(storage);
      if (loaded.source === "unavailable") return { ok: false, message: loaded.message };
      const profile = createProfile();
      profile.nextRunSerial = Math.max(minimumNextSerial, loaded.profile.nextRunSerial);
      const previous = loaded.profile.lastRecordedRun;
      if (activeRun && integer2(activeRun.runSerial, 1) && integer2(activeRun.commandIndex)) {
        profile.nextRunSerial = Math.max(profile.nextRunSerial, activeRun.runSerial + 1);
        profile.resetCursor = { serial: activeRun.runSerial, commandIndex: activeRun.commandIndex };
        if (activeRun.phase === "result") profile.lastRecordedRun = { serial: activeRun.runSerial, orders: activeRun.completedOrders, score: activeRun.score, ignored: true };
        else if (previous) profile.lastRecordedRun = { ...previous, ignored: true };
      } else if (previous) {
        profile.resetCursor = { serial: previous.serial, commandIndex: MAX };
        profile.lastRecordedRun = { ...previous, ignored: true };
      }
      const result = writeProfile(storage, profile, true);
      return result.ok ? { ok: true, message: "\u957F\u671F\u8BB0\u5F55\u5DF2\u91CD\u7F6E\uFF1B\u5F53\u524D\u503C\u73ED\u4ECD\u4FDD\u7559\uFF0C\u4E4B\u540E\u7ED3\u7B97\u4F1A\u8BA1\u5165\u65B0\u8BB0\u5F55", profile } : result;
    } catch (e) {
      return { ok: false, message: "\u91CD\u7F6E\u5931\u8D25\uFF0C\u65E7\u957F\u671F\u8BB0\u5F55\u5DF2\u4FDD\u62A4" };
    }
  }

  // src/presentation/ui.ts
  var wide = (y, h = 114) => ({ x: 210, y, w: 660, h });
  var settingsRow = (y) => ({ x: 132, y, w: 816, h: 106 });
  var control = (rect, label, action) => ({ rect, label, action });
  function getUiControls(state, view) {
    var _a, _b, _c, _d, _e;
    if (view.confirmation) {
      const label = view.confirmation.kind === "resetProfile" ? "\u786E\u8BA4\u91CD\u7F6E" : view.confirmation.kind === "finishOvertime" ? "\u7ED3\u675F\u5E76\u7ED3\u7B97" : "\u5F00\u59CB\u65B0\u5C40";
      return [control({ x: 186, y: 1160, w: 330, h: 118 }, "\u53D6\u6D88", { type: "cancel" }), control({ x: 564, y: 1160, w: 330, h: 118 }, label, { type: "confirm" })];
    }
    if (view.needsResume) return [];
    if (view.screen === "menu") return [
      control(wide(850), "\u5F00\u59CB\u6807\u51C6\u503C\u73ED", { type: "newRun", mode: "standard" }),
      control(wide(994), "\u672C\u5730\u6BCF\u65E5\u6311\u6218", { type: "newRun", mode: "daily" }),
      { ...control(wide(1138), "\u7EE7\u7EED\u4E0A\u6B21\u503C\u73ED", { type: "continue" }), disabled: !view.canContinue },
      control(wide(1282), "\u8BBE\u7F6E\u4E0E\u5916\u89C2", { type: "settings" })
    ];
    if (view.screen === "settings") {
      const options = (catalogue, kind, y) => {
        const gap = 18, w = (816 - gap * (catalogue.length - 1)) / catalogue.length;
        return catalogue.map((item, index) => {
          var _a2, _b2;
          const disabled = !!item.achievementId && !((_a2 = view.profile) == null ? void 0 : _a2.achievements.includes(item.achievementId));
          const unlock = item.achievementId === "first_shipment" ? "\u9996\u6B21\u51FA\u8D27\u89E3\u9501" : "\u4E94\u73ED\u5168\u52E4\u89E3\u9501";
          return { rect: { x: 132 + index * (w + gap), y, w, h: 112 }, action: { type: "cosmetic", kind, id: item.id }, label: disabled ? `${item.name}
${unlock}` : item.name, disabled, selected: ((_b2 = view.profile) == null ? void 0 : _b2.cosmetics[kind]) === item.id };
        });
      };
      return [
        { ...control(settingsRow(355), `\u58F0\u97F3\uFF1A${((_a = view.profile) == null ? void 0 : _a.settings.sound) !== false ? "\u5F00" : "\u5173"}`, { type: "toggleSound" }), selected: ((_b = view.profile) == null ? void 0 : _b.settings.sound) !== false },
        { ...control(settingsRow(493), `\u7B80\u5316\u52A8\u6548\uFF1A${((_c = view.profile) == null ? void 0 : _c.settings.reducedMotion) ? "\u5F00" : "\u5173"}`, { type: "toggleMotion" }), selected: !!((_d = view.profile) == null ? void 0 : _d.settings.reducedMotion) },
        ...options(THEMES, "theme", 725),
        ...options(FORKLIFTS, "forklift", 978),
        ...options(CARGO_STYLES, "cargo", 1226),
        ...view.profileNeedsRecovery ? [control(settingsRow(1504), "\u6062\u590D\u672C\u5730\u957F\u671F\u8BB0\u5F55", { type: "recoverProfile" })] : [],
        control(settingsRow(1636), "\u91CD\u7F6E\u957F\u671F\u8BB0\u5F55", { type: "resetProfile" }),
        control(settingsRow(1768), "\u8FD4\u56DE", { type: "back" })
      ];
    }
    if (view.paused) return [
      control({ ...L.resume }, "\u7EE7\u7EED\u5DE5\u4F5C", { type: "continue" }),
      control({ ...L.restart }, "\u8FD4\u56DE\u4E3B\u9875 \xB7 \u4FDD\u7559\u8FDB\u5EA6", { type: "home" }),
      control({ ...L.restart, y: 1390 }, "\u8BBE\u7F6E\u4E0E\u5916\u89C2", { type: "settings" }),
      ...state.overtime ? [control({ ...L.restart, y: 1540 }, "\u7ED3\u675F\u52A0\u73ED\u5E76\u7ED3\u7B97", { type: "finishOvertime" })] : []
    ];
    if (state.phase === "result" && ((_e = view.noticeFx) == null ? void 0 : _e.kind) === "fail") return [];
    if (state.phase === "result" && !view.animation) {
      const overtime = state.rulesetVersion === 3 && state.mode === "standard" && state.result === "won" && state.shift === 5 && !state.overtime;
      return [
        ...overtime ? [control({ ...L.resume }, "\u7EE7\u7EED\u52A0\u73ED \xB7 \u6311\u6218\u66F4\u9AD8\u5206", { type: "continueOvertime" })] : [],
        control({ ...L.restart }, state.mode === "tutorial" ? "\u5F00\u59CB\u6B63\u5F0F\u503C\u73ED" : state.mode === "daily" ? "\u518D\u8BD5\u4ECA\u65E5\u6311\u6218" : "\u518D\u6765\u4E00\u5C40", { type: "newRun", mode: state.mode === "daily" ? "daily" : "standard" }),
        control({ ...L.restart, y: 1390 }, "\u8FD4\u56DE\u4E3B\u9875", { type: "home" })
      ];
    }
    return [];
  }

  // src/presentation/input.ts
  var InputController = class {
    constructor(port) {
      this.active = null;
      this.start = null;
      this.dragging = false;
      this.routeReady = false;
      this.button = null;
      this.port = port;
    }
    canPlace() {
      const v = this.port.getView();
      return !v.debug && !v.paused && !v.needsResume && !v.animation && !v.confirmation && (!v.screen || v.screen === "game") && this.port.getState().phase === "input";
    }
    captureButton(point2, rect, act) {
      if (!hitTestPoint(point2, rect)) return false;
      this.button = { rect, act };
      return true;
    }
    down(point2, id2 = 0) {
      var _a, _b;
      if (this.active !== null) return;
      this.active = id2;
      this.start = point2;
      this.dragging = false;
      this.button = null;
      this.routeReady = false;
      const v = this.port.getView(), s = this.port.getState();
      if (v.confirmation || !v.needsResume && v.profile && (v.screen === "menu" || v.screen === "settings" || v.paused || s.phase === "result")) {
        const control2 = getUiControls(s, v).find((c) => !c.disabled && hitTestPoint(point2, c.rect));
        if (control2) this.button = { rect: control2.rect, act: () => {
          var _a2, _b2;
          return (_b2 = (_a2 = this.port).action) == null ? void 0 : _b2.call(_a2, control2.action);
        } };
        return;
      }
      if (v.needsResume) {
        if (!this.captureButton(point2, L.resume, () => this.port.resume())) this.captureButton(point2, L.restart, () => this.port.restart());
        return;
      }
      if (v.paused) {
        if (!this.captureButton(point2, L.resume, () => this.port.togglePause()) && !this.captureButton(point2, L.restart, () => this.port.restart())) this.captureButton(point2, L.pause, () => this.port.togglePause());
        return;
      }
      if (v.debug) {
        if (!this.captureButton(point2, L.debug, () => this.port.toggleDebug()) && !this.captureButton(point2, DEBUG_PREVIOUS, () => {
          var _a2;
          return this.port.patchView({ debugPage: Math.max(0, ((_a2 = v.debugPage) != null ? _a2 : 0) - 1) });
        })) this.captureButton(point2, DEBUG_NEXT, () => {
          var _a2;
          return this.port.patchView({ debugPage: ((_a2 = v.debugPage) != null ? _a2 : 0) + 1 });
        });
        return;
      }
      if (v.animation) return;
      if (s.phase === "result") {
        this.captureButton(point2, L.restart, () => this.port.restart());
        return;
      }
      if (s.phase === "upgrade") {
        const index2 = L.upgradeRects.findIndex((rect) => hitTestPoint(point2, rect));
        if (index2 >= 0 && s.upgradeChoices[index2]) this.button = { rect: L.upgradeRects[index2], act: () => this.port.dispatch({ type: "upgrade", upgradeId: s.upgradeChoices[index2] }) };
        return;
      }
      if (this.captureButton(point2, L.pause, () => this.port.togglePause()) || this.captureButton(point2, L.debug, () => this.port.toggleDebug())) return;
      const index = getTrayRects(s.candidates.length).findIndex((rect) => hitTestPoint(point2, rect));
      if (index >= 0 && s.candidates[index]) {
        this.port.patchView({ selectedPieceId: s.candidates[index].id, preview: null, hoverOrigin: null });
        (_b = (_a = this.port).feedback) == null ? void 0 : _b.call(_a, "pick", s.candidates[index].id);
      } else this.updatePreview(point2, false);
    }
    updatePreview(point2, dragging) {
      var _a, _b;
      const pieceId = this.port.getView().selectedPieceId;
      if (!pieceId || !this.canPlace()) return;
      const origin = pointToCell(point2);
      const preview = origin ? this.port.preview(pieceId, origin) : null, ready = !!(preview == null ? void 0 : preview.valid) && preview.shipments.length > 0;
      if (ready && !this.routeReady) (_b = (_a = this.port).feedback) == null ? void 0 : _b.call(_a, "routeReady", pieceId);
      this.routeReady = ready;
      this.port.patchView({ dragPoint: dragging ? point2 : null, hoverOrigin: origin, preview });
    }
    move(point2, id2 = 0) {
      if (this.active !== id2 || this.button || !this.start) return;
      if (!this.canPlace()) {
        this.cancel();
        return;
      }
      if (Math.hypot(point2.x - this.start.x, point2.y - this.start.y) > 14) this.dragging = true;
      this.updatePreview(point2, this.dragging);
    }
    up(point2, id2 = 0) {
      var _a, _b, _c, _d;
      if (this.active !== id2) return;
      const button2 = this.button;
      this.active = null;
      this.button = null;
      this.start = null;
      if (button2) {
        if (hitTestPoint(point2, button2.rect)) button2.act();
        return;
      }
      const pieceId = this.port.getView().selectedPieceId, origin = pointToCell(point2);
      if (pieceId && origin && this.canPlace()) {
        const preview = this.port.preview(pieceId, origin);
        if (preview.valid) {
          this.port.dispatch({ type: "place", pieceId, origin });
          this.port.patchView({ selectedPieceId: null });
        } else {
          this.port.patchView({ message: preview.reason || "\u8FD9\u91CC\u653E\u4E0D\u4E0B\uFF0C\u6362\u4E2A\u4F4D\u7F6E\u8BD5\u8BD5" });
          (_b = (_a = this.port).feedback) == null ? void 0 : _b.call(_a, "invalid", pieceId);
        }
      } else if (this.dragging) {
        this.port.patchView({ selectedPieceId: null });
        if (pieceId) (_d = (_c = this.port).feedback) == null ? void 0 : _d.call(_c, "invalid", pieceId);
      }
      this.dragging = false;
      this.port.patchView({ dragPoint: null, hoverOrigin: null, preview: null });
    }
    cancel(id2) {
      if (id2 !== void 0 && this.active !== id2) return;
      this.active = null;
      this.start = null;
      this.button = null;
      this.dragging = false;
      this.port.patchView({ dragPoint: null, hoverOrigin: null, preview: null, selectedPieceId: null });
    }
  };

  // src/application/session.ts
  var GameSession = class {
    constructor(platform2, options) {
      this.animationQueue = [];
      this.animationStarted = 0;
      this.animationCues = { move: false, delivery: false };
      this.placementStarted = 0;
      this.invalidStarted = 0;
      this.noticeStarted = 0;
      this.lastRouteReady = -Infinity;
      this.pendingNotice = null;
      this.lastTick = 0;
      this.canResume = false;
      this.hasRun = false;
      this.settingsReturn = "menu";
      var _a, _b, _c;
      this.platform = platform2;
      this.lastTick = platform2.now();
      const profile = loadProfile(platform2.storage);
      this.profile = profile.profile;
      const saved = loadRun(platform2.storage);
      const firstLesson = !this.profile.tutorialComplete;
      this.state = (_a = saved.state) != null ? _a : { ...createRun2(options.seed, firstLesson ? "tutorial" : "standard", CURRENT_RULESET), maxOccupancy: 0 };
      this.hasRun = !!saved.state || firstLesson && (saved.source === "empty" || saved.source === "unavailable");
      this.canResume = !!saved.state;
      this.view = { selectedPieceId: null, hoverOrigin: null, preview: null, dragPoint: null, paused: false, message: saved.source === "corrupt" ? saved.message : "\u540C\u7C7B\u51D1\u591F + \u53C9\u8F66\u80FD\u8FC7\u53BB = \u81EA\u52A8\u51FA\u5E93", saveStatus: saved.source === "unavailable" ? saved.message : "\u6BCF\u6B21\u64CD\u4F5C\u81EA\u52A8\u4FDD\u5B58", elapsed: (_c = (_b = saved.state) == null ? void 0 : _b.elapsedMs) != null ? _c : 0, animation: null, debug: false, needsResume: !!saved.state && (saved.state.phase !== "result" || saved.source === "backup") || saved.source === "corrupt", recoveryError: saved.source === "corrupt" ? saved.message : void 0, screen: this.hasRun || saved.source === "corrupt" ? "game" : "menu", profile: this.profile, profileStatus: profile.message, profileNeedsRecovery: profile.source === "backup" || profile.source === "corrupt" || profile.source === "unavailable", dailyLabel: this.daily().day, canContinue: this.hasRun && this.state.phase !== "result", confirmation: null };
      this.input = new InputController({ getState: () => this.state, getView: () => this.view, patchView: (patch) => Object.assign(this.view, patch), preview: (pieceId, origin) => previewPlacement2(this.state, pieceId, origin), dispatch: (command) => this.dispatch(command), togglePause: () => this.togglePause(), restart: () => this.restart(), resume: () => this.resume(), toggleDebug: () => {
        this.input.cancel();
        this.view.debug = !this.view.debug;
        this.view.debugPage = 0;
      }, action: (action) => this.action(action), feedback: (kind, pieceId) => this.feedback(kind, pieceId) });
      if (this.hasRun && !this.view.needsResume) {
        this.ensureSerial();
        if (this.persist()) this.recordFinal();
      }
    }
    daily() {
      var _a, _b, _c;
      return localDailyChallenge((_c = (_b = (_a = this.platform).wallTime) == null ? void 0 : _b.call(_a)) != null ? _c : Date.now(), CURRENT_RULESET);
    }
    updateProfile(profile) {
      this.profile = profile;
      this.view.profile = profile;
      const saved = saveProfile(this.platform.storage, profile);
      this.view.profileStatus = saved.message;
      if (!saved.ok) this.view.profileNeedsRecovery = true;
    }
    ensureSerial() {
      if (this.state.runSerial) return;
      const allocated = allocateRun(this.profile);
      this.state = { ...this.state, runSerial: allocated.serial };
      this.updateProfile(allocated.profile);
    }
    recordFinal() {
      if (this.state.phase !== "result") return;
      try {
        const next = recordResult(this.profile, this.state);
        if (JSON.stringify(next) !== JSON.stringify(this.profile)) this.updateProfile(next);
      } catch (e) {
        this.view.profileStatus = "\u672C\u5C40\u6210\u7EE9\u672A\u5199\u5165\u957F\u671F\u8BB0\u5F55\uFF0C\u5355\u5C40\u5B58\u6863\u4ECD\u72EC\u7ACB\u4FDD\u7559";
        this.view.profileNeedsRecovery = true;
      }
    }
    sound(name) {
      if (this.profile.settings.sound) this.platform.playSound(name);
    }
    routeCue() {
      const now2 = this.platform.now();
      if (now2 - this.lastRouteReady >= 200) {
        this.sound("route_ready");
        this.lastRouteReady = now2;
      }
    }
    feedback(kind, pieceId) {
      if (kind === "routeReady") {
        this.routeCue();
        return;
      }
      this.sound(kind);
      if (kind === "pick") this.view.invalidFx = null;
      if (kind === "invalid") {
        this.invalidStarted = this.platform.now();
        this.view.invalidFx = pieceId && !this.profile.settings.reducedMotion ? { pieceId, progress: 0 } : null;
      }
    }
    clearFeedback() {
      var _a, _b;
      this.animationQueue = [];
      this.view.animation = null;
      this.view.placementFx = null;
      this.view.invalidFx = null;
      this.view.noticeFx = null;
      this.pendingNotice = null;
      (_b = (_a = this.platform).stopSounds) == null ? void 0 : _b.call(_a);
    }
    startNotice(now2) {
      const notice = this.pendingNotice;
      this.pendingNotice = null;
      if (!notice) return;
      this.sound(notice.kind);
      this.noticeStarted = now2;
      const duration = notice.kind === "fail" ? this.profile.settings.reducedMotion ? MOTION.reduced.failMs : MOTION.failMs : this.profile.settings.reducedMotion ? MOTION.reduced.noticeMs : MOTION.noticeMs;
      this.view.noticeFx = duration ? { ...notice, progress: 0 } : null;
    }
    dispatch(command) {
      var _a, _b, _c;
      if (this.view.debug || this.view.paused || this.view.needsResume || this.view.animation || this.view.confirmation || this.view.screen !== "game") return;
      const before = this.state, resolved = applyCommand2(before, command);
      if (resolved.error) {
        this.view.message = resolved.error;
        this.feedback("invalid", command.type === "place" ? command.pieceId : void 0);
        return;
      }
      this.state = resolved.state;
      if (before.maxOccupancy !== void 0) {
        const placed2 = resolved.events.find((event) => event.type === "placed");
        this.state = { ...this.state, maxOccupancy: Math.max(before.maxOccupancy, before.board.filter(Boolean).length + ((_a = placed2 == null ? void 0 : placed2.cells.length) != null ? _a : 0), this.state.board.filter(Boolean).length) };
      }
      this.hasRun = true;
      this.canResume = true;
      this.view.canContinue = this.state.phase !== "result";
      if (this.persist()) this.recordFinal();
      const placed = resolved.events.find((event) => event.type === "placed");
      if (placed) {
        this.placementStarted = this.platform.now();
        this.view.placementFx = this.profile.settings.reducedMotion ? null : { cells: placed.cells.slice(), progress: 0 };
        this.sound("place");
      }
      if (resolved.events.some((event) => event.type === "result" && event.result === "failed")) this.pendingNotice = { kind: "fail", label: "\u6682\u65F6\u653E\u4E0D\u4E0B\u4E86\uFF0C\u4E0B\u4E00\u73ED\u518D\u6765" };
      else if (resolved.events.some((event) => event.type === "shift")) this.pendingNotice = { kind: "shift", label: `\u7B2C ${before.shift} \u73ED\u5B8C\u6210 \xB7 \u8FDB\u5165\u7B2C ${this.state.shift} \u73ED` };
      else if (this.state.phase === "result" && this.state.result === "won" && this.state.mode !== "tutorial" && !this.state.overtime) this.pendingNotice = { kind: "shift", label: "\u4E94\u73ED\u5B8C\u6210\uFF0C\u8F9B\u82E6\u4E86\uFF01" };
      const board = before.board.slice(), cellTraits = (_b = before.cellTraits) == null ? void 0 : _b.map((trait) => trait ? { ...trait } : null);
      for (const event of resolved.events) {
        if (event.type === "placed") {
          const piece = before.candidates.find((p) => p.id === event.pieceId);
          if (piece) for (const cell of event.cells) {
            board[cell] = piece.cargo;
            if (cellTraits) cellTraits[cell] = piece.trait ? { kind: piece.trait, ...piece.trait === "rush" ? { remaining: piece.rushTurns, bornAtCommand: this.state.commandIndex } : {} } : null;
          }
        }
        if (event.type === "shipment") {
          this.animationQueue.push({ shipment: event, board: board.slice(), cellTraits: cellTraits == null ? void 0 : cellTraits.map((trait) => trait ? { ...trait } : null) });
          for (const cell of [...event.cells, ...(_c = event.extraClearedCells) != null ? _c : []]) {
            board[cell] = null;
            if (cellTraits) cellTraits[cell] = null;
          }
        }
      }
      if (this.animationQueue.length) this.nextAnimation(this.platform.now());
      else this.startNotice(this.platform.now());
      if (command.type === "upgrade") this.sound("upgrade");
      this.view.message = this.state.phase === "upgrade" ? "\u9009\u62E9\u4E00\u4E2A\u5347\u7EA7\uFF0C\u7EE7\u7EED\u5F53\u524D\u4ED3\u5E93" : this.state.lastChain > 1 ? `${this.state.lastChain} \u8FDE\u9501\uFF01\u6E05\u51FA\u7684\u901A\u8DEF\u8BA9\u53C9\u8F66\u7EE7\u7EED\u6DF1\u5165` : resolved.events.some((event) => event.type === "shipment") ? "\u8BA2\u5355\u5B8C\u6210\uFF01\u8BB0\u5F97\u7ED9\u53C9\u8F66\u7559\u6761\u8DEF" : "\u8D27\u7269\u5DF2\u5165\u5E93\uFF0C\u7ED9\u540C\u7C7B\u8D27\u7BB1\u7559\u51FA\u8FDE\u63A5\u4F4D\u7F6E";
      if (resolved.events.some((event) => event.type === "rushExpired")) this.view.message = "\u52A0\u6025\u8D27\u4EF6\u5DF2\u8FC7\u671F\u53D8\u5E9F\u5F03\u7269\uFF0C\u53EF\u7528\u5371\u9669\u54C1\u6216\u626B\u8DEF\u6E05\u7406";
    }
    persist() {
      const elapsedMs = Math.floor(this.view.elapsed);
      if (this.state.elapsedMs !== elapsedMs) this.state = { ...this.state, elapsedMs };
      const result = saveRun(this.platform.storage, this.state);
      this.view.saveStatus = result.message;
      return result.ok;
    }
    nextAnimation(now2) {
      const next = this.animationQueue.shift();
      this.animationStarted = now2;
      this.animationCues = { move: false, delivery: false };
      this.view.animation = next ? { ...next, progress: 0 } : null;
      if (next) this.routeCue();
      else this.startNotice(now2);
    }
    tick(now2) {
      const delta = Math.max(0, now2 - this.lastTick);
      this.lastTick = now2;
      if (this.view.screen === "game" && !this.view.paused && !this.view.needsResume && !this.view.confirmation && this.state.phase !== "result") this.view.elapsed += delta;
      const reduced = this.profile.settings.reducedMotion;
      if (this.view.placementFx) {
        this.view.placementFx.progress = Math.max(0, Math.min(1, (now2 - this.placementStarted) / MOTION.placeMs));
        if (reduced || this.view.placementFx.progress >= 1) this.view.placementFx = null;
      }
      if (this.view.invalidFx) {
        this.view.invalidFx.progress = Math.max(0, Math.min(1, (now2 - this.invalidStarted) / MOTION.invalidMs));
        if (reduced || this.view.invalidFx.progress >= 1) this.view.invalidFx = null;
      }
      if (this.view.noticeFx) {
        const duration = this.view.noticeFx.kind === "fail" ? reduced ? MOTION.reduced.failMs : MOTION.failMs : reduced ? MOTION.reduced.noticeMs : MOTION.noticeMs;
        this.view.noticeFx.progress = duration ? Math.max(0, Math.min(1, (now2 - this.noticeStarted) / duration)) : 1;
        if (this.view.noticeFx.progress >= 1) this.view.noticeFx = null;
      }
      if (this.view.animation) {
        const timing = shipmentTiming(reduced), elapsed = Math.max(0, now2 - this.animationStarted), progress = Math.min(1, elapsed / timing.totalMs);
        this.view.animation.progress = progress;
        if (!this.animationCues.move && timing.moveMs > 0 && elapsed >= timing.routeMs && elapsed < timing.routeMs + timing.moveMs) {
          this.animationCues.move = true;
          this.sound("forklift");
        }
        if (!this.animationCues.delivery && elapsed >= timing.routeMs + timing.moveMs) {
          this.animationCues.delivery = true;
          const chain = this.view.animation.shipment.chain;
          this.sound(chain >= 4 ? "chain4" : chain === 3 ? "chain3" : chain === 2 ? "chain2" : "ship");
        }
        if (progress >= 1) this.nextAnimation(now2);
      }
    }
    hide() {
      this.input.cancel();
      this.clearFeedback();
      this.lastTick = this.platform.now();
      this.view.paused = !this.view.needsResume && this.hasRun && this.state.phase !== "result";
      if (this.hasRun && !this.view.needsResume && this.persist()) this.recordFinal();
    }
    show() {
      this.lastTick = this.platform.now();
      this.view.dailyLabel = this.daily().day;
      this.view.message = "\u5DF2\u6062\u590D\u7A33\u5B9A\u5B58\u6863\uFF0C\u70B9\u7EE7\u7EED\u503C\u73ED";
    }
    togglePause() {
      this.input.cancel();
      this.view.paused = !this.view.paused;
      if (this.view.paused) this.clearFeedback();
      this.lastTick = this.platform.now();
      if (this.view.paused && this.persist()) this.recordFinal();
    }
    resume() {
      if (!this.canResume && !this.hasRun) {
        this.view.message = "\u65E7\u6863\u65E0\u6CD5\u8BFB\u53D6\u3002\u8BF7\u9009\u62E9\u65B0\u5F00\u503C\u73ED\uFF0C\u635F\u574F\u539F\u6587\u4F1A\u53E6\u5B58\u4FDD\u7559";
        return;
      }
      const preserved = preserveCorrupt(this.platform.storage);
      if (!preserved.ok) {
        this.view.saveStatus = preserved.message;
        return;
      }
      this.ensureSerial();
      this.view.needsResume = false;
      this.view.paused = false;
      this.view.screen = "game";
      this.lastTick = this.platform.now();
      this.hasRun = true;
      this.canResume = true;
      this.view.canContinue = this.state.phase !== "result";
      if (this.persist()) this.recordFinal();
      this.view.message = "\u7EE7\u7EED\u4E0A\u6B21\u503C\u73ED\uFF0C\u4ED3\u5E93\u72B6\u6001\u5DF2\u6062\u590D";
    }
    restart() {
      this.action({ type: "newRun", mode: "standard" });
    }
    start(mode) {
      var _a, _b;
      const preserved = preserveCorrupt(this.platform.storage);
      if (!preserved.ok) {
        this.view.saveStatus = preserved.message;
        return;
      }
      const daily = mode === "daily" ? this.daily() : null;
      const allocated = allocateRun(this.profile, ((_a = this.state.runSerial) != null ? _a : 0) + 1);
      const next = createRun2((_b = daily == null ? void 0 : daily.seed) != null ? _b : this.state.seed + 1 >>> 0, mode, CURRENT_RULESET);
      next.runSerial = allocated.serial;
      next.maxOccupancy = 0;
      if (daily) {
        next.challengeId = daily.id;
        next.challengeDay = daily.day;
      }
      this.input.cancel();
      this.clearFeedback();
      this.state = next;
      this.hasRun = true;
      this.canResume = true;
      this.lastTick = this.platform.now();
      this.updateProfile(allocated.profile);
      Object.assign(this.view, { screen: "game", needsResume: false, paused: false, animation: null, elapsed: 0, recoveryError: void 0, confirmation: null, canContinue: true, message: daily ? `\u672C\u5730\u6BCF\u65E5\u6311\u6218 ${daily.day} \xB7 \u5317\u4EAC\u65F6\u95F4` : "\u65B0\u7684\u4E00\u73ED\uFF0C\u7ED9\u53C9\u8F66\u7559\u6761\u8DEF" });
      this.persist();
    }
    action(action) {
      var _a, _b, _c, _d;
      if (this.view.confirmation && action.type !== "confirm" && action.type !== "cancel") return;
      if (action.type === "cancel") {
        this.view.confirmation = null;
        return;
      }
      if (action.type === "confirm") {
        const pending = this.view.confirmation;
        if (!pending) return;
        this.view.confirmation = null;
        if (pending.kind === "newRun") this.start((_a = pending.mode) != null ? _a : "standard");
        else if (pending.kind === "finishOvertime") {
          this.view.paused = false;
          this.view.screen = "game";
          this.dispatch({ type: "finishOvertime" });
        } else {
          const reset = resetProfile(this.platform.storage, ((_b = this.state.runSerial) != null ? _b : 0) + 1, this.hasRun ? this.state : void 0);
          this.view.profileStatus = reset.message;
          if (reset.ok && reset.profile) {
            this.profile = reset.profile;
            this.view.profile = reset.profile;
            this.view.profileNeedsRecovery = false;
          }
        }
        return;
      }
      if (action.type === "newRun") {
        if (this.hasRun && this.state.phase !== "result") {
          this.view.confirmation = { kind: "newRun", mode: action.mode };
          return;
        }
        this.start(action.mode);
        return;
      }
      if (action.type === "continue") {
        if (this.hasRun) this.resume();
        return;
      }
      if (action.type === "home") {
        this.input.cancel();
        this.clearFeedback();
        if (this.hasRun && !this.view.needsResume && this.persist()) this.recordFinal();
        this.view.screen = "menu";
        this.view.paused = false;
        this.view.dailyLabel = this.daily().day;
        this.view.canContinue = this.hasRun && this.state.phase !== "result";
        return;
      }
      if (action.type === "settings") {
        this.input.cancel();
        this.clearFeedback();
        this.settingsReturn = this.view.screen === "menu" ? "menu" : "game";
        if (this.settingsReturn === "game") this.view.paused = true;
        this.view.screen = "settings";
        return;
      }
      if (action.type === "back") {
        this.view.screen = this.settingsReturn;
        return;
      }
      if (action.type === "toggleSound") {
        this.updateProfile(setProfileSettings(this.profile, { sound: !this.profile.settings.sound }));
        if (!this.profile.settings.sound) (_d = (_c = this.platform).stopSounds) == null ? void 0 : _d.call(_c);
        return;
      }
      if (action.type === "toggleMotion") {
        this.updateProfile(setProfileSettings(this.profile, { reducedMotion: !this.profile.settings.reducedMotion }));
        return;
      }
      if (action.type === "cosmetic") {
        const result = setProfileCosmetic(this.profile, action.kind, action.id);
        if (result.error) {
          this.view.profileStatus = result.error;
          return;
        }
        this.updateProfile(result.profile);
        return;
      }
      if (action.type === "resetProfile") {
        this.view.confirmation = { kind: "resetProfile" };
        return;
      }
      if (action.type === "recoverProfile") {
        const result = recoverProfile(this.platform.storage);
        this.view.profileStatus = result.message;
        if (result.ok) {
          const profile = loadProfile(this.platform.storage);
          this.profile = profile.profile;
          this.view.profile = this.profile;
          this.view.profileNeedsRecovery = false;
        }
        return;
      }
      if (action.type === "continueOvertime") {
        this.view.paused = false;
        this.view.screen = "game";
        this.dispatch({ type: "continueOvertime" });
        return;
      }
      if (action.type === "finishOvertime" && this.state.overtime) this.view.confirmation = { kind: "finishOvertime" };
    }
  };

  // src/presentation/assets.ts
  var CREAM = "#fff0cf";
  var MUTED = "#aab9c7";
  var PALETTE = {
    "cargo.food": { light: "#ff9a74", mid: "#e9584b", dark: "#8d3030", ink: "#6b2122" },
    "cargo.machine": { light: "#bed989", mid: "#76a74d", dark: "#3c622e", ink: "#284425" },
    "cargo.chem": { light: "#ffe594", mid: "#efb938", dark: "#a86a1b", ink: "#684717" },
    "cargo.electronic": { light: "#c1adf8", mid: "#8f70d1", dark: "#514283", ink: "#3a3166" },
    "cargo.cold": { light: "#b0e5ff", mid: "#59b5e7", dark: "#276a9d", ink: "#204e75" }
  };
  function roundedPath(ctx, x, y, w, h, r = 12) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
  function gradient(ctx, x, y, h, top, bottom) {
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, top);
    g.addColorStop(1, bottom);
    return g;
  }
  function text(ctx, value, x, y, size, color = CREAM, align = "left", weight = 700) {
    ctx.fillStyle = color;
    ctx.font = `${weight} ${size}px "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = "middle";
    ctx.fillText(value, x, y);
  }
  function outlinedText(ctx, value, x, y, size, color = CREAM, align = "left") {
    ctx.font = `900 ${size}px "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#0c131d";
    ctx.lineWidth = Math.max(8, size * 0.13);
    ctx.strokeText(value, x + 2, y + 6);
    ctx.strokeStyle = "#453026";
    ctx.lineWidth = Math.max(3, size * 0.045);
    ctx.strokeText(value, x, y);
    ctx.fillStyle = color;
    ctx.fillText(value, x, y);
  }
  function rivet(ctx, x, y, r = 4) {
    ctx.fillStyle = "#0d1620";
    ctx.beginPath();
    ctx.arc(x + 1, y + 2, r + 1, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#8b9da8";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#394953";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x - r / 2, y + r / 2);
    ctx.lineTo(x + r / 2, y - r / 2);
    ctx.stroke();
  }
  function panel(ctx, rect, color = "#26394e", rim = "#657c90", radius = 18) {
    const { x, y, w, h } = rect;
    roundedPath(ctx, x, y + 7, w, h, radius);
    ctx.fillStyle = "#090f17";
    ctx.fill();
    roundedPath(ctx, x, y, w, h, radius);
    ctx.fillStyle = gradient(ctx, x, y, h, color, "#111d2a");
    ctx.fill();
    ctx.strokeStyle = "#090f18";
    ctx.lineWidth = 7;
    ctx.stroke();
    roundedPath(ctx, x + 2, y + 2, w - 4, h - 4, radius - 2);
    ctx.strokeStyle = rim;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.strokeStyle = "rgba(232,246,255,.14)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + radius, y + 7);
    ctx.lineTo(x + w - radius, y + 7);
    ctx.stroke();
  }
  function button(ctx, rect, label, primary = true) {
    const { x, y, w, h } = rect;
    roundedPath(ctx, x, y + 7, w, h, 20);
    ctx.fillStyle = "#0a111b";
    ctx.fill();
    roundedPath(ctx, x, y, w, h, 20);
    ctx.fillStyle = gradient(ctx, x, y, h, primary ? "#ffdf65" : "#4a627c", primary ? "#eda92c" : "#263c53");
    ctx.fill();
    ctx.lineWidth = 5;
    ctx.strokeStyle = primary ? "#925619" : "#13212f";
    ctx.stroke();
    roundedPath(ctx, x + 5, y + 5, w - 10, h - 10, 16);
    ctx.lineWidth = 2;
    ctx.strokeStyle = primary ? "#fff2aa" : "#90a5ba";
    ctx.stroke();
    text(ctx, label, x + w / 2, y + h / 2, 40, primary ? "#493016" : CREAM, "center", 900);
  }
  function hazard(ctx, rect, vertical = false) {
    const { x, y, w, h } = rect;
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    ctx.fillStyle = "#d4a03f";
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = "#26313b";
    if (vertical) {
      for (let n = y - 35; n < y + h + 35; n += 54) {
        ctx.beginPath();
        ctx.moveTo(x, n);
        ctx.lineTo(x + w, n + 24);
        ctx.lineTo(x + w, n + 50);
        ctx.lineTo(x, n + 26);
        ctx.closePath();
        ctx.fill();
      }
    } else {
      for (let n = x - 35; n < x + w + 35; n += 54) {
        ctx.beginPath();
        ctx.moveTo(n, y);
        ctx.lineTo(n + 27, y);
        ctx.lineTo(n + 7, y + h);
        ctx.lineTo(n - 20, y + h);
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.fillStyle = "rgba(255,240,186,.25)";
    ctx.fillRect(x, y, w, Math.min(3, h));
    ctx.restore();
  }
  function icon(ctx, cargo, x, y, size, color = "#fff6dd", outline = "#243644") {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(size / 100, size / 100);
    ctx.fillStyle = color;
    ctx.strokeStyle = outline;
    ctx.lineWidth = 4;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    if (cargo === "cargo.machine") {
      ctx.beginPath();
      for (let i = 0; i < 40; i++) {
        const a = i / 40 * Math.PI * 2 - Math.PI / 2, r = [43, 43, 34, 34, 43][i % 5];
        const px = Math.cos(a) * r, py = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, 15, 0, Math.PI * 2);
      ctx.fillStyle = outline;
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, 21, 0, Math.PI * 2);
      ctx.stroke();
    } else if (cargo === "cargo.food") {
      ctx.beginPath();
      ctx.moveTo(0, -25);
      ctx.bezierCurveTo(-38, -52, -54, -2, -30, 29);
      ctx.bezierCurveTo(-12, 52, -8, 33, 0, 36);
      ctx.bezierCurveTo(16, 48, 25, 40, 36, 19);
      ctx.bezierCurveTo(57, -21, 27, -46, 0, -25);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(0, -26);
      ctx.quadraticCurveTo(-3, -39, 6, -47);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(8, -37);
      ctx.quadraticCurveTo(14, -60, 35, -49);
      ctx.quadraticCurveTo(24, -29, 8, -37);
      ctx.closePath();
      ctx.fillStyle = "#bada83";
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,.65)";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-22, -15);
      ctx.quadraticCurveTo(-32, -2, -25, 13);
      ctx.stroke();
    } else if (cargo === "cargo.cold") {
      ctx.strokeStyle = outline;
      ctx.lineWidth = 11;
      snowflake(ctx);
      ctx.strokeStyle = color;
      ctx.lineWidth = 6;
      snowflake(ctx);
      ctx.beginPath();
      ctx.arc(0, 0, 9, 0, Math.PI * 2);
      ctx.fill();
    } else if (cargo === "cargo.electronic") {
      ctx.strokeStyle = color;
      ctx.lineWidth = 6;
      for (let n = -20; n <= 20; n += 20) {
        ctx.beginPath();
        ctx.moveTo(n, -47);
        ctx.lineTo(n, 47);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-47, n);
        ctx.lineTo(47, n);
        ctx.stroke();
      }
      ctx.strokeStyle = outline;
      ctx.lineWidth = 4;
      roundedPath(ctx, -34, -34, 68, 68, 7);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = outline;
      roundedPath(ctx, -20, -20, 40, 40, 3);
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-12, 10);
      ctx.lineTo(-12, -10);
      ctx.lineTo(7, -10);
      ctx.lineTo(7, 3);
      ctx.lineTo(14, 3);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(0, -46);
      ctx.lineTo(47, 36);
      ctx.quadraticCurveTo(50, 43, 40, 43);
      ctx.lineTo(-40, 43);
      ctx.quadraticCurveTo(-50, 43, -46, 34);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = outline;
      roundedPath(ctx, -6, -21, 12, 36, 5);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(0, 28, 6, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
  function snowflake(ctx) {
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = i * Math.PI / 3;
      const dx = Math.cos(a), dy = Math.sin(a);
      ctx.moveTo(0, 0);
      ctx.lineTo(dx * 44, dy * 44);
      for (const sign of [-1, 1]) {
        ctx.moveTo(dx * 27, dy * 27);
        ctx.lineTo(dx * 19 - dy * sign * 12, dy * 19 + dx * sign * 12);
      }
    }
    ctx.stroke();
  }
  function cargoBox(ctx, cargo, x, y, size, alpha = 1, trait, style = "classic") {
    const p = PALETTE[cargo];
    ctx.save();
    ctx.globalAlpha *= alpha;
    ctx.translate(x, y);
    ctx.scale(size / 110, size / 110);
    if ((trait == null ? void 0 : trait.kind) === "waste") {
      roundedPath(ctx, 6, 13, 103, 97, 10);
      ctx.fillStyle = "rgba(9,14,16,.36)";
      ctx.fill();
      roundedPath(ctx, 5, 9, 98, 96, 8);
      ctx.fillStyle = "#727b83";
      ctx.fill();
      ctx.strokeStyle = "#323d47";
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.strokeStyle = "#d9dee0";
      ctx.lineWidth = 10;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(31, 25);
      ctx.lineTo(78, 66);
      ctx.moveTo(78, 25);
      ctx.lineTo(31, 66);
      ctx.stroke();
      text(ctx, "\u5E9F\u5F03\u7269", 54, 87, 20, "#f2f0df", "center", 900);
      if (style === "outline") drawCargoOutline(ctx);
      ctx.restore();
      return;
    }
    roundedPath(ctx, 6, 13, 103, 97, 10);
    ctx.fillStyle = "rgba(9,14,16,.36)";
    ctx.fill();
    ctx.strokeStyle = p.ink;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(5, 17);
    ctx.lineTo(18, 4);
    ctx.lineTo(104, 4);
    ctx.lineTo(91, 17);
    ctx.closePath();
    ctx.fillStyle = p.light;
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(92, 17);
    ctx.lineTo(105, 4);
    ctx.lineTo(105, 91);
    ctx.lineTo(92, 104);
    ctx.closePath();
    ctx.fillStyle = p.dark;
    ctx.fill();
    ctx.stroke();
    roundedPath(ctx, 4, 16, 89, 88, 6);
    ctx.fillStyle = gradient(ctx, 0, 16, 88, p.light, p.mid);
    ctx.fill();
    ctx.stroke();
    roundedPath(ctx, 11, 24, 75, 71, 3);
    ctx.strokeStyle = p.dark;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,.42)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(13, 26);
    ctx.lineTo(83, 26);
    ctx.moveTo(12, 28);
    ctx.lineTo(12, 91);
    ctx.stroke();
    ctx.strokeStyle = p.dark;
    ctx.lineWidth = 2;
    for (const [sx, sy, ex, ey] of [[14, 30, 28, 42], [82, 30, 69, 42], [14, 90, 27, 78], [82, 90, 70, 78]]) {
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(ex, ey);
      ctx.stroke();
    }
    if (cargo === "cargo.chem") hazard(ctx, { x: 16, y: 91, w: 64, h: 5 });
    if (cargo === "cargo.cold") {
      ctx.strokeStyle = "rgba(213,251,255,.7)";
      ctx.beginPath();
      ctx.moveTo(19, 11);
      ctx.lineTo(86, 11);
      ctx.stroke();
    }
    icon(ctx, cargo, 48, 60, 54, cargo === "cargo.chem" ? "#fff2ac" : "#fff4da", p.ink);
    for (const [sx, sy] of [[10, 22], [87, 22], [10, 98], [87, 98]]) rivet(ctx, sx, sy, 2.2);
    ctx.fillStyle = p.ink;
    ctx.fillRect(33, 98, 30, 3);
    ctx.fillStyle = p.light;
    ctx.fillRect(37, 98, 2, 3);
    ctx.fillRect(45, 98, 1, 3);
    ctx.fillRect(51, 98, 3, 3);
    if (trait) drawTraitBadge(ctx, trait);
    if (style === "outline") drawCargoOutline(ctx);
    ctx.restore();
  }
  function drawCargoOutline(ctx) {
    roundedPath(ctx, 3, 3, 104, 104, 8);
    ctx.strokeStyle = "#172635";
    ctx.lineWidth = 11;
    ctx.stroke();
    ctx.strokeStyle = "#fff6d6";
    ctx.lineWidth = 5;
    ctx.stroke();
  }
  function drawTraitBadge(ctx, trait) {
    var _a;
    const kind = trait.kind;
    if (kind === "pallet") {
      ctx.fillStyle = "#bd8f50";
      ctx.strokeStyle = "#483322";
      ctx.lineWidth = 3;
      roundedPath(ctx, 2, 90, 105, 18, 3);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#483322";
      for (const x of [19, 50, 81]) ctx.fillRect(x, 98, 9, 10);
    }
    const label = kind === "pallet" ? "\xD72" : kind === "rush" ? `\u4F59${(_a = trait.remaining) != null ? _a : "?"}\u6B21` : kind === "hazard" ? "\u5371\u9669" : "\u4E07\u80FD";
    const color = kind === "rush" && trait.remaining === 1 ? "#ffb392" : kind === "wildcard" ? "#ddd0ff" : "#ffe393";
    roundedPath(ctx, 14, 7, 84, 29, 5);
    ctx.fillStyle = "#1b2633";
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.stroke();
    text(ctx, label, 56, 22, kind === "rush" ? 22 : 24, color, "center", 900);
    if (kind === "hazard") {
      ctx.fillStyle = "#ffdb75";
      ctx.strokeStyle = "#4a321f";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(88, 69);
      ctx.lineTo(105, 96);
      ctx.lineTo(71, 96);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      text(ctx, "!", 88, 87, 22, "#4a321f", "center", 900);
    } else if (kind === "wildcard") {
      ctx.fillStyle = "#e8dcff";
      ctx.strokeStyle = "#53416f";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(88, 64);
      ctx.lineTo(103, 82);
      ctx.lineTo(88, 100);
      ctx.lineTo(73, 82);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      text(ctx, "*", 88, 85, 29, "#53416f", "center", 900);
    }
  }
  function forklift(ctx, x, y, size, angle, paint = "yellow") {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.scale(size / 110, size / 110);
    ctx.fillStyle = "rgba(0,0,0,.33)";
    ctx.beginPath();
    ctx.ellipse(0, 7, 57, 39, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#131920";
    for (const xx of [-32, 19]) for (const yy of [-36, 23]) {
      roundedPath(ctx, xx, yy, 23, 17, 4);
      ctx.fill();
    }
    const colors = paint === "blue" ? ["#478ed0", "#9bd8ff", "#254965", "#71bdff"] : paint === "red" ? ["#d65646", "#ffb290", "#76332e", "#ff846b"] : ["#e4ab36", "#ffe077", "#6a481e", "#ffc857"];
    ctx.fillStyle = colors[0];
    ctx.strokeStyle = colors[2];
    ctx.lineWidth = 3;
    roundedPath(ctx, -41, -25, 75, 50, 13);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = colors[1];
    roundedPath(ctx, -38, -22, 25, 44, 8);
    ctx.fill();
    ctx.fillStyle = "#243541";
    roundedPath(ctx, -12, -22, 32, 44, 4);
    ctx.fill();
    ctx.fillStyle = "#13202b";
    roundedPath(ctx, -6, -14, 17, 28, 5);
    ctx.fill();
    ctx.strokeStyle = colors[3];
    ctx.lineWidth = 5;
    ctx.strokeRect(-13, -27, 35, 54);
    ctx.strokeStyle = "#2d3438";
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(30, -31);
    ctx.lineTo(30, 31);
    ctx.stroke();
    ctx.strokeStyle = "#bac1ba";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(31, -17);
    ctx.lineTo(61, -17);
    ctx.moveTo(31, 17);
    ctx.lineTo(61, 17);
    ctx.stroke();
    ctx.fillStyle = "#fff2a5";
    ctx.fillRect(24, -24, 5, 7);
    ctx.fillRect(24, 17, 5, 7);
    ctx.fillStyle = "#ee6942";
    ctx.fillRect(-40, -17, 4, 7);
    ctx.fillRect(-40, 10, 4, 7);
    ctx.restore();
  }
  function arrow(ctx, x, y, size, angle, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(size / 2, 0);
    ctx.lineTo(-size / 3, -size / 3);
    ctx.lineTo(-size / 6, 0);
    ctx.lineTo(-size / 3, size / 3);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // src/presentation/renderer.ts
  var cargoName = (id2) => {
    var _a, _b;
    return (_b = (_a = CARGO.find((c) => c.id === id2)) == null ? void 0 : _a.name) != null ? _b : "\u8D27\u7269";
  };
  var number = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  var traitName = { pallet: "\u6258\u76D8", rush: "\u52A0\u6025", hazard: "\u5371\u9669", wildcard: "\u4E07\u80FD" };
  var pieceTrait = (piece) => piece.trait ? { kind: piece.trait, remaining: piece.rushTurns } : void 0;
  function render(ctx, state, view) {
    var _a, _b, _c, _d;
    ctx.save();
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
    ctx.clearRect(0, 0, L.width, L.height);
    drawWarehouse(ctx, view);
    if (view.confirmation) {
      drawConfirmation(ctx, state, view);
      ctx.restore();
      return;
    }
    if (!view.needsResume && view.screen === "menu") {
      drawMenu(ctx, state, view);
      ctx.restore();
      return;
    }
    if (!view.needsResume && view.screen === "settings") {
      drawSettings(ctx, state, view);
      ctx.restore();
      return;
    }
    drawHeader(ctx, state, view);
    const board = (_b = (_a = view.animation) == null ? void 0 : _a.board) != null ? _b : state.board;
    const cellTraits = view.animation ? view.animation.cellTraits : state.cellTraits;
    drawOrders(ctx, { ...state, board, cellTraits }, (_c = view.animation) == null ? void 0 : _c.shipment);
    drawBoard(ctx, state, view, board, cellTraits);
    drawTrays(ctx, state, view);
    drawFooter(ctx, state, view);
    if (view.debug) drawDebug(ctx, state, view);
    if (view.needsResume) drawPause(ctx, true, state.rulesetVersion, view.recoveryError, state.mode === "daily" ? state.challengeDay : void 0);
    else if (view.paused) drawActivePause(ctx, state, view);
    else if (state.phase === "upgrade" && !view.animation) drawUpgrades(ctx, state);
    else if (state.phase === "result" && !view.animation && ((_d = view.noticeFx) == null ? void 0 : _d.kind) !== "fail") drawResult(ctx, state, view);
    if (!view.paused && !view.needsResume && view.noticeFx) drawNotice(ctx, view);
    ctx.restore();
  }
  function drawWarehouse(ctx, view) {
    var _a;
    const night = ((_a = view.profile) == null ? void 0 : _a.cosmetics.theme) === "night";
    ctx.fillStyle = gradient(ctx, 0, 0, 1920, night ? "#111c35" : "#243345", night ? "#080d1b" : "#111b25");
    ctx.fillRect(0, 0, 1080, 1920);
    ctx.save();
    ctx.globalAlpha = 0.68;
    for (const sx of [-56, 963]) {
      for (let row = 0; row < 8; row++) {
        const y = 62 + row * 230;
        ctx.fillStyle = "#101b27";
        ctx.fillRect(sx, y, 185, 185);
        const cargo = ["cargo.machine", "cargo.chem", "cargo.cold", "cargo.food"][row % 4];
        cargoBox(ctx, cargo, sx + 12, y + 38, 74, 0.75);
        cargoBox(ctx, "cargo.chem", sx + 80, y + 63, 64, 0.52);
        ctx.fillStyle = "#3f4f5a";
        ctx.fillRect(sx - 1, y + 180, 184, 14);
        ctx.fillStyle = "#a77233";
        ctx.fillRect(sx - 1, y + 180, 184, 5);
        for (const xx of [sx + 4, sx + 157]) {
          ctx.fillStyle = "#273a4d";
          ctx.fillRect(xx, y, 16, 217);
          ctx.fillStyle = "#647184";
          ctx.fillRect(xx, y, 3, 217);
          for (let k = 0; k < 6; k++) {
            ctx.fillStyle = "#111d28";
            ctx.fillRect(xx + 7, y + k * 33 + 16, 4, 7);
          }
        }
      }
    }
    ctx.restore();
    for (const y of [18, 234, 310, 1470, 1824]) {
      ctx.fillStyle = "rgba(8,17,25,.7)";
      ctx.fillRect(0, y, 1080, 10);
      ctx.fillStyle = "rgba(138,153,160,.18)";
      ctx.fillRect(0, y + 11, 1080, 3);
    }
    ctx.fillStyle = "rgba(221,158,71,.07)";
    ctx.beginPath();
    ctx.moveTo(440, 0);
    ctx.lineTo(180, 520);
    ctx.lineTo(900, 520);
    ctx.lineTo(640, 0);
    ctx.fill();
  }
  function drawHeader(ctx, state, view) {
    var _a;
    text(ctx, "WAREHOUSE  /  LAST SLOT", 58, 35, 16, "#b6aa90", "left", 600);
    outlinedText(ctx, "\u7206\u4ED3", 49, 112, 115);
    outlinedText(ctx, "\u6700\u540E\u4E00\u683C", 63, 206, 57);
    hazard(ctx, { x: 55, y: 249, w: 425, h: 15 });
    forklift(ctx, 427, 177, 88, -0.12, (_a = view.profile) == null ? void 0 : _a.cosmetics.forklift);
    panel(ctx, { x: 548, y: 54, w: 363, h: 151 });
    text(ctx, "\u5F53\u524D\u5206\u6570", 577, 89, 25, MUTED);
    text(ctx, number(state.score), 878, 151, 56, "#ffe087", "right", 900);
    panel(ctx, L.pause, "#40536b");
    ctx.fillStyle = CREAM;
    roundedPath(ctx, 966, 80, 12, 47, 4);
    ctx.fill();
    roundedPath(ctx, 989, 80, 12, 47, 4);
    ctx.fill();
    text(ctx, "\u8FDE\u9501", L.chain.x, L.chain.y + 21, 20, MUTED);
    text(ctx, `\xD7${state.lastChain}`, L.chain.x + L.chain.w, L.chain.y + 21, 28, "#f7cc67", "right");
    panel(ctx, { x: 548, y: 226, w: 486, h: 70 }, "#25394c", "#53687a", 13);
    text(ctx, state.overtime ? "\u52A0\u73ED\u6311\u6218" : `\u7B2C ${state.shift} \u73ED`, 573, 261, 28, "#e4f1f1");
    const progress = Math.min(6, state.completedOrders - (state.shift - 1) * 6);
    for (let i = 0; i < 5; i++) {
      const x = 735 + i * 57;
      if (i < 4) {
        ctx.fillStyle = i < state.shift - 1 ? "#d3aa4f" : "#465563";
        ctx.fillRect(x, 257, 55, 5);
      }
      ctx.fillStyle = i < state.shift ? "#ffc958" : "#243240";
      ctx.strokeStyle = "#7f90a1";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, 260, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      text(ctx, String(i + 1), x, 260, 15, i < state.shift ? "#48321d" : "#8d9ba7", "center");
    }
    text(ctx, "\u672C\u73ED\u8BA2\u5355", 57, 291, 22, MUTED);
    for (let i = 0; i < 6; i++) {
      roundedPath(ctx, 180 + i * 43, 281, 35, 16, 4);
      ctx.fillStyle = i < progress ? "#ffc74d" : "#111c27";
      ctx.fill();
    }
    text(ctx, `${Math.max(0, progress)} / 6`, 474, 289, 23, CREAM, "right");
  }
  function drawOrders(ctx, state, shipment) {
    text(ctx, "\u51FA\u5E93\u8BA2\u5355", 56, 330, 26, CREAM);
    text(ctx, "\u6570\u91CF\u8FBE\u6807 \xB7 \u901A\u8DEF\u7545\u901A", 1027, 330, 22, MUTED, "right", 500);
    const w = (972 - (state.orders.length - 1) * 16) / Math.max(1, state.orders.length);
    state.orders.forEach((order, i) => {
      var _a, _b, _c;
      const x = 54 + i * (w + 16), y = 357;
      const status = orderStatus2(state, order);
      const shipping = (shipment == null ? void 0 : shipment.dockId) === order.dockId ? shipment : void 0;
      const cargo = (_a = shipping == null ? void 0 : shipping.cargo) != null ? _a : order.cargo;
      const p = PALETTE[cargo], ready = !!shipping || status.status === "ready";
      const statusColor = ready ? "#abd982" : status.status === "blocked" ? "#ff976d" : "#aac4d6";
      panel(ctx, { x, y, w, h: 135 }, ready ? "#2a4c3c" : "#293d51", ready ? "#8bb875" : "#697f90", 13);
      ctx.fillStyle = p.mid;
      roundedPath(ctx, x + 13, y + 14, 46, 46, 8);
      ctx.fill();
      icon(ctx, cargo, x + 36, y + 37, 31, "#fff5df", p.ink);
      text(ctx, (_c = (_b = DOCKS.find((d) => d.id === order.dockId)) == null ? void 0 : _b.name) != null ? _c : "\u51FA\u8D27\u53E3", x + 73, y + 25, 20, MUTED);
      text(ctx, cargoName(cargo), x + 73, y + 55, 29, CREAM);
      const units = shipping == null ? void 0 : shipping.units;
      const amount = shipping ? units === void 0 ? `${shipping.cells.length}\u683C` : `${units}\u4EF6\xB7${shipping.cells.length}\u683C` : `${status.count}/${order.amount}`;
      text(ctx, amount, x + w - 16, y + (units === void 0 ? 38 : 25), units === void 0 ? state.orders.length > 3 ? 27 : 37 : state.orders.length > 3 ? 18 : 24, "#fff0c7", "right", 900);
      ctx.fillStyle = "#10212c";
      roundedPath(ctx, x + 15, y + 78, w - 30, 8, 4);
      ctx.fill();
      roundedPath(ctx, x + 15, y + 78, Math.max(1, (w - 30) * Math.min(1, shipping ? 1 : status.count / order.amount)), 8, 4);
      ctx.fillStyle = p.mid;
      ctx.fill();
      ctx.fillStyle = statusColor;
      ctx.beginPath();
      ctx.arc(x + 22, y + 108, 5, 0, Math.PI * 2);
      ctx.fill();
      const reason = "reason" in status ? status.reason : void 0;
      const blocked = reason === "entry-blocked" ? "\u5165\u53E3\u88AB\u5835 \xB7 \u8BF7\u7559\u7A7A" : reason === "route-blocked" ? "\u6570\u91CF\u5DF2\u591F \xB7 \u65E0\u7A7A\u8DEF" : "\u6570\u91CF\u5DF2\u591F \xB7 \u901A\u8DEF\u88AB\u5835";
      const label = shipping ? `\u51FA\u5E93\u4E2D \xB7 +${shipping.score}` : ready ? "\u901A\u8DEF\u7545\u901A \xB7 \u53EF\u51FA\u5E93" : status.status === "blocked" ? blocked : `\u518D\u8FDE ${Math.max(0, order.amount - status.count)} ${state.rulesetVersion >= 2 ? "\u4EF6" : "\u683C"}`;
      text(ctx, label, x + 35, y + 108, state.orders.length > 3 ? 17 : 21, statusColor, "left", 600);
    });
  }
  function drawBoard(ctx, state, view, board, cellTraits) {
    var _a, _b, _c, _d;
    const { x, y, size, cell } = L.board;
    if (!view.animation) text(ctx, tutorialStep(state) === 2 ? "\u6570\u91CF\u591F\uFF0C\u8DEF\u5374\u5835\u4F4F\u4E86\uFF1A\u5357\u95E8\u6E05\u5899 \u2192 \u5317\u95E8\u51FA\u8D27" : "\u540C\u7C7B\u76F8\u90BB\u6210\u7EC4\uFF0C\u7ED9\u53C9\u8F66\u7559\u6761\u8DEF", 540, L.boardHint.y + L.boardHint.h / 2, 22, "#d9d0b7", "center", 600);
    panel(ctx, { x: x - 26, y: y - 24, w: size + 52, h: size + 54 }, "#56616a", "#829098", 12);
    hazard(ctx, { x: x - 13, y: y - 13, w: size + 26, h: 14 });
    hazard(ctx, { x: x - 13, y: y + size - 1, w: size + 26, h: 14 });
    hazard(ctx, { x: x - 13, y, w: 14, h: size }, true);
    hazard(ctx, { x: x + size - 1, y, w: 14, h: size }, true);
    ctx.fillStyle = "#453e34";
    ctx.fillRect(x, y, size, size);
    for (let row = 0; row < 7; row++) for (let col = 0; col < 7; col++) {
      const px = x + col * cell, py = y + row * cell, tone = (row * 3 + col * 5) % 6;
      const night = ((_a = view.profile) == null ? void 0 : _a.cosmetics.theme) === "night";
      const floor = (night ? ["#536071", "#5b6776", "#4d5b6c", "#606c79", "#526272", "#586676"] : ["#958d7b", "#a19884", "#928976", "#a69c86", "#9b927d", "#a09680"])[tone];
      const bottom = (night ? ["#3c485b", "#445264", "#39465a", "#485769", "#3e4d5e", "#425064"] : ["#817969", "#8c826f", "#807767", "#908571", "#867e6b", "#8b806c"])[tone];
      ctx.fillStyle = gradient(ctx, px, py, cell, floor, bottom);
      ctx.fillRect(px + 2, py + 2, cell - 4, cell - 4);
      ctx.fillStyle = "rgba(248,232,196,.21)";
      ctx.fillRect(px + 3, py + 2, cell - 6, 2);
      ctx.fillStyle = "rgba(35,33,29,.15)";
      ctx.fillRect(px + cell - 4, py + 4, 2, cell - 7);
      ctx.fillRect(px + 3, py + cell - 4, cell - 6, 2);
      if ((row + col * 2) % 4 === 0) {
        ctx.strokeStyle = "rgba(49,43,36,.12)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(px + 17, py + 83);
        ctx.lineTo(px + 37, py + 72);
        ctx.lineTo(px + 49, py + 75);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(255,242,213,.13)";
      ctx.fillRect(px + 27 + tone * 5, py + 32 + tone * 3, 2, 2);
    }
    ctx.fillStyle = gradient(ctx, x, y, 24, "rgba(32,30,26,.35)", "rgba(32,30,26,0)");
    ctx.fillRect(x, y, size, 24);
    ctx.fillStyle = gradient(ctx, x, y + size - 18, 18, "rgba(32,30,26,0)", "rgba(32,30,26,.25)");
    ctx.fillRect(x, y + size - 18, size, 18);
    drawTutorialTarget(ctx, state, view);
    for (const r of [0, 1]) for (const c of [0, 1]) rivet(ctx, x - 21 + c * (size + 42), y - 19 + r * (size + 40), 5);
    state.orders.forEach((order) => {
      const dock2 = DOCKS.find((d) => d.id === order.dockId);
      if (dock2) drawGate(ctx, dock2, order.cargo);
    });
    if (state.upgrades.includes("upgrade.side_gate")) drawSideGate(ctx);
    if ((_b = view.preview) == null ? void 0 : _b.valid) view.preview.shipments.forEach((s) => drawRoute(ctx, s.path, false));
    const shipment = (_c = view.animation) == null ? void 0 : _c.shipment, reduced = !!((_d = view.profile) == null ? void 0 : _d.settings.reducedMotion);
    const frame2 = view.animation ? shipmentFrame(view.animation.progress, reduced) : null;
    if (shipment && frame2) drawRoute(ctx, shipment.path, true, reduced ? 1 : 0.25 + frame2.route * 0.75);
    const dock = shipment ? DOCKS.find((d) => d.id === shipment.dockId) : void 0;
    const collecting = shipment && (frame2 == null ? void 0 : frame2.stage) === "collect" && !reduced;
    const drawCargo = (cargo, index) => {
      var _a2, _b2, _c2, _d2;
      const source2 = { x: x + index % 7 * cell + 60, y: y + Math.floor(index / 7) * cell + 59 };
      const isShipment = shipment == null ? void 0 : shipment.cells.includes(index), extra = (_a2 = shipment == null ? void 0 : shipment.extraClearedCells) == null ? void 0 : _a2.includes(index);
      const pose = collecting && isShipment && dock ? collectPose(source2, dockPosition(dock), frame2.collect, false) : { ...source2, scale: 1 };
      const placed = ((_b2 = view.placementFx) == null ? void 0 : _b2.cells.includes(index)) ? placementPose(view.placementFx.progress, reduced) : { x: 1, y: 1 };
      const failure = ((_c2 = view.noticeFx) == null ? void 0 : _c2.kind) === "fail" ? placementPose(view.noticeFx.progress, reduced) : { x: 1, y: 1 };
      const cleanupScale = collecting && extra ? 1 - frame2.collect * 0.9 : 1;
      ctx.save();
      ctx.translate(pose.x, pose.y);
      ctx.scale(pose.scale * cleanupScale * placed.x * failure.x, pose.scale * cleanupScale * placed.y * failure.y);
      cargoBox(ctx, cargo, -55, -55, 110, collecting && extra ? 1 - frame2.collect : 1, cellTraits == null ? void 0 : cellTraits[index], (_d2 = view.profile) == null ? void 0 : _d2.cosmetics.cargo);
      ctx.restore();
    };
    board.forEach((cargo, index) => {
      if (cargo && !(collecting && (shipment == null ? void 0 : shipment.cells.includes(index)))) drawCargo(cargo, index);
    });
    if (collecting) shipment == null ? void 0 : shipment.cells.forEach((index) => {
      const cargo = board[index];
      if (cargo) drawCargo(cargo, index);
    });
    drawChosenGroups(ctx, view);
    drawExtraClears(ctx, view);
    drawPlacementFeedback(ctx, view);
    drawPlacement(ctx, state, view);
    if (view.animation) drawShipment(ctx, view.animation.shipment, view.animation.progress, view);
  }
  function tutorialStep(state) {
    var _a, _b;
    if (state.rulesetVersion === 3 && state.mode === "tutorial" && state.phase === "input") return state.tutorialStep === 0 || state.tutorialStep === 1 || state.tutorialStep === 2 ? state.tutorialStep : null;
    if (state.mode !== "tutorial" || state.phase !== "input" || state.completedOrders > 0) return null;
    if (state.commandIndex === 0) return 0;
    if (state.commandIndex === 1 && state.board[8] === "cargo.food" && state.board[9] === "cargo.food" && state.board[10] === null && ((_a = state.candidates[1]) == null ? void 0 : _a.cargo) === "cargo.food" && ((_b = state.candidates[1]) == null ? void 0 : _b.shapeId) === "shape.single") return 1;
    return null;
  }
  function drawTutorialTarget(ctx, state, view) {
    const step = tutorialStep(state);
    if (step === null || view.animation || view.dragPoint) return;
    const x = L.board.x + (step === 0 ? 1 : 3) * L.board.cell + 10, y = L.board.y + (step === 2 ? 4 : 1) * L.board.cell + 10;
    const w = (step === 0 ? 2 : 1) * L.board.cell - 20;
    ctx.save();
    roundedPath(ctx, x, y, w, 100, 10);
    ctx.fillStyle = "rgba(255,225,126,.10)";
    ctx.fill();
    ctx.strokeStyle = "#ffe58d";
    ctx.lineWidth = 4;
    ctx.setLineDash([11, 9]);
    ctx.stroke();
    ctx.setLineDash([]);
    text(ctx, step === 0 ? "\u98DF\u54C1 \xD72" : step === 1 ? "\u98DF\u54C1 \xD71" : "\u673A\u68B0 \xD71", x + w / 2, y + 50, 24, "#fff1bd", "center");
    ctx.restore();
  }
  function drawGate(ctx, dock, cargo) {
    const side = dock.side;
    const angle = side === "north" ? Math.PI / 2 : side === "south" ? -Math.PI / 2 : side === "west" ? 0 : Math.PI;
    const { x: gx, y: gy } = dockPosition(dock);
    ctx.save();
    ctx.translate(gx, gy);
    ctx.rotate(angle);
    panel(ctx, { x: -25, y: -40, w: 43, h: 80 }, "#172735", "#ddbc65", 6);
    ctx.fillStyle = PALETTE[cargo].mid;
    roundedPath(ctx, -20, -31, 31, 62, 4);
    ctx.fill();
    arrow(ctx, -1, 0, 28, 0, "#fff7cf");
    ctx.restore();
  }
  function drawSideGate(ctx) {
    const p = cellCenter({ x: 0, y: 6 });
    panel(ctx, { x: 68, y: p.y - 35, w: 48, h: 70 }, "#30493b", "#c4e298", 6);
    arrow(ctx, 94, p.y, 31, 0, "#e8ffbf");
    text(ctx, "\u4FA7\u95E8", 89, p.y - 55, 21, "#e8ffbf", "center");
    text(ctx, "\u5168\u8BA2\u5355", 80, p.y + 57, 16, "#d4e6bb", "center", 600);
  }
  function drawRoute(ctx, route2, active, opacity = 1) {
    if (!route2.length) return;
    ctx.save();
    ctx.globalAlpha *= opacity;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const path = () => {
      ctx.beginPath();
      route2.forEach((p, i) => {
        const c = cellCenter(p);
        if (i === 0) ctx.moveTo(c.x, c.y);
        else ctx.lineTo(c.x, c.y);
      });
    };
    if (route2.length > 1) {
      path();
      ctx.strokeStyle = active ? "rgba(255,210,72,.28)" : "rgba(94,237,200,.20)";
      ctx.lineWidth = active ? 32 : 22;
      ctx.stroke();
      path();
      ctx.setLineDash(active ? [] : [13, 12]);
      ctx.strokeStyle = active ? "#fff1a2" : "#b4fff0";
      ctx.lineWidth = active ? 10 : 6;
      ctx.stroke();
      ctx.setLineDash([]);
    }
    for (let i = 0; i < route2.length; i++) {
      const c = cellCenter(route2[i]);
      if (i < route2.length - 1) arrow(ctx, c.x, c.y, 25, Math.atan2(route2[i + 1].y - route2[i].y, route2[i + 1].x - route2[i].x), active ? "#fff5b6" : "#bafcec");
      else {
        ctx.strokeStyle = active ? "#fff4b0" : "#b4fff0";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(c.x, c.y, 17, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
  function drawChosenGroups(ctx, view) {
    var _a, _b, _c, _d;
    const reducedShipment = view.animation && ((_a = view.profile) == null ? void 0 : _a.settings.reducedMotion) ? view.animation.shipment : null;
    if (!reducedShipment && (!((_b = view.preview) == null ? void 0 : _b.valid) || view.animation)) return;
    const cells = new Set((_d = reducedShipment == null ? void 0 : reducedShipment.cells) != null ? _d : ((_c = view.preview) == null ? void 0 : _c.valid) ? view.preview.shipments.flatMap((shipment) => shipment.cells) : []);
    ctx.save();
    ctx.strokeStyle = "#cbffde";
    ctx.lineWidth = 4;
    ctx.fillStyle = "rgba(179,255,207,.15)";
    for (const index of cells) {
      const x = L.board.x + index % 7 * L.board.cell + 4, y = L.board.y + Math.floor(index / 7) * L.board.cell + 4;
      ctx.fillRect(x, y, 112, 112);
      ctx.strokeRect(x, y, 112, 112);
    }
    ctx.restore();
  }
  function drawExtraClears(ctx, view) {
    var _a;
    const shipments = view.animation ? [view.animation.shipment] : ((_a = view.preview) == null ? void 0 : _a.valid) ? view.preview.shipments : [];
    const cells = new Set(shipments.flatMap((shipping) => {
      var _a2;
      return (_a2 = shipping.extraClearedCells) != null ? _a2 : [];
    }));
    ctx.save();
    ctx.strokeStyle = "#ffc893";
    ctx.lineWidth = 4;
    ctx.setLineDash([9, 7]);
    for (const index of cells) {
      const x = L.board.x + index % 7 * L.board.cell + 9, y = L.board.y + Math.floor(index / 7) * L.board.cell + 9;
      ctx.strokeRect(x, y, 102, 102);
    }
    ctx.setLineDash([]);
    ctx.restore();
  }
  function drawPlacement(ctx, state, view) {
    const piece = state.candidates.find((p) => p.id === view.selectedPieceId);
    if (!piece) return;
    if (view.hoverOrigin) {
      const shape2 = SHAPES.find((s) => s.id === piece.shapeId);
      shape2 == null ? void 0 : shape2.cells.forEach((p) => {
        var _a, _b;
        const cx = p.x + view.hoverOrigin.x, cy = p.y + view.hoverOrigin.y;
        if (cx < 0 || cy < 0 || cx > 6 || cy > 6) return;
        const x = L.board.x + cx * L.board.cell + 4, y = L.board.y + cy * L.board.cell + 4;
        const valid = (_a = view.preview) == null ? void 0 : _a.valid;
        ctx.fillStyle = valid ? "rgba(223,239,144,.32)" : "rgba(231,69,48,.30)";
        ctx.fillRect(x, y, 112, 112);
        ctx.strokeStyle = valid ? "#f3f6b1" : "#ff7959";
        ctx.lineWidth = 5;
        ctx.strokeRect(x + 2, y + 2, 108, 108);
        if (piece.trait && !view.dragPoint) cargoBox(ctx, piece.cargo, x + 1, y, 110, 0.7, pieceTrait(piece), (_b = view.profile) == null ? void 0 : _b.cosmetics.cargo);
      });
    }
    if (view.dragPoint) {
      const shape2 = SHAPES.find((s) => s.id === piece.shapeId);
      if (!shape2) return;
      ctx.save();
      ctx.globalAlpha = 0.8;
      shape2.cells.forEach((p) => {
        var _a;
        return cargoBox(ctx, piece.cargo, view.dragPoint.x + p.x * 120 - 55, view.dragPoint.y + p.y * 120 - 55, 110, 1, pieceTrait(piece), (_a = view.profile) == null ? void 0 : _a.cosmetics.cargo);
      });
      ctx.restore();
    }
  }
  function drawPlacementFeedback(ctx, view) {
    var _a;
    const effect = view.placementFx;
    if (!effect) return;
    const reduced = !!((_a = view.profile) == null ? void 0 : _a.settings.reducedMotion);
    ctx.save();
    ctx.globalAlpha = reduced ? 1 : Math.max(0, 1 - effect.progress);
    ctx.strokeStyle = "#fff2ae";
    ctx.lineWidth = 4;
    for (const index of effect.cells) {
      if (index < 0 || index >= 49) continue;
      ctx.strokeRect(L.board.x + index % 7 * L.board.cell + 4, L.board.y + Math.floor(index / 7) * L.board.cell + 4, 112, 112);
    }
    ctx.restore();
  }
  function drawShipment(ctx, shipment, progress, view) {
    var _a, _b;
    const reduced = !!((_a = view.profile) == null ? void 0 : _a.settings.reducedMotion), frame2 = shipmentFrame(progress, reduced);
    const feedback = chainFeedback(shipment.chain), pose = routePose(shipment.path, frame2.move);
    const dock = DOCKS.find((d) => d.id === shipment.dockId), target = dock ? dockPosition(dock) : null;
    if (pose) {
      if (frame2.stage === "move") drawParticles(ctx, feedbackParticles(pose, shipment.chain, frame2.move, "move", reduced), "#c9baa0");
      forklift(ctx, pose.x, pose.y, 99, pose.angle, (_b = view.profile) == null ? void 0 : _b.cosmetics.forklift);
    }
    if (target && frame2.stage === "collect") {
      if (!reduced) {
        const pulse = Math.sin(Math.PI * frame2.collect);
        ctx.save();
        ctx.globalAlpha = feedback.flash * pulse;
        ctx.strokeStyle = "#ffe8a0";
        ctx.lineWidth = 12;
        ctx.beginPath();
        ctx.arc(target.x, target.y, 39, 0, Math.PI * 2);
        ctx.stroke();
        if (feedback.pulse) {
          ctx.globalAlpha = 0.18 * pulse;
          ctx.lineWidth = 5;
          ctx.strokeRect(L.board.x - 22, L.board.y - 21, L.board.size + 44, L.board.size + 42);
        }
        ctx.restore();
        drawParticles(ctx, feedbackParticles(target, shipment.chain, frame2.collect, "collect"), "#ffe29b");
      }
      const side = dock.side;
      const x = side === "west" ? 55 : side === "east" ? 1025 : side === "south" && shipment.chain > 1 ? 816 : target.x;
      const y = side === "north" ? 522 : side === "south" ? shipment.chain > 1 ? 1441 : 1426 : target.y - 58;
      const maxWidth = side === "west" || side === "east" ? 94 : 244;
      const label = `+${number(shipment.score)}`;
      ctx.font = `900 ${feedback.fontSize}px "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", sans-serif`;
      const size = Math.min(feedback.fontSize, feedback.fontSize * maxWidth / Math.max(1, ctx.measureText(label).width));
      outlinedText(ctx, label, x, y, size, "#ffe48a", "center");
    }
    if (shipment.chain > 1) {
      panel(ctx, { x: 370, y: 1432, w: 340, h: 57 }, "#5a3f26", "#b98d40", 12);
      text(ctx, `${shipment.chain} \u8FDE\u9501\u51FA\u5E93\uFF01`, 540, 1460, Math.min(36, feedback.fontSize - 8), "#ffdf75", "center", 900);
    }
  }
  function drawParticles(ctx, particles, color) {
    if (!particles.length) return;
    ctx.save();
    ctx.fillStyle = color;
    for (const particle of particles) {
      ctx.globalAlpha = particle.alpha;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
  function drawNotice(ctx, view) {
    const notice = view.noticeFx;
    if (!notice) return;
    const failure = notice.kind === "fail";
    panel(ctx, { x: 252, y: 1430, w: 576, h: 67 }, failure ? "#493b31" : "#304b40", failure ? "#ccab88" : "#b5ce91", 12);
    text(ctx, notice.label, 540, 1463, 26, failure ? "#f5d8ba" : "#e3efca", "center", 700);
  }
  function drawTrays(ctx, state, view) {
    var _a;
    const shipments = view.animation ? [view.animation.shipment] : ((_a = view.preview) == null ? void 0 : _a.valid) ? view.preview.shipments : [];
    const extra = new Set(shipments.flatMap((shipping) => {
      var _a2;
      return (_a2 = shipping.extraClearedCells) != null ? _a2 : [];
    })).size;
    const detail = [shipments.some((shipping) => shipping.usedPalletPass) ? "\u7A7F\u6258\u76D81\u6B21 \xB7 \u6258\u76D8\u4FDD\u7559" : "", extra ? `\u989D\u5916\u6E05\u7406${extra}\u683C \xB7 \u4E0D\u8BA1\u5206` : ""].filter(Boolean).join(" / ");
    if (!view.noticeFx && (!view.animation || view.animation.shipment.chain < 2)) {
      const step = tutorialStep(state);
      const hint = state.rulesetVersion === 3 && step !== null ? ["\u7B2C1\u6B65\uFF1A\u628A\u98DF\u54C1\u6A2A2\u62D6\u8FDB\u865A\u7EBF\u6846", "\u7B2C2\u6B65\uFF1A\u628A\u98DF\u54C1\u63A5\u5728\u53F3\u4FA7\uFF0C\u51D1\u62103\u4EF6\u51FA\u8D27", "\u7B2C3\u6B65\uFF1A\u8865\u4E0A\u673A\u68B0\uFF0C\u5148\u6E05\u8DEF\uFF0C\u518D\u8FDE\u9501\u51FA\u8D27"][step] : step === 0 ? "\u7B2C1\u6B65\uFF1A\u628A\u5DE6\u4FA7\u98DF\u54C1\u62D6\u8FDB\u865A\u7EBF\u6846" : step === 1 ? "\u7B2C2\u6B65\uFF1A\u628A\u4E2D\u95F4\u98DF\u54C1\u63A5\u5728\u53F3\u4FA7\uFF0C\u51D1\u62103\u683C" : detail || view.message || "\u62D6\u5165\u8D27\u4EF6\uFF0C\u6216\u70B9\u9009\u540E\u70B9\u51FB\u843D\u70B9";
      text(ctx, hint, 540, 1467, detail ? 24 : 27, "#efe3c9", "center", 600);
    }
    text(ctx, "\u5F85\u5165\u5E93", 58, 1502, 22, "#b8c3cd");
    text(ctx, detail && view.animation && view.animation.shipment.chain > 1 ? detail : "\u56FA\u5B9A\u671D\u5411 \xB7 \u4E0D\u53EF\u65CB\u8F6C", 1027, 1502, detail ? 18 : 20, "#b2c1ca", "right", 500);
    const trays = getTrayRects(state.candidates.length);
    state.candidates.forEach((piece, index) => {
      var _a2, _b, _c, _d, _e;
      const r = trays[index];
      if (!r) return;
      const selected = piece.id === view.selectedPieceId || tutorialStep(state) !== null && (state.rulesetVersion === 3 ? index === 0 : tutorialStep(state) === index) && !view.selectedPieceId;
      panel(ctx, r, selected ? "#485045" : "#293c50", selected ? "#f4cf69" : "#718396");
      if (selected) {
        roundedPath(ctx, r.x + 7, r.y + 7, r.w - 14, r.h - 14, 13);
        ctx.strokeStyle = "#eec860";
        ctx.lineWidth = 3;
        ctx.stroke();
      }
      text(ctx, `0${index + 1}`, r.x + 20, r.y + 26, 17, "#718b9c");
      const invalid = ((_a2 = view.invalidFx) == null ? void 0 : _a2.pieceId) === piece.id;
      const reduced = !!((_b = view.profile) == null ? void 0 : _b.settings.reducedMotion);
      const progress = invalid ? view.invalidFx.progress : ((_c = view.noticeFx) == null ? void 0 : _c.kind) === "fail" ? view.noticeFx.progress : null;
      if (progress !== null && !reduced) {
        const squash = placementPose(progress, false), center = { x: r.x + r.w / 2, y: r.y + 126 };
        ctx.save();
        ctx.translate(center.x, center.y + (invalid ? reboundOffset(progress, false) : 0));
        ctx.scale(squash.x, squash.y);
        ctx.translate(-center.x, -center.y);
        drawPieceInTray(ctx, piece, r, selected, (_d = view.profile) == null ? void 0 : _d.cosmetics.cargo);
        ctx.restore();
      } else drawPieceInTray(ctx, piece, r, selected, (_e = view.profile) == null ? void 0 : _e.cosmetics.cargo);
      if (invalid) {
        ctx.save();
        ctx.strokeStyle = "#ffb28b";
        ctx.lineWidth = 3;
        roundedPath(ctx, r.x + 7, r.y + 7, r.w - 14, r.h - 14, 13);
        ctx.stroke();
        ctx.restore();
      }
      const label = piece.trait ? `${traitName[piece.trait]} \xB7 ${cargoName(piece.cargo)}` : cargoName(piece.cargo);
      text(ctx, label, r.x + r.w / 2, r.y + r.h - 27, piece.trait && r.w < 300 ? 24 : 27, selected ? "#ffe397" : "#e7e9df", "center");
    });
  }
  function drawPieceInTray(ctx, piece, r, selected, cargoStyle) {
    const shape2 = SHAPES.find((s) => s.id === piece.shapeId);
    if (!(shape2 == null ? void 0 : shape2.cells.length)) return;
    const width = Math.max(...shape2.cells.map((p) => p.x)) + 1, height = Math.max(...shape2.cells.map((p) => p.y)) + 1;
    const cell = Math.min(piece.trait ? 104 : 74, Math.min(230, r.w - 54) / width, 166 / height);
    const x = r.x + (r.w - width * cell) / 2, y = r.y + 31 + (166 - height * cell) / 2;
    if (selected) {
      ctx.fillStyle = "rgba(241,190,79,.09)";
      ctx.beginPath();
      ctx.ellipse(r.x + r.w / 2, r.y + 199, Math.min(105, r.w / 2 - 20), 14, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    shape2.cells.forEach((p) => cargoBox(ctx, piece.cargo, x + p.x * cell, y + p.y * cell, cell - 2, 1, pieceTrait(piece), cargoStyle));
  }
  function drawFooter(ctx, state, view) {
    var _a, _b;
    if (state.mode === "daily") text(ctx, `\u672C\u5730\u6BCF\u65E5 ${(_b = (_a = state.challengeDay) != null ? _a : view.dailyLabel) != null ? _b : "\u65E5\u671F\u5F85\u786E\u8BA4"} \xB7 \u5317\u4EAC\u65F6\u95F4`, 54, 1840, 21, "#bfbaa8", "left", 500);
    else if (state.rulesetVersion >= 2 && state.shift >= 3) text(ctx, "\u6258\u76D81\u683C\u8BA12\u4EF6 \xB7 \u52A0\u6025\u5230\u671F\u53D8\u5E9F\u7269 \xB7 \u89C4\u5219\u89C1\u6682\u505C", 54, 1840, 21, "#bfbaa8", "left", 500);
    else text(ctx, "\u51D1\u591F\u8BA2\u5355 \u2192 \u7A7A\u683C\u901A\u8DEF \u2192 \u81EA\u52A8\u51FA\u5E93", 540, 1840, 24, "#bfbaa8", "center", 500);
    text(ctx, view.saveStatus || "\u672C\u673A\u5B58\u6863", 54, 1888, 19, "#8297a6", "left", 500);
    text(ctx, `\u89C4\u5219 v${state.rulesetVersion} \xB7 \u5F00\u53D1\u7248 / ${state.mode === "daily" ? "\u672C\u5730\u6BCF\u65E5\u6311\u6218" : state.mode === "tutorial" ? "\u521D\u6B21\u5165\u5E93" : state.overtime ? "\u52A0\u73ED\u6311\u6218" : "\u6807\u51C6\u73ED\u6B21"}`, 1027, 1888, 18, "#8297a6", "right", 500);
    roundedPath(ctx, L.debug.x, L.debug.y, L.debug.w, L.debug.h, 6);
    ctx.fillStyle = "rgba(13,23,31,.86)";
    ctx.fill();
    text(ctx, "\u72B6\u6001", L.debug.x + L.debug.w / 2, L.debug.y + 23, 20, "#9cabaf", "center");
  }
  function shade(ctx) {
    ctx.fillStyle = "rgba(5,11,18,.84)";
    ctx.fillRect(0, 0, 1080, 1920);
  }
  function drawPause(ctx, recovery, rulesetVersion, error, challengeDay) {
    shade(ctx);
    panel(ctx, { x: 173, y: 582, w: 734, h: 839 }, "#30455a", "#9aabaf", 28);
    hazard(ctx, { x: 201, y: 610, w: 678, h: 19 });
    forklift(ctx, 540, 744, 140, -0.12);
    outlinedText(ctx, error ? "\u5B58\u6863\u9700\u8981\u5904\u7406" : recovery ? "\u4ED3\u5E93\u8FD8\u5728\u7B49\u4F60" : "\u4F11\u606F\u4E00\u4E0B", 540, 868, 62, CREAM, "center");
    text(ctx, error ? "\u73B0\u6709\u5B58\u6863\u65E0\u6CD5\u5B89\u5168\u7EE7\u7EED" : recovery ? challengeDay ? `\u672C\u5730\u6BCF\u65E5 ${challengeDay} \xB7 \u5DF2\u4FDD\u5B58\u7684\u6311\u6218` : "\u5DF2\u627E\u5230\u672C\u673A\u4FDD\u5B58\u7684\u8FDB\u5EA6" : "\u8D27\u7269\u4E0E\u8BA2\u5355\u90FD\u5DF2\u6682\u505C", 540, 960, 31, "#c6d1d6", "center", 500);
    text(ctx, error ? "\u91CD\u65B0\u5F00\u59CB\u524D\u4F1A\u4FDD\u7559\u635F\u574F\u5B58\u6863\u539F\u6587" : recovery ? "\u7EE7\u7EED\u4E0A\u6B21\u73ED\u6B21\uFF0C\u6216\u5F00\u59CB\u5168\u65B0\u4E00\u5C40" : "\u56DE\u6765\u65F6\uFF0C\u7EE7\u7EED\u628A\u4ED3\u5E93\u6574\u7406\u5F97\u4E95\u4E95\u6709\u6761", 540, 1013, 25, "#9bafbf", "center", 500);
    if (!error && rulesetVersion >= 2) {
      const rules = [
        "\u6258\u76D8\u53601\u683C\u8BA12\u4EF6\uFF1B\u4E07\u80FD\u53EF\u8FDE\u63A5\u5F53\u524D\u8BA2\u5355\u8D27\u7C7B",
        "\u52A0\u6025\uFF1A\u540E\u7EED\u6709\u6548\u653E\u7F6E\u5012\u6570\u5F52\u96F6\uFF0C\u53D8\u5E9F\u5F03\u7269",
        "\u5E9F\u7269\u5360\u683C\u4E0D\u51FA\u5E93\uFF1B\u5371\u9669\u54C1\u51FA\u8D27\u65F6\u6E05\u76F8\u90BB\u5E9F\u7269",
        "\u7A7F\u6258\u76D8\u4E0D\u642C\u8D70\u6258\u76D8\uFF1B\u989D\u5916\u6E05\u7406\u4E0D\u8BA1\u5206"
      ];
      rules.forEach((line, index) => text(ctx, line, 540, 1482 + index * 39, 25, "#d5ddda", "center", 500));
    }
    if (error) {
      wrap(ctx, error, 246, 1094, 588, 23, 34);
      button(ctx, L.restart, "\u4FDD\u7559\u65E7\u6863\u5E76\u91CD\u65B0\u5F00\u59CB");
    } else {
      button(ctx, L.resume, recovery ? "\u7EE7\u7EED\u4E0A\u6B21\u73ED\u6B21" : "\u7EE7\u7EED\u5DE5\u4F5C");
      button(ctx, L.restart, "\u91CD\u65B0\u5F00\u59CB", false);
    }
  }
  function wrap(ctx, value, x, y, width, fontSize = 27, lineHeight = 43) {
    let line = "", lineY = y;
    ctx.font = `500 ${fontSize}px "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", sans-serif`;
    for (const char of value) {
      if (char === "\n" || ctx.measureText(line + char).width > width) {
        text(ctx, line, x, lineY, fontSize, "#d5dce1", "left", 500);
        line = char === "\n" ? "" : char;
        lineY += lineHeight;
      } else line += char;
    }
    if (line) text(ctx, line, x, lineY, fontSize, "#d5dce1", "left", 500);
  }
  function drawUpgrades(ctx, state) {
    shade(ctx);
    text(ctx, `\u7B2C ${state.shift} \u73ED \xB7 \u5DF2\u5B8C\u6210 ${state.completedOrders} \u5355`, 540, 419, 29, "#b8c9d6", "center");
    outlinedText(ctx, "\u9009\u62E9\u4E00\u9879\u5347\u7EA7", 540, 520, 75, "#ffe5a1", "center");
    text(ctx, "\u6539\u53D8\u642C\u8FD0\u65B9\u5F0F\uFF0C\u8BA9\u4E0B\u4E00\u6B21\u51FA\u5E93\u66F4\u4ECE\u5BB9", 540, 593, 29, "#d7dedc", "center", 500);
    state.upgradeChoices.forEach((id2, index) => {
      const upgrade2 = UPGRADES_V2.find((u) => u.id === id2), r = L.upgradeRects[index];
      if (!upgrade2 || !r) return;
      const colors = ["#6dbde1", "#b091df", "#efbb5d"];
      panel(ctx, r, ["#1d4c69", "#493462", "#5a472c"][index], colors[index], 21);
      roundedPath(ctx, r.x + 9, r.y + 9, r.w - 18, r.h - 18, 15);
      ctx.strokeStyle = colors[index];
      ctx.lineWidth = 2;
      ctx.stroke();
      text(ctx, `0${index + 1}`, r.x + 23, r.y + 33, 19, colors[index]);
      text(ctx, upgrade2.title, r.x + r.w / 2, r.y + 87, 34, CREAM, "center", 900);
      ctx.fillStyle = "rgba(9,21,30,.35)";
      roundedPath(ctx, r.x + 29, r.y + 137, r.w - 58, 180, 15);
      ctx.fill();
      drawUpgradeModifier(ctx, upgrade2, r, colors[index]);
      text(ctx, upgrade2.behavior ? "\u89C4\u5219\u53D8\u5316" : "\u8BA1\u5206 / \u8865\u7ED9", r.x + r.w / 2, r.y + 341, 21, colors[index], "center", 600);
      const description = upgrade2.description.replace(/Dock/g, "\u51FA\u8D27\u53E3").replace(/Shift(\d+)/g, "\u7B2C$1\u73ED");
      wrap(ctx, description, r.x + 30, r.y + 377, r.w - 60, 24, 32);
      roundedPath(ctx, r.x + 27, r.y + r.h - 75, r.w - 54, 47, 10);
      ctx.fillStyle = colors[index];
      ctx.fill();
      text(ctx, "\u9009\u62E9\u6B64\u9879", r.x + r.w / 2, r.y + r.h - 51, 25, "#172737", "center");
    });
    text(ctx, "\u9009\u62E9\u540E\u7ACB\u5373\u751F\u6548 \xB7 \u539F\u68CB\u76D8\u7EE7\u7EED", 540, 1310, 26, "#aabcc9", "center", 500);
  }
  function drawUpgradeModifier(ctx, upgrade2, r, color) {
    var _a;
    const labels = {
      overfill: ["+", "\u8D85\u989D\u88C5\u8F7D\u52A0\u5206"],
      deep_route: ["\u8FDC", "\u957F\u8DEF\u7EBF\u52A0\u5206"],
      small_parcels: ["\u5C0F", "\u5C0F\u4EF6\u8865\u7ED9\u589E\u52A0"],
      chain: ["\xD7", "\u8FDE\u9501\u500D\u7387\u589E\u52A0"],
      contract: ["+", "\u8BA2\u5355\u57FA\u7840\u5206\u589E\u52A0"],
      variety: ["\u6362", "\u4E0D\u540C\u8D27\u7C7B\u8FDE\u8FD0"],
      side_gate: ["\u95E8+", "\u5168\u8BA2\u5355\u5171\u7528\u4FA7\u95E8"],
      pallet_pass: ["\u901A", "\u7A7F\u8FC7\u6258\u76D8\u4E0D\u642C\u8D70"],
      small_order_first: ["\u5E8F", "\u5C11\u91CF\u65E7\u5355\u4F18\u5148"],
      light_orders: ["\u2212", "\u540E\u7EED\u65B0\u5355\u51CF\u91CF"],
      stock_orders: ["\u5E93", "\u5E93\u5B58\u5F71\u54CD\u65B0\u8BA2\u5355"],
      four_choices: ["4", "\u540C\u65F6\u56DB\u4E2A\u5019\u9009"],
      pallet_supply: ["\xD72", "\u5B9A\u671F\u5355\u683C\u6258\u76D8"],
      rush_buffer: ["+2", "\u52A0\u6025\u671F\u9650\u5EF6\u957F"],
      hazard_clearance: ["\u6E05", "\u6E05\u76F8\u90BB\u5E9F\u5F03\u7269"],
      wild_supply: ["*", "\u589E\u52A0\u4E07\u80FD\u8D27\u4EF6"],
      sweep_route: ["\u626B", "\u6E05\u7406\u8DEF\u7EBF\u65C1\u5E9F\u7269"],
      extra_pickup: ["\u634E", "\u987A\u8DEF\u6E05\u666E\u901A\u8D27\u7269"]
    };
    const [mark, label] = (_a = labels[upgrade2.effect]) != null ? _a : ["+", upgrade2.title];
    const x = r.x + r.w / 2, y = r.y + 211;
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(x, y, 52, 0, Math.PI * 2);
    ctx.stroke();
    text(ctx, mark, x, y, 52, "#fff0c8", "center", 900);
    text(ctx, label, x, r.y + 284, 22, "#d6e1de", "center", 600);
  }
  function drawResult(ctx, state, view) {
    var _a, _b;
    shade(ctx);
    const won = state.result === "won", tutorial = state.mode === "tutorial", daily = state.mode === "daily";
    const retired = state.overtime && state.endReason === "retired";
    const title = tutorial ? won ? "\u6559\u5B66\u5B8C\u6210\uFF01" : "\u7206\u4ED3\u4E86\uFF01" : retired ? "\u52A0\u73ED\u7ED3\u7B97" : state.overtime ? "\u52A0\u73ED\u7ED3\u675F" : daily ? won ? "\u4ECA\u65E5\u6311\u6218\u5B8C\u6210" : "\u4ECA\u65E5\u6311\u6218\u7ED3\u7B97" : won ? "\u5B8C\u7F8E\u6536\u5DE5\uFF01" : "\u7206\u4ED3\u4E86\uFF01";
    outlinedText(ctx, title, 540, 414, 88, won || retired ? "#fff0bb" : "#ffbd86", "center");
    const subtitle = tutorial ? "\u76F8\u90BB\u6210\u7EC4\u3001\u7559\u51FA\u901A\u8DEF\uFF0C\u6E05\u5899\u8FD8\u80FD\u5E26\u6765\u8FDE\u9501" : retired ? "\u5DF2\u4E3B\u52A8\u7ED3\u675F\u52A0\u73ED\uFF0C\u672C\u8F6E\u5230\u6B64\u7ED3\u675F" : state.overtime ? "\u8FD9\u6B21\u52A0\u73ED\u5DF2\u7ED3\u675F\uFF0C\u4E0B\u6B21\u518D\u6311\u6218\u65B0\u7EAA\u5F55" : daily ? `\u672C\u5730\u6BCF\u65E5\u6311\u6218 \xB7 ${(_b = (_a = state.challengeDay) != null ? _a : view.dailyLabel) != null ? _b : "\u65E5\u671F\u5F85\u786E\u8BA4"}` : won ? "\u4E94\u4E2A\u73ED\u6B21\u5168\u90E8\u5B8C\u6210\uFF0C\u4ED3\u5E93\u4EA4\u7ED9\u4E0B\u4E00\u73ED" : `${state.candidates.length === 4 ? "\u56DB" : state.candidates.length === 1 ? "\u4E00\u4E2A" : "\u4E09"}${state.candidates.length === 1 ? "" : "\u4E2A"}\u5019\u9009\u8D27\u4EF6\u90FD\u6CA1\u6709\u5408\u6CD5\u843D\u70B9`;
    text(ctx, subtitle, 540, 507, 28, "#d9d9cf", "center", 500);
    panel(ctx, { x: 174, y: 581, w: 732, h: 496 }, "#415263", "#b2a888", 26);
    roundedPath(ctx, 203, 610, 674, 269, 16);
    ctx.fillStyle = gradient(ctx, 203, 610, 269, "#f8e9c7", "#decaa4");
    ctx.fill();
    text(ctx, tutorial ? "\u6559\u5B66\u5F97\u5206" : "\u672C\u5C40\u5F97\u5206", 540, 657, 30, "#5c4936", "center");
    outlinedText(ctx, number(state.score), 540, 742, 94, "#ffce5b", "center");
    text(ctx, `\u6700\u9AD8\u8FDE\u9501  \xD7${state.maxChain}`, 240, 830, 27, "#534332");
    text(ctx, `\u5B8C\u6210\u8BA2\u5355  ${state.completedOrders}`, 840, 830, 27, "#534332", "right");
    const seconds = Math.floor(view.elapsed / 1e3), time = `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
    text(ctx, tutorial ? "\u5DF2\u638C\u63E1\u5165\u5E93\u4E0E\u6E05\u8DEF" : state.overtime ? "\u52A0\u73ED\u6311\u6218" : `\u5230\u8FBE\u7B2C ${state.shift} \u73ED`, 242, 939, 29, "#e7e4d4");
    text(ctx, time, 838, 939, 29, "#e7e4d4", "right");
    const peak = state.maxOccupancy === void 0 ? "\u672A\u8BB0\u5F55\uFF08\u65E7\u6863\uFF09" : `${Math.round(state.maxOccupancy / 49 * 100)}%\uFF08${state.maxOccupancy}/49\uFF09`;
    text(ctx, `\u6700\u9AD8\u5360\u7528  ${peak}`, 240, 992, 25, "#e7e4d4");
    const selected = [...new Set(state.upgrades)].map((id2) => {
      var _a2, _b2;
      return (_b2 = (_a2 = UPGRADES_V2.find((upgrade2) => upgrade2.id === id2)) == null ? void 0 : _a2.title) != null ? _b2 : id2;
    });
    const keyUpgrades = selected.length ? selected.slice(0, 3).join(" / ") + (selected.length > 3 ? ` \u7B49${selected.length}\u9879` : "") : "\u65E0";
    text(ctx, `\u5173\u952E\u5347\u7EA7  ${keyUpgrades}`, 240, 1041, 23, "#d4dcdd", "left", 500);
    if (tutorial) text(ctx, "\u7EC3\u4E60\u4E0D\u8BA1\u5165\u6B63\u5F0F\u6210\u7EE9\u4E0E\u4E94\u73ED\u5168\u52E4", 540, 1118, 28, "#c1d1d6", "center", 500);
    else if (daily) text(ctx, "\u540C\u65E5\u540C\u89C4\u5219\u56FA\u5B9A\u79CD\u5B50 \xB7 \u6BCF\u65E5\u6311\u6218\u4E0D\u8FDB\u5165\u52A0\u73ED", 540, 1118, 25, "#c1d1d6", "center", 500);
    else if (!getUiControls(state, view).some((control2) => control2.action.type === "continueOvertime")) text(ctx, "\u4E0B\u4E00\u6B21\uFF0C\u7ED9\u53C9\u8F66\u7559\u4E00\u6761\u8DEF", 540, 1118, 29, "#c1d1d6", "center", 500);
    drawControls(ctx, state, view);
    text(ctx, view.profileStatus || "\u672C\u5730\u8BB0\u5F55", 540, 1588, 24, "#bbcad0", "center", 500);
    text(ctx, daily ? "\u5317\u4EAC\u65F6\u95F4\uFF08UTC+08:00\uFF09\xB7 \u5BA2\u6237\u7AEF\u65E5\u671F \xB7 \u65E0\u5728\u7EBF\u6392\u884C" : "\u672C\u5730\u8BB0\u5F55\u6A21\u5F0F \xB7 \u65E0\u5728\u7EBF\u6392\u884C", 540, 1643, 23, "#91a4b3", "center", 500);
  }
  function drawDebug(ctx, state, view) {
    var _a;
    const pages = debugPages(state, view), page = ((_a = view.debugPage) != null ? _a : 0) % pages.length;
    panel(ctx, { x: 72, y: 390, w: 936, h: 1310 }, "#0f2634", "#8fa9af");
    text(ctx, `\u89C4\u5219 v${state.rulesetVersion} \xB7 \u5F00\u53D1\u7248`, 112, 445, 31, "#f2d38b");
    text(ctx, `\u8BCA\u65AD ${page + 1}/${pages.length}`, 960, 445, 28, "#f2d38b", "right");
    pages[page].forEach((line, i) => text(ctx, line, 112, 515 + i * 40, 24, "#c6d1d7", "left", 500));
    button(ctx, DEBUG_PREVIOUS, "\u4E0A\u4E00\u9875", false);
    button(ctx, DEBUG_NEXT, "\u4E0B\u4E00\u9875", false);
    text(ctx, "\u53EA\u8BFB\u8BCA\u65AD \xB7 \u70B9\u51FB\u53F3\u4E0B\u300C\u72B6\u6001\u300D\u6536\u8D77", 540, 1655, 23, "#e9c473", "center", 500);
  }
  function drawControls(ctx, state, view) {
    getUiControls(state, view).forEach((control2, index) => drawControl(ctx, control2, index === 0 && !["cancel", "toggleSound"].includes(control2.action.type)));
  }
  function drawControl(ctx, control2, primary) {
    const { rect: r, disabled, selected } = control2;
    const warm = !disabled && (primary || selected);
    ctx.save();
    roundedPath(ctx, r.x, r.y + 6, r.w, r.h, 18);
    ctx.fillStyle = "#08121d";
    ctx.fill();
    roundedPath(ctx, r.x, r.y, r.w, r.h, 18);
    ctx.fillStyle = gradient(ctx, r.x, r.y, r.h, disabled ? "#34404c" : warm ? "#ffe184" : "#40576f", disabled ? "#293440" : warm ? "#e7ae46" : "#243b51");
    ctx.fill();
    ctx.strokeStyle = disabled ? "#526271" : warm ? "#bd8d38" : "#7890a3";
    ctx.lineWidth = 3;
    ctx.stroke();
    roundedPath(ctx, r.x + 6, r.y + 6, r.w - 12, r.h - 12, 13);
    ctx.strokeStyle = disabled ? "#455565" : warm ? "#fff0ba" : "#526e85";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    if (selected) {
      roundedPath(ctx, r.x + 12, r.y + 22, 7, r.h - 44, 3);
      ctx.fillStyle = "#654016";
      ctx.fill();
    }
    const lines = control2.label.split("\n");
    lines.forEach((line, index) => {
      let size = lines.length > 1 ? index ? 22 : 29 : r.w < 420 ? 32 : 36;
      ctx.font = `800 ${size}px "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", sans-serif`;
      const measured = ctx.measureText(line).width;
      if (measured > r.w - 48) size *= (r.w - 48) / measured;
      text(ctx, line, r.x + r.w / 2, r.y + r.h / 2 + (index - (lines.length - 1) / 2) * 34, size, disabled ? "#a2b1be" : warm ? "#49361b" : CREAM, "center", index ? 500 : 800);
    });
    ctx.restore();
  }
  function drawMenu(ctx, state, view) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    text(ctx, "WAREHOUSE  /  LAST SLOT", 540, 120, 22, "#b7b098", "center", 600);
    outlinedText(ctx, "\u7206\u4ED3", 540, 267, 151, CREAM, "center");
    outlinedText(ctx, "\u6700\u540E\u4E00\u683C", 540, 387, 79, "#ffe3a3", "center");
    hazard(ctx, { x: 314, y: 448, w: 452, h: 14 });
    ctx.fillStyle = "rgba(255,230,159,.07)";
    ctx.beginPath();
    ctx.ellipse(540, 553, 180, 33, 0, 0, Math.PI * 2);
    ctx.fill();
    forklift(ctx, 540, 523, 140, -0.12, (_a = view.profile) == null ? void 0 : _a.cosmetics.forklift);
    panel(ctx, { x: 180, y: 610, w: 720, h: 195 }, "#304758", "#849792", 20);
    const best = (_b = view.profile) == null ? void 0 : _b.bestScores[`standard.v${state.rulesetVersion}`];
    text(ctx, `\u6807\u51C6\u6700\u9AD8\u5206 \xB7 v${state.rulesetVersion}`, 222, 653, 25, "#a9c0c9", "left", 500);
    text(ctx, number((_c = best == null ? void 0 : best.score) != null ? _c : 0), 222, 720, 48, "#ffe29c", "left", 900);
    text(ctx, "\u6700\u9AD8\u8FDE\u9501", 850, 653, 25, "#a9c0c9", "right", 500);
    text(ctx, `\xD7${(_e = (_d = view.profile) == null ? void 0 : _d.stats.maxChain) != null ? _e : 0}`, 850, 720, 48, "#cce8ce", "right", 900);
    text(ctx, `\u52A0\u73ED\u6700\u9AD8\u5206 \xB7 ${number((_h = (_g = (_f = view.profile) == null ? void 0 : _f.bestScores[`overtime.v${state.rulesetVersion}`]) == null ? void 0 : _g.score) != null ? _h : 0)}`, 540, 774, 23, "#a9c0c9", "center", 500);
    drawControls(ctx, state, view);
    text(ctx, `${(_i = view.dailyLabel) != null ? _i : "\u65E5\u671F\u5F85\u786E\u8BA4"} \xB7 \u5317\u4EAC\u65F6\u95F4\uFF08UTC+08:00\uFF09`, 540, 1460, 27, "#d1dccf", "center", 500);
    text(ctx, "\u672C\u5730\u6BCF\u65E5\u6311\u6218 \xB7 \u540C\u65E5\u540C\u89C4\u5219\u56FA\u5B9A\u79CD\u5B50 \xB7 \u65E0\u5728\u7EBF\u6392\u884C", 540, 1513, 23, "#9bafbd", "center", 500);
    const unlocked = ACHIEVEMENTS.filter((item) => {
      var _a2;
      return (_a2 = view.profile) == null ? void 0 : _a2.achievements.includes(item.id);
    });
    text(ctx, `\u6210\u5C31 ${unlocked.length} / ${ACHIEVEMENTS.length}`, 540, 1610, 24, "#ecc778", "center", 600);
    text(ctx, unlocked.length ? unlocked.slice(0, 2).map((item) => item.name).join("  \xB7  ") : "\u9996\u6B21\u6B63\u5F0F\u51FA\u8D27\uFF0C\u89E3\u9501\u84DD\u8272\u53C9\u8F66", 540, 1660, 26, "#c4d2d6", "center", 500);
    text(ctx, view.profileStatus || "\u957F\u671F\u8BB0\u5F55\u4FDD\u5B58\u5728\u672C\u673A", 540, 1777, 23, "#9db0bc", "center", 500);
    text(ctx, "\u7EAF\u5916\u89C2\u89E3\u9501 \xB7 \u6CA1\u6709\u6C38\u4E45\u6218\u529B", 540, 1845, 22, "#7f95a6", "center", 500);
  }
  function drawSettings(ctx, state, view) {
    outlinedText(ctx, "\u8BBE\u7F6E\u4E0E\u5916\u89C2", 540, 157, 71, CREAM, "center");
    text(ctx, "\u6309\u81EA\u5DF1\u7684\u8282\u594F\u503C\u73ED", 540, 237, 28, "#b1c4cf", "center", 500);
    text(ctx, "\u6E38\u73A9\u8BBE\u7F6E", 133, 312, 25, "#e0c18a", "left", 600);
    text(ctx, "\u7B80\u5316\u51FA\u5E93\u52A8\u753B\uFF0C\u4ECD\u4FDD\u7559\u7ED3\u679C\u4E0E\u8DEF\u5F84\u63D0\u793A", 540, 638, 24, "#a6bdca", "center", 500);
    text(ctx, "\u4ED3\u5E93\u4E3B\u9898", 133, 686, 27, "#e0c18a", "left", 600);
    text(ctx, "\u53C9\u8F66\u6D82\u88C5", 133, 891, 27, "#e0c18a", "left", 600);
    FORKLIFTS.forEach((item, index) => {
      const x = 262 + index * 278;
      forklift(ctx, x, 939, 71, 0, item.id);
    });
    text(ctx, "\u8D27\u7BB1\u6837\u5F0F", 133, 1142, 27, "#e0c18a", "left", 600);
    cargoBox(ctx, "cargo.food", 306, 1158, 55, 1, void 0, "classic");
    cargoBox(ctx, "cargo.food", 724, 1158, 55, 1, void 0, "outline");
    drawControls(ctx, state, view);
    text(ctx, "\u5916\u89C2\u4E0D\u6539\u53D8\u8BA2\u5355\u3001\u968F\u673A\u5E8F\u5217\u4E0E\u5F97\u5206\u89C4\u5219", 540, 1374, 24, "#a8bbc6", "center", 500);
    wrap(ctx, view.profileStatus || "\u957F\u671F\u8BB0\u5F55\u4FDD\u5B58\u5728\u672C\u673A", 153, 1431, 774, 23, 30);
  }
  function drawActivePause(ctx, state, view) {
    var _a;
    shade(ctx);
    const overtime = !!state.overtime;
    panel(ctx, { x: 173, y: 395, w: 734, h: overtime ? 1310 : 1160 }, "#30455a", "#95a9b1", 28);
    hazard(ctx, { x: 201, y: 423, w: 678, h: 18 });
    forklift(ctx, 540, 551, 137, -0.12, (_a = view.profile) == null ? void 0 : _a.cosmetics.forklift);
    outlinedText(ctx, overtime ? "\u52A0\u73ED\u4F11\u606F\u4E2D" : "\u4F11\u606F\u4E00\u4E0B", 540, 674, 68, CREAM, "center");
    text(ctx, "\u8D27\u7269\u4E0E\u8BA2\u5355\u90FD\u5DF2\u6682\u505C", 540, 761, 29, "#c6d1d6", "center", 500);
    const rules = state.rulesetVersion >= 2 ? [
      "\u6258\u76D8\u53601\u683C\u8BA12\u4EF6\uFF1B\u4E07\u80FD\u53EF\u8FDE\u63A5\u5F53\u524D\u8BA2\u5355\u8D27\u7C7B",
      "\u52A0\u6025\uFF1A\u540E\u7EED\u6709\u6548\u653E\u7F6E\u5012\u6570\u5F52\u96F6\uFF0C\u53D8\u5E9F\u5F03\u7269",
      "\u5E9F\u7269\u5360\u683C\u4E0D\u51FA\u5E93\uFF1B\u5371\u9669\u54C1\u51FA\u8D27\u65F6\u6E05\u76F8\u90BB\u5E9F\u7269",
      "\u7A7F\u6258\u76D8\u4E0D\u642C\u8D70\u6258\u76D8\uFF1B\u989D\u5916\u6E05\u7406\u4E0D\u8BA1\u5206"
    ] : ["\u540C\u7C7B\u8D27\u7269\u76F8\u90BB\u6210\u7EC4\uFF0C\u8FBE\u5230\u8BA2\u5355\u6570\u91CF", "\u4ECE\u51FA\u8D27\u53E3\u7559\u51FA\u7A7A\u683C\u901A\u8DEF\uFF0C\u53C9\u8F66\u81EA\u52A8\u642C\u8FD0"];
    rules.forEach((line, index) => text(ctx, line, 540, 850 + index * 42, 24, "#b7cbd4", "center", 500));
    drawControls(ctx, state, view);
    text(ctx, view.saveStatus || "\u5F53\u524D\u503C\u73ED\u4FDD\u7559\u5728\u672C\u673A", 540, overtime ? 1774 : 1630, 24, "#a3bac8", "center", 500);
  }
  function drawConfirmation(ctx, state, view) {
    var _a, _b;
    shade(ctx);
    panel(ctx, { x: 140, y: 595, w: 800, h: 765 }, "#344859", "#c5b98f", 28);
    hazard(ctx, { x: 170, y: 627, w: 740, h: 16 });
    const kind = (_a = view.confirmation) == null ? void 0 : _a.kind;
    const title = kind === "resetProfile" ? "\u91CD\u7F6E\u957F\u671F\u8BB0\u5F55\uFF1F" : kind === "finishOvertime" ? "\u7ED3\u675F\u8FD9\u6B21\u52A0\u73ED\uFF1F" : "\u5F00\u59CB\u65B0\u7684\u503C\u73ED\uFF1F";
    outlinedText(ctx, title, 540, 750, 59, CREAM, "center");
    const lines = kind === "resetProfile" ? ["\u8BBE\u7F6E\u3001\u5916\u89C2\u548C\u672C\u5730\u6210\u7EE9\u5C06\u6062\u590D\u521D\u59CB\u72B6\u6001\u3002", "\u5F53\u524D\u503C\u73ED\u4ECD\u4F1A\u4FDD\u7559\u3002", "\u5F53\u524D\u5C40\u4E4B\u540E\u7684\u7ED3\u7B97\u4F1A\u8BA1\u5165\u65B0\u8BB0\u5F55\u3002"] : kind === "finishOvertime" ? ["\u5C06\u6309\u5F53\u524D\u5206\u6570\u7ED3\u7B97\u8FD9\u6B21\u52A0\u73ED\u3002", "\u7ED3\u7B97\u540E\u4E0D\u80FD\u7EE7\u7EED\u672C\u6B21\u52A0\u73ED\u3002", "\u53D6\u6D88\u53EF\u56DE\u5230\u539F\u6765\u7684\u4ED3\u5E93\u3002"] : ["\u65B0\u5C40\u4F1A\u66FF\u6362\u5C1A\u672A\u5B8C\u6210\u7684\u5F53\u524D\u503C\u73ED\u3002", ((_b = view.confirmation) == null ? void 0 : _b.mode) === "daily" ? "\u5F00\u59CB\u4ECA\u65E5\u7684\u672C\u5730\u56FA\u5B9A\u79CD\u5B50\u6311\u6218\u3002" : "\u5F00\u59CB\u4E00\u8F6E\u5168\u65B0\u7684\u6807\u51C6\u4E94\u73ED\u6311\u6218\u3002", "\u53D6\u6D88\u4F1A\u5B8C\u6574\u4FDD\u7559\u5F53\u524D\u8FDB\u5EA6\u3002"];
    lines.forEach((line, index) => text(ctx, line, 540, 897 + index * 63, 29, "#d1dde1", "center", 500));
    drawControls(ctx, state, view);
  }

  // src/wechat-main.ts
  var platform = createWechatPlatform(wx, { requestAnimationFrame: (callback) => requestAnimationFrame(callback), now: () => Date.now() });
  var session = new GameSession(platform, { seed: 20261005, mode: "tutorial" });
  platform.onPointer((event) => {
    if (event.type === "cancel") session.input.cancel(event.id);
    else session.input[event.type](event.point, event.id);
  });
  platform.onHide(() => session.hide());
  platform.onShow(() => session.show());
  function frame(now2) {
    session.tick(now2);
    render(platform.beginFrame(), session.state, session.view);
    platform.frame(frame);
  }
  platform.frame(frame);
})();
